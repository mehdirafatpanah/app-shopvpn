# ShopVPN Admin — Nexus UI v2

This version is a full UI/UX redesign focused on information density, navigation clarity and compact controls.

## What changed

- Replaced the old large bento/tile "All Sections" menu with a compact command-center menu.
- Added section grouping, section counts and search/filter for fast navigation.
- Reworked bottom navigation into a compact dock with a dedicated floating "All Sections" command button.
- Reworked notification preferences from a long vertical list into:
  - one global notification control
  - compact two-column per-section controls
- Reduced excessive card heights, padding and visual noise.
- Kept SDUI, API, session, cache, FCM and existing business logic intact.
- No new external dependencies were added.

## Build

The project uses Android Gradle Plugin/Kotlin/Compose settings already present in the project.
Run the existing GitHub Actions workflow or build with the project's configured Gradle environment.
