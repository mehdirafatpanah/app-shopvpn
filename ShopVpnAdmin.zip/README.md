# ShopVPN Admin — اپ اندروید مدیریت

اپ مدیریت بومی (Native, Kotlin + Jetpack Compose) برای پنل مستقل ShopVPN.
معماری آن **Server-Driven UI (SDUI)** است: تب‌ها، فیلدها و اکشن‌ها از یک
اندپوینت روی سرور (`/api/app/config`) خوانده و به‌صورت کامپوننت‌های Native
رندر می‌شوند — یعنی اضافه‌کردن یا تغییر یک فیچر در پنل وب، بدون نیاز به
آپدیت یا ری‌بیلد اپ، همان لحظه در اپ هم دیده می‌شود.

## پیش‌نیاز سمت بک‌اند

فایل‌های زیر باید در ریپوی اصلی ShopVPN شما اضافه/تغییر کرده باشند (اگر از
همین مکالمه گرفتیدشان، از قبل انجام شده):

- `database.py` → جدول‌های `mobile_app_tokens` و `mobile_fcm_tokens`
- `admin_panel/mobile_auth.py` (فایل جدید)
- `admin_panel/server.py` → پشتیبانی از `Authorization: Bearer`، اندپوینت‌های
  `/api/app/tokens`, `/api/app/config`, `/api/app/fcm-token`, `/app/webview-bridge`
- `fcm_client.py` (فایل جدید، در ریشه‌ی پروژه‌ی بات)
- `requirements.txt` → اضافه‌شدن `PyJWT`

بعد از اضافه‌کردن این‌ها، `pip install -r requirements.txt --break-system-packages`
و ری‌استارت سرویس پنل وب (`manage.sh` یا سرویس systemd مربوطه) را انجام دهید.

## ساخت یک توکن دسترسی (PAT)

فعلاً از طریق API مستقیم (بعداً یک دکمه هم به تنظیمات UI پنل وب اضافه کنید):

```bash
curl -X POST https://YOUR_PANEL_URL/api/app/tokens \
  -H "Content-Type: application/json" \
  -b "panel_session=<کوکی لاگین فعلی مرورگرت>" \
  -d '{"name":"گوشی من"}'
```

یا ساده‌تر: همین درخواست را از طریق DevTools مرورگر (Console → fetch) بعد از
لاگین در پنل وب بزنید. توکن (`token`) در پاسخ فقط همین یک‌بار نمایش داده
می‌شود — جایی کپی‌اش کنید.

> بعداً پیشنهاد می‌شود یک دکمه‌ی «ساخت توکن اپ موبایل» به صفحه‌ی تنظیمات
> پنل وب اضافه کنید که همین اندپوینت را صدا بزند؛ خودِ اپ هم از داخل
> «تنظیمات» توکن جدید می‌سازد، پس این مرحله فقط برای اولین اتصال لازم است.

## راه‌اندازی Firebase (اختیاری، برای پوش لحظه‌ای)

اگر در سؤالات قبلی گزینه‌ی «پوش واقعی با FCM» را انتخاب کردید:

1. یک پروژه‌ی رایگان در [Firebase Console](https://console.firebase.google.com) بسازید.
2. یک اپ اندروید با Package name دقیقاً `com.shopvpn.admin` اضافه کنید.
3. فایل `google-services.json` را دانلود کنید.
4. در ریپوی این اپ اندروید: Settings → Secrets and variables → Actions →
   New repository secret به نام `GOOGLE_SERVICES_JSON` بسازید و **کل محتوای**
   فایل JSON را در مقدارش پیست کنید.
5. سمت سرور: از Project Settings → Service Accounts → Generate new private
   key یک فایل جدید بگیرید، اسمش را `firebase-service-account.json` بگذارید
   و کنار `main.py` در ریشه‌ی پروژه‌ی بات قرار دهید (یا مسیرش را در متغیر
   محیطی `FIREBASE_SERVICE_ACCOUNT_PATH` بدهید).

بدون این مرحله، اپ کاملاً کار می‌کند فقط نوتیف پوش لحظه‌ای نخواهید داشت (به‌جایش
هر بار که اپ را باز کنید، لیست‌ها خودشان تازه می‌شوند).

## بیلد اپ (GitHub Actions)

با هر push به شاخه‌ی `main`، اکشن `build-apk.yml` به‌صورت خودکار:
1. یک **APK دیباگ نصب‌شدنی** می‌سازد و به‌عنوان Artifact در تب Actions همان
   ران، قابل دانلود می‌گذارد (بدون نیاز به هیچ تنظیم اضافه).
2. اگر تگ `v*` بزنید (مثل `v1.0.0`) و Secretهای امضا را هم تنظیم کرده
   باشید، یک APK **release امضاشده** هم می‌سازد.

### امضای نسخه‌ی release (اختیاری)

```bash
keytool -genkey -v -keystore release.keystore -alias shopvpn \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.keystore > release.keystore.b64
```

سپس در Secrets ریپو اضافه کنید: `KEYSTORE_BASE64` (محتوای فایل `.b64`),
`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## اولین اجرا رو گوشی

1. APK را نصب کنید (ممکن است لازم باشد «نصب از منابع ناشناس» را فعال کنید).
2. آدرس پنل (`https://panel.example.com`) و توکن PAT را وارد کنید.
3. تب‌ها (سفارش‌ها، کاربران، محصولات، نقشه، تنظیمات و ...) خودکار از سرور
   خوانده می‌شوند.

## توسعه‌ی بعدی — چطور یک تب/فیچر جدید اضافه کنم؟

فقط تابع `api_app_config` در `admin_panel/server.py` را ویرایش کنید و یک
آبجکت جدید به لیست `tabs` اضافه کنید (نوع `list`, `dashboard`, `settings`
یا `webview`). همان لحظه — بدون هیچ آپدیت اپ — تب جدید در گوشی‌های همه‌ی
ادمین‌ها ظاهر می‌شود. فقط اگر فیچر جدید ماهیتاً تصویری/غیرمعمول باشد (مثل
نقشه)، باید مثل تب `map` از نوع `webview` استفاده کنید یا یک کامپوننت
Native اختصاصی جدید به پوشه‌ی `sdui/components` اضافه کرده و در
`ScreenRenderer.kt` رجیستر کنید (این یکی، بله، به آپدیت اپ نیاز دارد).


## UI/UX redesign — ShopVPN Nexus

This version includes a full visual refresh while keeping the existing networking, SDUI and data layers intact.

- New **ShopVPN Nexus** design system: premium dark + minimal cyberpunk.
- New global color tokens, typography and Material 3 shapes.
- New app shell with redesigned top bar, status treatment and floating navigation.
- Redesigned connection/onboarding screen.
- Redesigned all-sections navigation and tiles.
- Shared cards, status chips, icon tiles, empty states and background treatment refreshed globally.
- Default visual mode is now dark to match the Nexus direction; the existing session-based theme controller remains available.
