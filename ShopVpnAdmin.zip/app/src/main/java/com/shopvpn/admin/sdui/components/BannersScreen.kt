package com.shopvpn.admin.sdui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.theme.StatusDanger
import kotlinx.coroutines.launch

private const val MAX_BANNERS = 20

private data class BannerItem(
    val text: String = "",
    val imageUrl: String? = null,
    val enabled: Boolean = true,
)

/**
 * تب «بنرها»: لیست native از بنرها با متن، عکس (آپلود از گالری گوشی) و
 * فعال/غیرفعال — بدون هیچ صفحه‌ی وبی. آپلود عکس مستقیماً از /api/banners/
 * upload-image استفاده می‌کند و بعد از آن، کل لیست با یک درخواست ذخیره می‌شود
 * (دقیقاً همان قراردادی که پنل وب هم استفاده می‌کند).
 */
@Composable
fun BannersScreen(tab: TabConfig, api: ApiClient, session: SessionManager) {
    var banners by remember(tab.id) { mutableStateOf<List<BannerItem>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var saving by remember(tab.id) { mutableStateOf(false) }
    var uploadingIndex by remember(tab.id) { mutableStateOf(-1) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var pickTargetIndex by remember { mutableStateOf(-1) }

    fun baseUrlOf(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http")) return path
        return (session.baseUrl?.trimEnd('/') ?: "") + path
    }

    suspend fun load() {
        val source = tab.source
        if (source == null) {
            error = "این تب پیکربندی نامعتبری دارد."
            loading = false
            return
        }
        loading = true
        error = null
        try {
            val res = api.get(source)
            if (res.isJsonArray) {
                banners = res.asJsonArray.mapNotNull { el ->
                    if (!el.isJsonObject) return@mapNotNull null
                    val o = el.asJsonObject
                    BannerItem(
                        text = o["text"]?.takeIf { !it.isJsonNull }?.asString ?: "",
                        imageUrl = o["image_url"]?.takeIf { !it.isJsonNull }?.asString,
                        enabled = o["enabled"]?.takeIf { !it.isJsonNull }?.asBoolean ?: true,
                    )
                }
            }
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری بنرها"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val index = pickTargetIndex
        pickTargetIndex = -1
        if (uri == null || index < 0 || index >= banners.size) return@rememberLauncherForActivityResult
        scope.launch {
            uploadingIndex = index
            try {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("خواندن فایل ممکن نشد")
                if (bytes.size > 2 * 1024 * 1024) {
                    snackbarHostState.showSnackbar("حجم عکس نباید بیشتر از ۲ مگابایت باشد")
                    return@launch
                }
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val ext = when {
                    mime.contains("png") -> "png"
                    mime.contains("webp") -> "webp"
                    mime.contains("gif") -> "gif"
                    else -> "jpg"
                }
                val res = api.uploadFile("/api/banners/upload-image", "photo", "banner.$ext", mime, bytes)
                val url = res.takeIf { it.isJsonObject }?.asJsonObject?.get("url")?.asString
                if (url != null) {
                    banners = banners.toMutableList().also { it[index] = it[index].copy(imageUrl = url) }
                } else {
                    snackbarHostState.showSnackbar("آپلود ناموفق بود")
                }
            } catch (e: Exception) {
                snackbarHostState.showSnackbar(e.message ?: "خطا در آپلود عکس")
            } finally {
                uploadingIndex = -1
            }
        }
    }

    suspend fun save() {
        val submitUrl = tab.submit_url ?: return
        saving = true
        try {
            val arr = JsonArray()
            banners.forEach { b ->
                val o = JsonObject()
                o.addProperty("text", b.text)
                if (b.imageUrl != null) o.addProperty("image_url", b.imageUrl) else o.add("image_url", com.google.gson.JsonNull.INSTANCE)
                o.addProperty("enabled", b.enabled)
                arr.add(o)
            }
            val body = JsonObject()
            body.add("banners", arr)
            api.post(submitUrl, body.toString())
            snackbarHostState.showSnackbar("بنرها ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            saving = false
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { scope.launch { save() } },
                icon = {
                    if (saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Filled.Image, contentDescription = null)
                },
                text = { Text(if (saving) "در حال ذخیره..." else "ذخیره‌ی بنرها") },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (banners.isEmpty()) {
                        item { EmptyState(title = "بنری اضافه نشده", subtitle = "با دکمه‌ی زیر یکی اضافه کن") }
                    }
                    items(banners.size) { index ->
                        val banner = banners[index]
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(120.dp)
                                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    val fullUrl = baseUrlOf(banner.imageUrl)
                                    if (uploadingIndex == index) {
                                        CircularProgressIndicator()
                                    } else if (fullUrl != null) {
                                        AsyncImage(
                                            model = fullUrl,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                        )
                                    } else {
                                        Icon(Icons.Filled.Image, contentDescription = null)
                                    }
                                }
                                TextButton(
                                    onClick = { pickTargetIndex = index; pickImageLauncher.launch("image/*") },
                                    enabled = uploadingIndex != index,
                                ) {
                                    Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (banner.imageUrl == null) "انتخاب عکس" else "تغییر عکس")
                                }
                                OutlinedTextField(
                                    value = banner.text,
                                    onValueChange = { new ->
                                        banners = banners.toMutableList().also { it[index] = it[index].copy(text = new) }
                                    },
                                    label = { Text("متن بنر") },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = banner.enabled,
                                            onCheckedChange = { new ->
                                                banners = banners.toMutableList().also { it[index] = it[index].copy(enabled = new) }
                                            },
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text("فعال", style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = { banners = banners.toMutableList().also { it.removeAt(index) } }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = StatusDanger)
                                    }
                                }
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            onClick = { banners = banners + BannerItem() },
                            enabled = banners.size < MAX_BANNERS,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (banners.size < MAX_BANNERS) "➕ افزودن بنر" else "حداکثر ۲۰ بنر مجاز است") }
                    }
                }
            }
        }
    }
}
