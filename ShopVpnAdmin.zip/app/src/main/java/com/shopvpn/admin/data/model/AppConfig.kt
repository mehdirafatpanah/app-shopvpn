package com.shopvpn.admin.data.model

data class AppConfigResponse(
    val server_name: String = "ShopVPN Admin",
    val tenant: String = "main",
    val tabs: List<TabConfig> = emptyList(),
)

data class TabConfig(
    val id: String,
    val title: String,
    val icon: String = "circle",
    val screen: String,           // dashboard | list | settings | webview
    val source: String? = null,
    val url: String? = null,
    val item_id_field: String? = "id",
    val search: Boolean = false,
    val filters: List<FilterConfig> = emptyList(),
    val fields: List<FieldConfig> = emptyList(),
    val actions: List<ActionConfig> = emptyList(),
    val detail_source: String? = null,
)

data class FilterConfig(
    val key: String,
    val label: String,
    val options: List<String> = emptyList(),
)

data class FieldConfig(
    val key: String,
    val label: String,
    val type: String = "text",     // text | title | currency | badge | date | toggle
    val toggle_endpoint: String? = null,
)

data class ActionConfig(
    val id: String,
    val label: String,
    val method: String = "POST",
    val endpoint: String,          // شامل {id} که با مقدار واقعی جایگزین می‌شود
    val style: String = "default", // default | success | danger
    val confirm: Boolean = false,
)
