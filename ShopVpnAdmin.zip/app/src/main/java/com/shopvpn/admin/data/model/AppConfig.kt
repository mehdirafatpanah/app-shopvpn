package com.shopvpn.admin.data.model

data class AppConfigResponse(
    val server_name: String = "ShopVPN Admin",
    val tenant: String = "main",
    val tabs: List<TabConfig> = emptyList(),
)

data class TabConfig(
    val id: String,
    val title: String,
    val icon: String = "circle",
    val screen: String,           // dashboard | list | settings | form | webview
    val source: String? = null,
    val url: String? = null,
    val item_id_field: String? = "id",
    val search: Boolean = false,
    val filters: List<FilterConfig> = emptyList(),
    val fields: List<FieldConfig> = emptyList(),
    val actions: List<ActionConfig> = emptyList(),
    val detail_source: String? = null,
    val section: String? = null,  // برای گروه‌بندی در منوی کشویی، مثل سایدبار پنل وب
    // فقط برای screen == "form": فرم native با فیلدهای کلید-مقدار که سرور
    // تعریف می‌کند؛ یعنی افزودن فیلد جدید در پنل وب/سرور، بدون آپدیت اپ همان
    // لحظه در فرم موبایل ظاهر می‌شود.
    val load_url: String? = null,
    val submit_url: String? = null,
    val form_sections: List<FormSectionConfig> = emptyList(),
    // فقط برای screen == "settings_group": چند کارت مستقل که هرکدام endpoint
    // load/submit خودشان را دارند (برخلاف "form" که یک فروشگاه کلید-مقدار
    // ساده است، این‌ها اندپوینت‌های REST جدا با بدنه‌ی JSON تایپ‌شده‌اند).
    val cards: List<SettingsCardConfig> = emptyList(),
    // فقط برای screen == "server_map": اندپوینت جدای نقشه‌ی پس‌زمینه (خطوط
    // ساحلی)، جدا از "source" که لیست پین‌های سرور را می‌دهد.
    val map_source: String? = null,
    // فقط برای screen == "system_status": "source" آمار CPU/RAM/دیسک را می‌دهد؛
    // این سه‌تا مکمل آن‌اند.
    val jobs_source: String? = null,
    val backup_status_source: String? = null,
    val backup_create_endpoint: String? = null,
    // فقط برای screen == "list": اگر تعریف شده باشد یک دکمه‌ی شناور «افزودن»
    // نمایش داده می‌شود که فرم native می‌سازد و به submit_url پست می‌کند.
    val create_form: CreateEditFormConfig? = null,
    // فقط برای screen == "list": اگر تعریف شده باشد (و detail_source تعریف
    // نشده باشد) با لمس هر آیتم همین فرم با مقادیر همان آیتم باز می‌شود.
    val edit_form: CreateEditFormConfig? = null,
    // فقط برای screen == "list" با detail_source: اگر تعریف شده باشد، صفحه‌ی
    // جزئیات یک دکمه‌ی «نمایش رسید» نشان می‌دهد که این اندپوینت را (شامل {id})
    // می‌خواند و یک تصویر base64 برمی‌گرداند.
    val receipt_source: String? = null,
    // فقط برای screen == "list": اگر "user" باشد، به‌جای DetailScreen عمومی از
    // UserDetailScreen استفاده می‌شود (کیف‌پول، سفارش‌ها، شارژها، سرویس‌های
    // مستقیم-پنل با اکشن‌هایشان — معادل صفحه‌ی جزئیات کاربر در پنل وب).
    val detail_type: String? = null,
    val services_source: String? = null,
    val wallet_endpoint: String? = null,
    // فقط برای screen == "list": اگر تعریف شده باشد و آیتم auto_provision نباشد،
    // یک دکمه‌ی «بانک کانفیگ» نمایش داده می‌شود که موجودی لینک‌های دستی محصول
    // را مدیریت می‌کند (افزودن چندخطی، کپی، حذف) — معادل همین دکمه در پنل وب.
    val config_bank_source: String? = null,
)

data class CreateEditFormConfig(
    val title: String = "",
    val submit_url: String,       // می‌تواند شامل {id} باشد (برای edit_form)
    val method: String = "POST",  // POST برای ساخت، PUT برای ویرایش
    val fields: List<FormFieldConfig> = emptyList(),
)

data class SettingsCardConfig(
    val title: String,
    val load_url: String,
    val submit_url: String,
    val fields: List<FormFieldConfig> = emptyList(),
    val danger_action: DangerActionConfig? = null,
)

data class DangerActionConfig(
    val label: String,
    val endpoint: String,
    val method: String = "POST",
    val confirm_text: String = "مطمئنی؟",
)

data class FormSectionConfig(
    val title: String,
    val groups: List<FormGroupConfig> = emptyList(),
)

data class FormGroupConfig(
    val title: String,
    val fields: List<FormFieldConfig> = emptyList(),
)

data class FormFieldConfig(
    val key: String,
    val label: String,
    val type: String = "text",   // text | textarea | password | number | bool | color | select | select_remote | multiselect
    val options: List<List<String>> = emptyList(), // برای select/multiselect ثابت: [[value, label], ...]
    // برای select_remote: از این اندپوینت (GET) لیست گزینه‌ها را می‌گیرد؛
    // پاسخ می‌تواند آرایه‌ای از {id,name}, {value,label} یا رشته‌ی ساده باشد.
    val options_source: String? = null,
    val option_value_key: String = "id",
    val option_label_key: String = "name",
    val nullable: Boolean = false, // برای select/select_remote: گزینه‌ی «بدون انتخاب» اضافه می‌شود
    // این فیلد فقط وقتی نمایش داده می‌شود که فیلد بولی depends_on مقدار "1" داشته باشد
    val depends_on: String? = null,
)

data class FilterConfig(
    val key: String,
    val label: String,
    val options: List<String> = emptyList(),
)

data class FieldConfig(
    val key: String,
    val label: String,
    val type: String = "text",     // text | title | currency | badge | date | toggle
    val toggle_endpoint: String? = null,
)

data class ActionConfig(
    val id: String,
    val label: String,
    val method: String = "POST",
    val endpoint: String,          // شامل {id} که با مقدار واقعی جایگزین می‌شود
    val style: String = "default", // default | success | danger
    val confirm: Boolean = false,
)
