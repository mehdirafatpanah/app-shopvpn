package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.FormFieldConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.network.ApiException
import com.shopvpn.admin.ui.components.ElevatedAppCard
import kotlinx.coroutines.launch

private val PANEL_TYPE_OPTIONS = listOf(
    listOf("pasarguard", "PasarGuard"),
    listOf("3xui", "3X-UI"),
    listOf("marzban", "Marzban"),
    listOf("marzneshin", "Marzneshin"),
    listOf("hiddify", "Hiddify"),
)
private val TEMPLATE_BASED_TYPES = setOf("pasarguard", "marzban", "marzneshin")
private val INBOUND_SELECT_TYPES = setOf("3xui")
private val SUB_BASE_URL_TYPES = setOf("3xui", "hiddify")

private data class InboundOption(val id: Int, val remark: String, val protocol: String, val port: Int?)

private fun JsonObject.strOrEmpty(key: String): String =
    get(key)?.takeIf { !it.isJsonNull }?.asString ?: ""

private fun apiErrorMessage(e: Exception, fallback: String): String =
    (e as? ApiException)?.message ?: e.message ?: fallback

/**
 * دیالوگ اختصاصی افزودن پنل VPN. برخلاف CreateEditFormDialog عمومی (یک POST
 * ساده)، این یک فلوی دو-مرحله‌ای native است - دقیقاً معادل مودال «پنل جدید»ِ
 * پنل وب (app.js: panelAddFormHtml/wirePanelAddForm/openXuiInboundModal/
 * askPanelSubBaseUrl):
 *  مرحله ۱: اطلاعات اتصال (نام/نوع/آدرس/یوزر-پس یا توکن/کاربر نمونه) →
 *    POST /api/panel-servers.
 *  مرحله ۲ (فقط برای 3X-UI/Hiddify): سرور در پاسخ مرحله‌ی ۱، لیست inbound
 *    (فقط برای 3X-UI) و/یا نیاز به لینک Subscription را اعلام می‌کند؛ اینجا
 *    از خود پنل inbound واقعی چک‌باکسی انتخاب می‌شود، سپس با
 *    PUT /api/panel-servers/{id} (همون اندپوینتی که پنل وب هم برای تکمیل این
 *    مرحله استفاده می‌کند) ثبت نهایی انجام می‌شود.
 */
@Composable
fun PanelWizardDialog(api: ApiClient, onDismiss: () -> Unit, onSaved: () -> Unit) {
    var step by remember { mutableStateOf(1) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var panelType by remember { mutableStateOf("pasarguard") }
    var apiUrl by remember { mutableStateOf("") }
    var apiUsername by remember { mutableStateOf("") }
    var apiPassword by remember { mutableStateOf("") }
    var templateUsername by remember { mutableStateOf("") }
    var defaultGroup by remember { mutableStateOf("") }

    var serverId by remember { mutableStateOf<Int?>(null) }
    var needsInboundSelect by remember { mutableStateOf(false) }
    var inbounds by remember { mutableStateOf<List<InboundOption>>(emptyList()) }
    var selectedInbounds by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var subBaseUrl by remember { mutableStateOf("") }

    suspend fun submitStep1() {
        if (name.isBlank() || apiUrl.isBlank()) {
            error = "نام و آدرس الزامی است."
            return
        }
        if (apiPassword.isBlank()) {
            error = if (panelType == "3xui") "API Token الزامی است." else "رمز/کلید الزامی است."
            return
        }
        if (panelType in TEMPLATE_BASED_TYPES && templateUsername.isBlank()) {
            error = "نام کاربری نمونه الزامی است."
            return
        }
        saving = true
        error = null
        try {
            val body = JsonObject().apply {
                addProperty("name", name.trim())
                addProperty("panel_type", panelType)
                addProperty("api_url", apiUrl.trim())
                addProperty("api_username", apiUsername.trim())
                addProperty("api_password", apiPassword)
                if (defaultGroup.isNotBlank()) addProperty("default_group", defaultGroup.trim())
                if (panelType in TEMPLATE_BASED_TYPES) addProperty("template_username", templateUsername.trim())
            }
            val res = api.post("/api/panel-servers", body.toString()).asJsonObject
            val id = res.get("id").asInt
            when {
                panelType in INBOUND_SELECT_TYPES -> {
                    serverId = id
                    needsInboundSelect = true
                    inbounds = res.get("inbounds")?.takeIf { it.isJsonArray }?.asJsonArray
                        ?.mapNotNull { el ->
                            if (!el.isJsonObject) return@mapNotNull null
                            val o = el.asJsonObject
                            InboundOption(
                                id = o.get("id").asInt,
                                remark = o.strOrEmpty("remark"),
                                protocol = o.strOrEmpty("protocol"),
                                port = o.get("port")?.takeIf { !it.isJsonNull }?.asInt,
                            )
                        } ?: emptyList()
                    step = 2
                }
                panelType in SUB_BASE_URL_TYPES -> {
                    serverId = id
                    needsInboundSelect = false
                    step = 2
                }
                else -> onSaved()
            }
        } catch (e: Exception) {
            error = apiErrorMessage(e, "خطا در ثبت پنل")
        } finally {
            saving = false
        }
    }

    suspend fun submitStep2() {
        if (subBaseUrl.isBlank()) {
            error = "لینک Subscription الزامی است."
            return
        }
        if (needsInboundSelect && selectedInbounds.isEmpty()) {
            error = "حداقل یک inbound را تیک بزن."
            return
        }
        val id = serverId ?: return
        saving = true
        error = null
        try {
            val body = JsonObject().apply {
                addProperty("xui_sub_base_url", subBaseUrl.trim())
                if (needsInboundSelect) {
                    val arr = JsonArray()
                    selectedInbounds.forEach { arr.add(it) }
                    add("xui_inbound_ids", arr)
                }
            }
            api.put("/api/panel-servers/$id", body.toString())
            onSaved()
        } catch (e: Exception) {
            error = apiErrorMessage(e, "خطا در تکمیل تنظیمات")
        } finally {
            saving = false
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TopAppBar(
                    title = { Text(if (step == 1) "پنل جدید" else "تکمیل تنظیمات پنل") },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت")
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = { scope.launch { if (step == 1) submitStep1() else submitStep2() } },
                            enabled = !saving,
                        ) {
                            if (saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("ثبت")
                            }
                        }
                    },
                )

                if (error != null) {
                    Text(
                        error!!,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                    )
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (step == 1) {
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(key = "name", label = "نام (مثلا سرور آلمان)"),
                                        value = name,
                                        onValueChange = { name = it },
                                    )
                                }
                            }
                        }
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(
                                            key = "panel_type", label = "نوع پنل",
                                            type = "select", options = PANEL_TYPE_OPTIONS,
                                        ),
                                        value = panelType,
                                        onValueChange = { panelType = it; error = null },
                                    )
                                }
                            }
                        }
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(key = "api_url", label = "آدرس پنل (https://...)"),
                                        value = apiUrl,
                                        onValueChange = { apiUrl = it },
                                    )
                                }
                            }
                        }
                        if (panelType != "3xui") {
                            item {
                                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                    Box(Modifier.padding(12.dp)) {
                                        FormFieldInput(
                                            field = FormFieldConfig(
                                                key = "api_username",
                                                label = if (panelType == "hiddify") "یوزرنیم (استفاده نمی‌شود)" else "یوزرنیم",
                                            ),
                                            value = apiUsername,
                                            onValueChange = { apiUsername = it },
                                        )
                                    }
                                }
                            }
                        }
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(
                                            key = "api_password",
                                            label = when (panelType) {
                                                "3xui" -> "API Token (Settings ← Security در پنل)"
                                                "hiddify" -> "Hiddify API Key (UUID ادمین)"
                                                else -> "پسورد"
                                            },
                                            type = "password",
                                        ),
                                        value = apiPassword,
                                        onValueChange = { apiPassword = it },
                                    )
                                }
                            }
                        }
                        if (panelType in TEMPLATE_BASED_TYPES) {
                            item {
                                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                    Box(Modifier.padding(12.dp)) {
                                        FormFieldInput(
                                            field = FormFieldConfig(
                                                key = "template_username",
                                                label = "نام کاربری نمونه (برای دریافت قالب)",
                                            ),
                                            value = templateUsername,
                                            onValueChange = { templateUsername = it },
                                        )
                                    }
                                }
                            }
                        }
                        item {
                            Text(
                                when (panelType) {
                                    "3xui" -> "3X-UI جدید فقط با API Token کار می‌کند؛ یوزرنیم لازم نیست. بعد از ثبت باید inbound و لینک Subscription را هم تنظیم کنی."
                                    "hiddify" -> "Hiddify یوزر/پس ندارد؛ فقط API Key لازم است. بعد از ثبت لینک Subscription را هم می‌پرسیم."
                                    else -> "یک نام کاربری که از قبل روی این پنل ساخته شده را وارد کن؛ تنظیمات (گروه/پروکسی) او به‌عنوان قالب برای کاربرهای جدید استفاده می‌شود."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(key = "default_group", label = "گروه پیش‌فرض (اختیاری)"),
                                        value = defaultGroup,
                                        onValueChange = { defaultGroup = it },
                                    )
                                }
                            }
                        }
                    } else {
                        if (needsInboundSelect) {
                            item {
                                Text(
                                    "کدام inbound(ها) برای ساخت کاربرهای جدید استفاده شود؟ (می‌توانی چند مورد را تیک بزنی)",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                            if (inbounds.isEmpty()) {
                                item {
                                    Text(
                                        "این پنل هیچ inbound ای ندارد؛ اول از داخل پنل یک inbound بساز.",
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                            items(inbounds) { ib ->
                                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text(
                                            "#${ib.id} ${ib.remark} (${ib.protocol}:${ib.port ?: "-"})",
                                            modifier = Modifier.weight(1f),
                                        )
                                        Checkbox(
                                            checked = ib.id in selectedInbounds,
                                            onCheckedChange = { checked ->
                                                selectedInbounds = if (checked) selectedInbounds + ib.id else selectedInbounds - ib.id
                                            },
                                        )
                                    }
                                }
                            }
                        }
                        item {
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    FormFieldInput(
                                        field = FormFieldConfig(key = "sub_base_url", label = "لینک پایه‌ی Subscription (https://...)"),
                                        value = subBaseUrl,
                                        onValueChange = { subBaseUrl = it },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
