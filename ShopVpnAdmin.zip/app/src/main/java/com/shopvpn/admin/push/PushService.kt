package com.shopvpn.admin.push

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.shopvpn.admin.MainActivity
import com.shopvpn.admin.R
import com.shopvpn.admin.ShopVpnAdminApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PushService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val app = application as ShopVpnAdminApp
        if (!app.session.isConnected) return // بعد از اتصال، دفعه‌ی بعد ثبت می‌شود
        CoroutineScope(Dispatchers.IO).launch {
            try {
                app.api.post(
                    "/api/app/fcm-token",
                    """{"fcm_token":"$token","device_label":"${Build.MODEL}"}""",
                )
            } catch (_: Exception) {
                // اگر ثبت ناموفق بود، دفعه‌ی بعد که اپ باز شود دوباره تلاش می‌شود
            }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "ShopVPN"
        val body = message.notification?.body ?: message.data["body"] ?: ""
        showNotification(title, body)
    }

    private fun showNotification(title: String, body: String) {
        // اگر اپ هیچ‌وقت باز نشده باشه و onCreate اجرا نشده باشه (مثلاً بلافاصله
        // بعد از نصب یه پوش تستی می‌فرستی)، این یه ضامن اضافه‌ست؛ منبع اصلی
        // ساخت کانال، ShopVpnAdminApp.onCreate هست. createNotificationChannel
        // با همون ID دوباره صدا زدنش بی‌ضرره (no-op می‌شه).
        NotificationHelper.ensureChannel(this)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(this, R.color.brand_primary))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
