package com.shopvpn.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.BrandGradientCard
import com.shopvpn.admin.ui.components.CyberBackground
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(session: SessionManager, api: ApiClient, onConnected: () -> Unit) {
    var serverUrl by remember { mutableStateOf("https://") }
    var token by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    CyberBackground {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(78.dp).clip(RoundedCornerShape(23.dp))
                    .background(Brush.linearGradient(listOf(BrandStart, BrandEnd)))
                    .border(1.dp, Color.White.copy(.16f), RoundedCornerShape(23.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(17.dp))
            Text("ShopVPN", style = MaterialTheme.typography.displaySmall)
            Text("NEXUS ADMIN", style = MaterialTheme.typography.labelMedium, color = AccentCyan)
            Spacer(Modifier.height(26.dp))

            ElevatedAppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp))
                            .background(BrandPrimary.copy(.12f)), Alignment.Center) {
                            Icon(Icons.Filled.Lock, null, tint = BrandPrimary, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column {
                            Text("اتصال امن", style = MaterialTheme.typography.titleMedium)
                            Text("به پنل مدیریت متصل شو", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        serverUrl, { serverUrl = it; error = null },
                        label = { Text("آدرس سرور") },
                        placeholder = { Text("https://panel.example.com") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(13.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        token, { token = it; error = null },
                        label = { Text("توکن دسترسی") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(13.dp)
                    )
                    error?.let {
                        Spacer(Modifier.height(9.dp))
                        Text(it, color = StatusDanger, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height(15.dp))
                    Button(
                        onClick = {
                            if (serverUrl.isBlank() || token.isBlank()) {
                                error = "آدرس سرور و توکن را کامل وارد کن."; return@Button
                            }
                            loading = true
                            session.baseUrl = serverUrl.trim()
                            session.token = token.trim()
                            scope.launch {
                                val ok = api.testConnection()
                                loading = false
                                if (ok) onConnected()
                                else {
                                    session.clear()
                                    error = "اتصال ناموفق بود. آدرس یا توکن را بررسی کن."
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp)
                        else {
                            Icon(Icons.Filled.Login, null, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("ورود به پنل")
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("SHOPVPN  /  NEXUS ADMIN", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(Modifier.height(10.dp))
        }
    }
}
