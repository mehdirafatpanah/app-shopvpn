package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.local.LocalCacheRepository
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import kotlinx.coroutines.launch

private val STYLE_CHOICES = listOf(
    "" to "پیش‌فرض (خاکستری)",
    "primary" to "آبی",
    "success" to "سبز",
    "danger" to "قرمز",
)

private data class ButtonItem(
    val key: String,
    val label: String,
    val hasText: Boolean,
    val hasStyle: Boolean,
    val text: String,
    val style: String,
)

private data class ButtonGroup(
    val key: String,
    val label: String,
    val reorderable: Boolean,
    val items: List<ButtonItem>,
)

private fun JsonObject.str(key: String, default: String = ""): String {
    val el = this[key]
    return if (el == null || el.isJsonNull) default else el.asString
}

private fun JsonObject.boolOf(key: String, default: Boolean = false): Boolean {
    val el = this[key]
    return if (el == null || el.isJsonNull) default else el.asBoolean
}

private fun parseRegistry(root: JsonObject): List<ButtonGroup> {
    val groupsEl = root["groups"]
    if (groupsEl == null || !groupsEl.isJsonArray) return emptyList()
    return groupsEl.asJsonArray.mapNotNull { g ->
        if (!g.isJsonObject) return@mapNotNull null
        val go = g.asJsonObject
        val items = (go["items"]?.takeIf { it.isJsonArray }?.asJsonArray ?: com.google.gson.JsonArray())
            .mapNotNull { it.takeIf { i -> i.isJsonObject }?.asJsonObject }
            .map { io ->
                ButtonItem(
                    key = io.str("key"),
                    label = io.str("label"),
                    hasText = io.boolOf("has_text", true),
                    hasStyle = io.boolOf("has_style", true),
                    text = io.str("text", io.str("label")),
                    style = io.str("style"),
                )
            }
        ButtonGroup(
            key = go.str("key"),
            label = go.str("label"),
            reorderable = go.boolOf("reorderable", false),
            items = items,
        )
    }
}

/**
 * صفحه‌ی native برای تب «دکمه‌های ربات»: رجیستری از button_registry.py را
 * می‌خواند و بدون هیچ صفحه‌ی وبی، متن/رنگ هر دکمه را قابل ویرایش و ترتیب هر
 * گروه را قابل جابه‌جایی (بالا/پایین) می‌کند. اگر فردا دکمه‌ی جدیدی به بات
 * اضافه شود، همین که در رجیستری پایتون ظاهر شود، این‌جا هم خودکار می‌آید —
 * هیچ نام دکمه‌ای این‌جا هاردکد نیست.
 */
@Composable
fun ButtonRegistryScreen(tab: TabConfig, api: ApiClient, cache: LocalCacheRepository) {
    var groups by remember(tab.id) { mutableStateOf<List<ButtonGroup>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var busy by remember(tab.id) { mutableStateOf(false) }
    var editing by remember(tab.id) { mutableStateOf<Pair<String, ButtonItem>?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val cacheKey = remember(tab.id) { LocalCacheRepository.keyForForm(tab.id) }

    suspend fun load() {
        val source = tab.source
        if (source == null) {
            error = "این تب پیکربندی نامعتبری دارد."
            loading = false
            return
        }
        cache.load(cacheKey)?.let { if (it.isJsonObject) groups = parseRegistry(it.asJsonObject) }
        loading = groups.isEmpty()
        error = null
        try {
            val res = api.get(source)
            if (res.isJsonObject) {
                groups = parseRegistry(res.asJsonObject)
                cache.save(cacheKey, res)
            }
        } catch (e: Exception) {
            if (groups.isEmpty()) error = e.message ?: "خطا در بارگذاری دکمه‌ها"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    suspend fun saveItem(groupKey: String, key: String, text: String, style: String) {
        busy = true
        try {
            val body = JsonObject()
            body.addProperty("group", groupKey)
            body.addProperty("key", key)
            body.addProperty("text", text)
            body.addProperty("style", style)
            api.post("/api/buttons/item", body.toString())
            groups = groups.map { g ->
                if (g.key != groupKey) g
                else g.copy(items = g.items.map { if (it.key == key) it.copy(text = text, style = style) else it })
            }
            snackbarHostState.showSnackbar("ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            busy = false
        }
    }

    suspend fun move(groupKey: String, index: Int, delta: Int) {
        val group = groups.firstOrNull { it.key == groupKey } ?: return
        val newIndex = index + delta
        if (newIndex < 0 || newIndex >= group.items.size) return
        val newItems = group.items.toMutableList()
        val tmp = newItems[index]
        newItems[index] = newItems[newIndex]
        newItems[newIndex] = tmp
        groups = groups.map { if (it.key == groupKey) it.copy(items = newItems) else it }
        busy = true
        try {
            val body = JsonObject()
            body.addProperty("group", groupKey)
            val orderArr = com.google.gson.JsonArray()
            newItems.forEach { orderArr.add(it.key) }
            body.add("order", orderArr)
            api.post("/api/buttons/order", body.toString())
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره‌ی ترتیب؛ صفحه را تازه کن")
        } finally {
            busy = false
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                groups.isEmpty() -> EmptyState(title = "دکمه‌ای برای نمایش نیست")
                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(groups) { group ->
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(group.label, style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(8.dp))
                                group.items.forEachIndexed { index, item ->
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.text.ifBlank { item.label }, style = MaterialTheme.typography.bodyMedium)
                                            if (item.hasStyle && item.style.isNotBlank()) {
                                                Text(
                                                    STYLE_CHOICES.firstOrNull { it.first == item.style }?.second ?: item.style,
                                                    style = MaterialTheme.typography.labelSmall,
                                                )
                                            }
                                        }
                                        if (group.reorderable) {
                                            IconButton(onClick = { scope.launch { move(group.key, index, -1) } }, enabled = !busy && index > 0) {
                                                Icon(Icons.Filled.ArrowUpward, contentDescription = "بالا")
                                            }
                                            IconButton(onClick = { scope.launch { move(group.key, index, 1) } }, enabled = !busy && index < group.items.lastIndex) {
                                                Icon(Icons.Filled.ArrowDownward, contentDescription = "پایین")
                                            }
                                        }
                                        IconButton(onClick = { editing = group.key to item }) {
                                            Icon(Icons.Filled.Edit, contentDescription = "ویرایش")
                                        }
                                    }
                                    if (index != group.items.lastIndex) Divider(Modifier.padding(vertical = 4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { (groupKey, item) ->
        var text by remember(item.key) { mutableStateOf(item.text) }
        var style by remember(item.key) { mutableStateOf(item.style) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(item.label) },
            text = {
                Column {
                    if (item.hasText) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            label = { Text("متن دکمه") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    if (item.hasStyle) {
                        Spacer(Modifier.height(12.dp))
                        Text("رنگ", style = MaterialTheme.typography.labelMedium)
                        Column {
                            STYLE_CHOICES.forEach { (value, label) ->
                                Row(
                                    Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    RadioButton(selected = style == value, onClick = { style = value })
                                    Text(label)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { saveItem(groupKey, item.key, text, style) }
                    editing = null
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("انصراف") } },
        )
    }
}
