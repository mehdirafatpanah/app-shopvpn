package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.SubdirectoryArrowLeft
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.shopvpn.admin.data.local.LocalCacheRepository
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import kotlinx.coroutines.launch

private val STYLE_CHOICES = listOf(
    "" to "پیش‌فرض (خاکستری)",
    "primary" to "آبی",
    "success" to "سبز",
    "danger" to "قرمز",
)

// نکته: منوی اصلی بات (کیبورد پایین/شیشه‌ای) در button_registry.py عمداً
// نیامده - پنل وب آن را جداگانه از GET /api/settings/menu-order می‌خواند و
// به‌صورت یک گروه دیگر، کنار گروه‌های رجیستری عمومی، در همان تب «دکمه‌های
// ربات» نشان می‌دهد (app.js: buildMainMenuGroup). این صفحه‌ی native باید
// دقیقاً همان کار را بکند تا با پنل وب یکی باشد.
private const val MAIN_MENU_GROUP_KEY = "main_menu"
private const val MAIN_MENU_LABEL = "منوی اصلی ربات (پایین / شیشه‌ای)"
private const val MAIN_MENU_NOTE =
    "ترتیب، فعال/غیرفعال بودن، متن و رنگ دکمه‌های منوی اصلی ربات از همین‌جا قابل تغییر است. " +
    "با فلش‌های بالا/پایین ترتیب را جابه‌جا کن و با دکمه‌ی «کنار قبلی / ردیف جدید» مشخص کن کدام " +
    "دکمه‌ها کنار هم و کدام‌ها در ردیف جدا نمایش داده شوند. برای نوع نمایش منو (پایین/شیشه‌ای) و " +
    "تعداد دکمه در هر ردیف، به «تنظیمات و برندینگ» در پنل وب برو."

private data class ButtonItem(
    val key: String,
    val label: String,
    val hasText: Boolean,
    val hasStyle: Boolean,
    val text: String,
    val style: String,
    val adminOnly: Boolean = false,
    val togglable: Boolean = false,
    val enabled: Boolean = true,
    val breakBefore: Boolean? = null,
)

private data class ButtonGroup(
    val key: String,
    val label: String,
    val reorderable: Boolean,
    val supportsRowBreak: Boolean = false,
    val note: String? = null,
    val items: List<ButtonItem>,
)

private fun JsonObject.str(key: String, default: String = ""): String {
    val el = this[key]
    return if (el == null || el.isJsonNull) default else el.asString
}

private fun JsonObject.strOrNull(key: String): String? {
    val el = this[key]
    return if (el == null || el.isJsonNull) null else el.asString
}

private fun JsonObject.boolOf(key: String, default: Boolean = false): Boolean {
    val el = this[key]
    return if (el == null || el.isJsonNull) default else el.asBoolean
}

private fun JsonObject.nullableBool(key: String): Boolean? {
    val el = this[key]
    return if (el == null || el.isJsonNull) null else el.asBoolean
}

/** یک آیتم دکمه را چه از رجیستری عمومی (button_registry.py) و چه از پاسخ
 * /api/settings/menu-order با یک منطق یکسان می‌خواند. فیلدهای مخصوص منوی
 * اصلی (admin_only/togglable/enabled/break_before) در گروه‌های دیگر وجود
 * ندارند و مقدار پیش‌فرض بی‌ضرر می‌گیرند. */
private fun parseButtonItem(io: JsonObject): ButtonItem = ButtonItem(
    key = io.str("key"),
    label = io.str("label"),
    hasText = io.boolOf("has_text", true),
    hasStyle = io.boolOf("has_style", true),
    text = io.str("text", io.str("label")),
    style = io.str("style"),
    adminOnly = io.boolOf("admin_only", false),
    togglable = io.boolOf("togglable", false),
    enabled = io.boolOf("enabled", true),
    breakBefore = if (io.has("break_before")) io.nullableBool("break_before") else io.nullableBool("row_break_before"),
)

private fun parseRegistry(root: JsonObject): List<ButtonGroup> {
    val groupsEl = root["groups"]
    if (groupsEl == null || !groupsEl.isJsonArray) return emptyList()
    return groupsEl.asJsonArray.mapNotNull { g ->
        if (!g.isJsonObject) return@mapNotNull null
        val go = g.asJsonObject
        val items = (go["items"]?.takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray())
            .mapNotNull { it.takeIf { i -> i.isJsonObject }?.asJsonObject }
            .map { io -> parseButtonItem(io) }
        ButtonGroup(
            key = go.str("key"),
            label = go.str("label"),
            reorderable = go.boolOf("reorderable", false),
            supportsRowBreak = go.boolOf("supports_row_break", false),
            note = go.strOrNull("note"),
            items = items,
        )
    }
}

/** پاسخ GET /api/settings/menu-order یک آرایه‌ی مستقیم است (نه یک آبجکت با
 * "groups")؛ همان چیزی که پنل وب برای ساختن گروه «منوی اصلی ربات» می‌خواند. */
private fun parseMenuOrder(arr: JsonArray): List<ButtonItem> =
    arr.mapNotNull { it.takeIf { i -> i.isJsonObject }?.asJsonObject }.map { parseButtonItem(it) }

private fun buildMainMenuGroup(items: List<ButtonItem>): ButtonGroup = ButtonGroup(
    key = MAIN_MENU_GROUP_KEY,
    label = MAIN_MENU_LABEL,
    reorderable = true,
    supportsRowBreak = true,
    note = MAIN_MENU_NOTE,
    items = items,
)

private fun rowNumbers(group: ButtonGroup): List<Int> {
    var row = 0
    return group.items.mapIndexed { idx, item ->
        if (idx == 0 || item.breakBefore != false) row++
        row
    }
}

/**
 * صفحه‌ی native برای تب «دکمه‌های ربات»: رجیستری از button_registry.py را
 * می‌خواند و بدون هیچ صفحه‌ی وبی، متن/رنگ هر دکمه را قابل ویرایش و ترتیب هر
 * گروه را قابل جابه‌جایی (بالا/پایین) می‌کند. علاوه بر آن، درست مثل پنل وب،
 * گروه «منوی اصلی ربات» را جداگانه از GET /api/settings/menu-order می‌خواند
 * و به‌عنوان اولین گروه کنار بقیه نمایش می‌دهد (با تفاوت این‌که این گروه از
 * APIهای مخصوص خودش - menu-order/menu-layout - برای ذخیره استفاده می‌کند).
 * اگر فردا دکمه‌ی جدیدی به بات اضافه شود، همین که در رجیستری پایتون یا
 * MENU_BUTTON_META ظاهر شود، این‌جا هم خودکار می‌آید - هیچ نام دکمه‌ای این‌جا
 * هاردکد نیست.
 */
@Composable
fun ButtonRegistryScreen(tab: TabConfig, api: ApiClient, cache: LocalCacheRepository) {
    var groups by remember(tab.id) { mutableStateOf<List<ButtonGroup>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var busy by remember(tab.id) { mutableStateOf(false) }
    var editing by remember(tab.id) { mutableStateOf<Pair<String, ButtonItem>?>(null) }
    // مثل _customLayoutTouched در app.js: تا وقتی کاربر یک‌بار دکمه‌ی «ردیف
    // جدید/کنار قبلی» را نزده، ذخیره از /settings/menu-order (چیدمان قدیمیِ
    // تعداد ستون ثابت) استفاده می‌کند؛ بعد از اولین لمس، از /settings/menu-layout.
    var mainMenuLayoutTouched by remember(tab.id) { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val cacheKey = remember(tab.id) { LocalCacheRepository.keyForForm(tab.id) }
    val menuCacheKey = remember(tab.id) { LocalCacheRepository.keyForForm(tab.id) + "__main_menu" }

    suspend fun load() {
        val source = tab.source
        if (source == null) {
            error = "این تب پیکربندی نامعتبری دارد."
            loading = false
            return
        }
        val cachedRegistry = cache.load(cacheKey)?.takeIf { it.isJsonObject }?.let { parseRegistry(it.asJsonObject) }
        val cachedMenu = cache.load(menuCacheKey)?.takeIf { it.isJsonArray }?.let { parseMenuOrder(it.asJsonArray) }
        if (cachedRegistry != null || cachedMenu != null) {
            groups = (cachedMenu?.let { listOf(buildMainMenuGroup(it)) } ?: emptyList()) + (cachedRegistry ?: emptyList())
        }
        loading = groups.isEmpty()
        error = null

        var registryGroups = groups.filter { it.key != MAIN_MENU_GROUP_KEY }
        var menuItems = groups.firstOrNull { it.key == MAIN_MENU_GROUP_KEY }?.items
        var anyOk = false
        try {
            val res = api.get(source)
            if (res.isJsonObject) {
                registryGroups = parseRegistry(res.asJsonObject)
                cache.save(cacheKey, res)
                anyOk = true
            }
        } catch (e: Exception) {
            if (registryGroups.isEmpty() && menuItems == null) error = e.message ?: "خطا در بارگذاری دکمه‌ها"
        }
        try {
            val menuRes = api.get("/api/settings/menu-order")
            if (menuRes.isJsonArray) {
                menuItems = parseMenuOrder(menuRes.asJsonArray)
                cache.save(menuCacheKey, menuRes)
                anyOk = true
            }
        } catch (e: Exception) {
            // منوی اصلی جداگانه است؛ اگر فقط همین نگرفت، بقیه‌ی گروه‌ها بدون آن نمایش داده شوند.
        }
        groups = (menuItems?.let { listOf(buildMainMenuGroup(it)) } ?: emptyList()) + registryGroups
        if (anyOk) error = null
        loading = false
    }

    LaunchedEffect(tab.id) { load() }

    /** ذخیره‌ی کامل گروه «منوی اصلی» (ترتیب + فعال/غیرفعال + متن/رنگ + در
     * صورت لزوم چیدمان ردیف‌ها) - دقیقاً معادل saveButtonGroup('main_menu') در app.js. */
    suspend fun postMainMenu(group: ButtonGroup) {
        val orderArr = JsonArray()
        group.items.forEach { orderArr.add(it.key) }
        val buttonsArr = JsonArray()
        group.items.forEach { item ->
            if (item.togglable || item.hasText || item.hasStyle) {
                val b = JsonObject()
                b.addProperty("key", item.key)
                if (item.togglable) b.addProperty("enabled", item.enabled)
                if (item.hasText) b.addProperty("text", item.text)
                if (item.hasStyle) b.addProperty("style", item.style)
                buttonsArr.add(b)
            }
        }
        val body = JsonObject()
        body.add("order", orderArr)
        body.add("buttons", buttonsArr)
        if (mainMenuLayoutTouched) {
            val breaksArr = JsonArray()
            group.items.forEachIndexed { idx, item ->
                if (idx > 0 && item.breakBefore != false) breaksArr.add(item.key)
            }
            body.add("breaks", breaksArr)
            api.post("/api/settings/menu-layout", body.toString())
        } else {
            api.post("/api/settings/menu-order", body.toString())
        }
    }

    suspend fun saveItem(groupKey: String, key: String, text: String, style: String) {
        val group = groups.firstOrNull { it.key == groupKey } ?: return
        val updated = group.copy(items = group.items.map { if (it.key == key) it.copy(text = text, style = style) else it })
        busy = true
        try {
            if (groupKey == MAIN_MENU_GROUP_KEY) {
                postMainMenu(updated)
            } else {
                val body = JsonObject()
                body.addProperty("group", groupKey)
                body.addProperty("key", key)
                body.addProperty("text", text)
                body.addProperty("style", style)
                api.post("/api/buttons/item", body.toString())
            }
            groups = groups.map { if (it.key == groupKey) updated else it }
            snackbarHostState.showSnackbar("ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            busy = false
        }
    }

    suspend fun move(groupKey: String, index: Int, delta: Int) {
        val group = groups.firstOrNull { it.key == groupKey } ?: return
        val newIndex = index + delta
        if (newIndex < 0 || newIndex >= group.items.size) return
        val newItems = group.items.toMutableList()
        val tmp = newItems[index]
        newItems[index] = newItems[newIndex]
        newItems[newIndex] = tmp
        val updated = group.copy(items = newItems)
        groups = groups.map { if (it.key == groupKey) updated else it }
        busy = true
        try {
            if (groupKey == MAIN_MENU_GROUP_KEY) {
                postMainMenu(updated)
            } else {
                val body = JsonObject()
                body.addProperty("group", groupKey)
                val orderArr = JsonArray()
                newItems.forEach { orderArr.add(it.key) }
                body.add("order", orderArr)
                api.post("/api/buttons/order", body.toString())
            }
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره‌ی ترتیب؛ صفحه را تازه کن")
        } finally {
            busy = false
        }
    }

    /** فقط برای منوی اصلی: فعال/غیرفعال کردن یک دکمه. */
    suspend fun toggleEnabled(groupKey: String, key: String) {
        val group = groups.firstOrNull { it.key == groupKey } ?: return
        val updated = group.copy(items = group.items.map { if (it.key == key) it.copy(enabled = !it.enabled) else it })
        groups = groups.map { if (it.key == groupKey) updated else it }
        busy = true
        try {
            postMainMenu(updated)
            snackbarHostState.showSnackbar("ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            busy = false
        }
    }

    /** فقط برای منوی اصلی: مشخص می‌کند این دکمه کنار دکمه‌ی قبلی بماند یا
     * ردیف تازه‌ای شروع کند - دقیقاً همان منطق دکمه‌ی «کنار قبلی/ردیف جدید» در app.js. */
    suspend fun toggleRowBreak(groupKey: String, key: String) {
        val group = groups.firstOrNull { it.key == groupKey } ?: return
        val idx = group.items.indexOfFirst { it.key == key }
        if (idx <= 0) return
        val current = group.items[idx]
        val newBreak = if (current.breakBefore == false) true else false
        val updated = group.copy(items = group.items.mapIndexed { i, it -> if (i == idx) it.copy(breakBefore = newBreak) else it })
        groups = groups.map { if (it.key == groupKey) updated else it }
        mainMenuLayoutTouched = true
        busy = true
        try {
            postMainMenu(updated)
            snackbarHostState.showSnackbar("ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            busy = false
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                groups.isEmpty() && error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                groups.isEmpty() -> EmptyState(title = "دکمه‌ای برای نمایش نیست")
                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(groups) { group ->
                        val numbers = if (group.supportsRowBreak) rowNumbers(group) else emptyList()
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(group.label, style = MaterialTheme.typography.titleSmall)
                                group.note?.let {
                                    Spacer(Modifier.height(4.dp))
                                    Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(Modifier.height(8.dp))
                                group.items.forEachIndexed { index, item ->
                                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                        // ردیف اول: فقط شماره‌ی ردیف (در صورت وجود) + متن دکمه + سوییچ.
                                        // این ردیف عمداً شلوغ نیست تا متن فارسی جا برای شکسته‌شدن طبیعی داشته باشد.
                                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                                            if (group.supportsRowBreak) {
                                                Box(
                                                    Modifier
                                                        .padding(top = 2.dp, end = 8.dp)
                                                        .size(22.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                                    contentAlignment = Alignment.Center,
                                                ) {
                                                    Text(
                                                        "${numbers.getOrElse(index) { index + 1 }}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                            Column(Modifier.weight(1f)) {
                                                Text(
                                                    item.label + if (item.adminOnly) " (فقط ادمین)" else "",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                )
                                                if (item.hasText && item.text.isNotBlank() && item.text != item.label) {
                                                    Text(item.text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                if ((item.hasStyle && item.style.isNotBlank()) || (item.togglable && !item.enabled)) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        if (item.hasStyle && item.style.isNotBlank()) {
                                                            Text(
                                                                STYLE_CHOICES.firstOrNull { it.first == item.style }?.second ?: item.style,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            )
                                                        }
                                                        if (item.hasStyle && item.style.isNotBlank() && item.togglable && !item.enabled) {
                                                            Text(" · ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        }
                                                        if (item.togglable && !item.enabled) {
                                                            Text("غیرفعال", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                                        }
                                                    }
                                                }
                                            }
                                            if (item.togglable) {
                                                Switch(
                                                    checked = item.enabled,
                                                    onCheckedChange = { scope.launch { toggleEnabled(group.key, item.key) } },
                                                    enabled = !busy,
                                                )
                                            }
                                        }
                                        // ردیف دوم: کنترل‌های کوچک (چیدمان ردیف، جابه‌جایی، ویرایش) - همه آیکون‌ی و
                                        // جمع‌وجور، تا با متن ردیف اول تداخل نداشته باشند.
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 2.dp),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            if (group.supportsRowBreak && index > 0) {
                                                val joined = item.breakBefore == false
                                                IconButton(onClick = { scope.launch { toggleRowBreak(group.key, item.key) } }, enabled = !busy) {
                                                    Icon(
                                                        if (joined) Icons.Filled.Link else Icons.Filled.SubdirectoryArrowLeft,
                                                        contentDescription = if (joined) "کنار دکمه‌ی قبلی (لمس کن تا ردیف جدید شود)" else "ردیف جدید (لمس کن تا کنار قبلی بچسبد)",
                                                        tint = if (joined) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                            if (group.reorderable) {
                                                IconButton(onClick = { scope.launch { move(group.key, index, -1) } }, enabled = !busy && index > 0) {
                                                    Icon(Icons.Filled.ArrowUpward, contentDescription = "بالا")
                                                }
                                                IconButton(onClick = { scope.launch { move(group.key, index, 1) } }, enabled = !busy && index < group.items.lastIndex) {
                                                    Icon(Icons.Filled.ArrowDownward, contentDescription = "پایین")
                                                }
                                            }
                                            if (item.hasText || item.hasStyle) {
                                                IconButton(onClick = { editing = group.key to item }) {
                                                    Icon(Icons.Filled.Edit, contentDescription = "ویرایش")
                                                }
                                            }
                                        }
                                    }
                                    if (index != group.items.lastIndex) Divider(Modifier.padding(vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { (groupKey, item) ->
        var text by remember(item.key) { mutableStateOf(item.text) }
        var style by remember(item.key) { mutableStateOf(item.style) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(item.label) },
            text = {
                Column {
                    if (item.hasText) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            label = { Text("متن دکمه") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    if (item.hasStyle) {
                        Spacer(Modifier.height(12.dp))
                        Text("رنگ", style = MaterialTheme.typography.labelMedium)
                        Column {
                            STYLE_CHOICES.forEach { (value, label) ->
                                Row(
                                    Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    RadioButton(selected = style == value, onClick = { style = value })
                                    Text(label)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { saveItem(groupKey, item.key, text, style) }
                    editing = null
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("انصراف") } },
        )
    }
}
