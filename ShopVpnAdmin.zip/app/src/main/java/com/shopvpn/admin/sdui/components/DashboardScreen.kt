package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.*
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

private data class Metric(val key: String, val label: String, val icon: ImageVector, val color: Color, val format: (Double) -> String = { it.toLong().toString() })
private val METRICS = listOf(
    Metric("total_users", "کاربران کل", Icons.Filled.People, AccentCyan),
    Metric("new_users", "کاربران جدید", Icons.Filled.PersonAdd, StatusSuccess),
    Metric("active_configs", "کانفیگ فعال", Icons.Filled.Shield, BrandPrimary),
    Metric("open_tickets", "تیکت باز", Icons.Filled.SupportAgent, StatusWarning),
    Metric("conversion_rate", "نرخ تبدیل", Icons.Filled.TrendingUp, StatusInfo) { "${it.toInt()}٪" },
    Metric("repeat_customer_rate", "مشتری تکراری", Icons.Filled.Repeat, AccentPink) { "${it.toInt()}٪" },
)
private fun JsonObject.num(key: String): Double? = get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
private fun fmtToman(v: Double) = String.format("%,d", v.toLong()).replace(",", "٬") + " تومان"

@Composable
fun DashboardScreen(tab: TabConfig, api: ApiClient) {
    var stats by remember { mutableStateOf<JsonObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    suspend fun load() {
        loading = true; error = null
        try { val res = api.get(tab.source ?: "/api/dashboard"); stats = res.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject() }
        catch (e: Exception) { error = e.message ?: "خطا در دریافت آمار" }
        finally { loading = false }
    }
    LaunchedEffect(tab.id) { load() }
    when {
        loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) }
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("داشبورد در دسترس نیست"); Spacer(Modifier.height(10.dp)); Button({ scope.launch { load() } }) { Text("تلاش دوباره") } } }
        else -> {
            val s = stats ?: JsonObject(); val revenue = s.num("revenue") ?: 0.0; val change = s.num("revenue_change_pct")
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                BrandGradientCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text("مرکز کنترل", color = Color.White.copy(.70f), style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(5.dp)); Text("سلام، مدیر 👋", color = Color.White, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(16.dp)); Text("درآمد این بازه", color = Color.White.copy(.75f), style = MaterialTheme.typography.bodySmall)
                            Text(fmtToman(revenue), color = Color.White, style = MaterialTheme.typography.displaySmall)
                        }
                        Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(.12f)), Alignment.Center) { Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                    }
                    Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) {
                        if (change != null) StatusChip(if (change >= 0) "active" else "danger")
                        Spacer(Modifier.width(8.dp)); Text(if (change != null) "${"%.1f".format(kotlin.math.abs(change))}٪ نسبت به بازه قبل" else "آخرین آمار ثبت‌شده", color = Color.White.copy(.75f), style = MaterialTheme.typography.labelSmall)
                    }
                }

                SectionLabel("نمای کلی")
                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(350.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
                    items(METRICS) { metric -> MetricCard(metric, s.num(metric.key)) }
                }

                val wallet = s.num("wallet_total"); val aov = s.num("aov")
                if (wallet != null || aov != null) {
                    SectionLabel("مالی")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        wallet?.let { QuickValueCard("مجموع کیف‌پول", fmtToman(it), Icons.Filled.AccountBalanceWallet, AccentCyan, Modifier.weight(1f)) }
                        aov?.let { QuickValueCard("میانگین سفارش", fmtToman(it), Icons.Filled.ReceiptLong, AccentPink, Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable private fun MetricCard(m: Metric, value: Double?) {
    ElevatedAppCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
        NeonIconTile(m.icon, m.color); Spacer(Modifier.height(12.dp)); Text(value?.let(m.format) ?: "—", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(3.dp)); Text(m.label, style = MaterialTheme.typography.bodySmall, color = TextMuted)
    } }
}

@Composable private fun QuickValueCard(label: String, value: String, icon: ImageVector, color: Color, modifier: Modifier) {
    ElevatedAppCard(modifier) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { NeonIconTile(icon, color, Modifier.size(38.dp)); Spacer(Modifier.width(10.dp)); Column { Text(value, style = MaterialTheme.typography.titleSmall); Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted) } } }
}
