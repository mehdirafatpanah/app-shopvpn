package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.InitialsBadge
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.BgElevated2
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val POLL_MS = 4000L
private const val LIST_POLL_MS = 8000L

private data class Conversation(
    val userId: Int,
    val userName: String,
    val userUsername: String,
    val lastMessage: String,
    val lastSender: String,
    val unread: Int,
    val lockedBy: String?,
    val lockedForMe: Boolean,
)

private data class ChatMessage(val id: Int, val sender: String, val text: String, val createdAt: String)

private fun JsonObject.strOf(key: String): String = this[key]?.takeIf { !it.isJsonNull }?.asString ?: ""
private fun JsonObject.intOf(key: String): Int = this[key]?.takeIf { !it.isJsonNull && it.isJsonPrimitive }?.asInt ?: 0

private fun parseConversations(res: com.google.gson.JsonElement): List<Conversation> {
    if (!res.isJsonArray) return emptyList()
    return res.asJsonArray.mapNotNull { el ->
        if (!el.isJsonObject) return@mapNotNull null
        val o = el.asJsonObject
        Conversation(
            userId = o.intOf("user_id"),
            userName = o.strOf("user_name"),
            userUsername = o.strOf("user_username"),
            lastMessage = o.strOf("last_message"),
            lastSender = o.strOf("last_sender"),
            unread = o.intOf("unread"),
            lockedBy = o["locked_by"]?.takeIf { !it.isJsonNull }?.asString,
            lockedForMe = o["locked_for_me"]?.takeIf { !it.isJsonNull }?.asBoolean ?: false,
        )
    }
}

/**
 * تب «چت زنده»: لیست مکالمات + صفحه‌ی چت. چون ذاتاً رفت‌وبرگشتی/زنده است،
 * به‌جای وب‌ویو از polling روی همان /api/support/* استفاده می‌کند — کاملاً
 * native، بدون نیاز به هیچ صفحه‌ی وبی.
 */
@Composable
fun SupportScreen(tab: TabConfig, api: ApiClient) {
    var openChat by remember(tab.id) { mutableStateOf<Conversation?>(null) }
    val chat = openChat
    if (chat != null) {
        SupportChatScreen(conversation = chat, api = api, onBack = { openChat = null })
    } else {
        SupportConversationList(tab, api) { openChat = it }
    }
}

@Composable
private fun SupportConversationList(tab: TabConfig, api: ApiClient, onOpen: (Conversation) -> Unit) {
    var conversations by remember(tab.id) { mutableStateOf<List<Conversation>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        val source = tab.source ?: return
        try {
            val res = api.get(source)
            conversations = parseConversations(res)
            error = null
        } catch (e: Exception) {
            if (conversations.isEmpty()) error = e.message ?: "خطا در بارگذاری مکالمات"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) {
        load()
        while (isActive) {
            delay(LIST_POLL_MS)
            load()
        }
    }

    when {
        loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
            }
        }
        conversations.isEmpty() -> EmptyState(title = "مکالمه‌ای وجود ندارد")
        else -> LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(conversations, key = { it.userId }) { c ->
                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(c) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        InitialsBadge(c.userName.ifBlank { c.userUsername }.ifBlank { "?" })
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    c.userName.ifBlank { c.userUsername.ifBlank { "کاربر #${c.userId}" } },
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                if (c.lockedBy != null) {
                                    Spacer(Modifier.width(6.dp))
                                    Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(12.dp), tint = TextMuted)
                                }
                            }
                            Text(
                                (if (c.lastSender == "admin") "شما: " else "") + c.lastMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                                maxLines = 1,
                            )
                        }
                        if (c.unread > 0) {
                            Box(
                                Modifier.size(22.dp).background(StatusDanger, CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    if (c.unread > 9) "9+" else "${c.unread}",
                                    color = androidx.compose.ui.graphics.Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SupportChatScreen(conversation: Conversation, api: ApiClient, onBack: () -> Unit) {
    var messages by remember(conversation.userId) { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var lockedBy by remember(conversation.userId) { mutableStateOf(conversation.lockedBy) }
    var lockedForMe by remember(conversation.userId) { mutableStateOf(conversation.lockedForMe) }
    var input by remember(conversation.userId) { mutableStateOf("") }
    var sending by remember(conversation.userId) { mutableStateOf(false) }
    var loading by remember(conversation.userId) { mutableStateOf(true) }
    var error by remember(conversation.userId) { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    suspend fun poll(sinceId: Int) {
        try {
            val res = api.get("/api/support/${conversation.userId}/messages?since_id=$sinceId")
            if (res.isJsonObject) {
                val o = res.asJsonObject
                o["user"]?.takeIf { it.isJsonObject }?.asJsonObject?.let { u ->
                    lockedBy = u["locked_by"]?.takeIf { !it.isJsonNull }?.asString
                    lockedForMe = u["locked_for_me"]?.takeIf { !it.isJsonNull }?.asBoolean ?: false
                }
                val newOnes = (o["messages"]?.takeIf { it.isJsonArray }?.asJsonArray ?: com.google.gson.JsonArray())
                    .mapNotNull { m ->
                        if (!m.isJsonObject) return@mapNotNull null
                        val mo = m.asJsonObject
                        ChatMessage(mo.intOf("id"), mo.strOf("sender"), mo.strOf("message"), mo.strOf("created_at"))
                    }
                if (newOnes.isNotEmpty()) {
                    messages = (messages + newOnes).distinctBy { it.id }.sortedBy { it.id }
                }
                error = null
            }
        } catch (e: Exception) {
            if (messages.isEmpty()) error = e.message ?: "خطا در بارگذاری گفتگو"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(conversation.userId) {
        poll(0)
        while (isActive) {
            delay(POLL_MS)
            poll(messages.lastOrNull()?.id ?: 0)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    suspend fun send() {
        val text = input.trim()
        if (text.isEmpty()) return
        sending = true
        try {
            val body = JsonObject()
            body.addProperty("message", text)
            api.post("/api/support/${conversation.userId}/messages", body.toString())
            input = ""
            poll(messages.lastOrNull()?.id ?: 0)
        } catch (e: Exception) {
            error = e.message ?: "ارسال ناموفق بود"
        } finally {
            sending = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text(conversation.userName.ifBlank { conversation.userUsername.ifBlank { "کاربر #${conversation.userId}" } })
                    if (lockedBy != null) {
                        Text(
                            "در حال پاسخ‌دهی توسط $lockedBy",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                        )
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت") }
            },
        )

        Box(Modifier.weight(1f)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                messages.isEmpty() && error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(error!!) }
                messages.isEmpty() -> EmptyState(title = "هنوز پیامی نیست")
                else -> LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(messages, key = { it.id }) { m ->
                        val isAdmin = m.sender == "admin"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isAdmin) Arrangement.Start else Arrangement.End) {
                            Box(
                                Modifier
                                    .background(
                                        if (isAdmin) BrandPrimary else BgElevated2,
                                        RoundedCornerShape(14.dp),
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .fillMaxWidth(0.78f),
                            ) {
                                Text(
                                    m.text,
                                    color = if (isAdmin) androidx.compose.ui.graphics.Color.White else androidx.compose.ui.graphics.Color.Unspecified,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (lockedForMe) {
            Text(
                "این گفتگو در حال حاضر توسط ادمین دیگری در حال پاسخ‌دهی است.",
                color = StatusDanger,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("پیام...") },
                modifier = Modifier.weight(1f),
                maxLines = 4,
            )
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = { scope.launch { send() } }, enabled = !sending && input.isNotBlank()) {
                if (sending) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(Icons.Filled.Send, contentDescription = "ارسال")
            }
        }
    }
}
