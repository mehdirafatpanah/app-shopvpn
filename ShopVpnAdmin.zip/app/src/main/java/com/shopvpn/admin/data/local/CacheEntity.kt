package com.shopvpn.admin.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * یک جدول عمومیِ کلید-مقدار برای کش کردن هر پاسخ JSON که از سرور می‌آید
 * (پیکربندی SDUI، مقادیر تنظیمات، لیست هر تب و ...). به‌جای ساختن یک جدول
 * جدا برای هر نوع داده، همه‌چیز این‌جا زیر یک "cacheKey" ذخیره می‌شود؛ این
 * یعنی وقتی تب جدیدی از سمت پنل اضافه شود، نیازی به Migration دیتابیس نیست
 * — همان لحظه با یک کلید جدید (مثلاً "list_<tabId>") کش می‌شود.
 */
@Entity(tableName = "cache_entries")
data class CacheEntity(
    @PrimaryKey val cacheKey: String,
    val jsonPayload: String,
    val updatedAt: Long,
)
