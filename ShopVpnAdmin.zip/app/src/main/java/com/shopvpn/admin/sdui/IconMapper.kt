package com.shopvpn.admin.sdui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** آیکن‌های جدید سمت سرور فقط باید از همین اسم‌های شناخته‌شده استفاده کنند؛
 * هر اسم ناشناخته به یک آیکن پیش‌فرض بی‌خطر می‌افتد (نه کرش). */
fun iconFor(name: String): ImageVector = when (name) {
    "dashboard" -> Icons.Filled.Dashboard
    "receipt" -> Icons.Filled.Receipt
    "wallet" -> Icons.Filled.AccountBalanceWallet
    "people" -> Icons.Filled.People
    "box" -> Icons.Filled.Inventory2
    "map" -> Icons.Filled.Map
    "settings" -> Icons.Filled.Settings
    "discount" -> Icons.Filled.LocalOffer
    "ticket" -> Icons.Filled.SupportAgent
    else -> Icons.Filled.Circle
}
