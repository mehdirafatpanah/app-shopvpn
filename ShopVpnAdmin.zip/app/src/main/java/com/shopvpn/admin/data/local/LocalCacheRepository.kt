package com.shopvpn.admin.data.local

import android.content.Context
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * کش محلی روی SQLite (از طریق Room) برای پاسخ‌های JSON سرور. هدف این نیست
 * که جایگزین سرور شود؛ فقط باعث می‌شود:
 *  ۱) وقتی اینترنت لحظه‌ای قطع است یا سرور کند جواب می‌دهد، اپ به‌جای صفحه‌ی
 *     خطا، آخرین داده‌ی موجود را نشان دهد (مخصوصاً پیکربندی SDUI که اگر
 *     نگیرد کل اپ باز نمی‌شود).
 *  ۲) باز شدن اپ سریع‌تر حس شود (نمایش فوری کش، بعد به‌روزرسانی در پس‌زمینه).
 */
class LocalCacheRepository(context: Context) {
    private val dao = AppDatabase.getInstance(context).cacheDao()

    suspend fun save(key: String, json: JsonElement) = withContext(Dispatchers.IO) {
        dao.put(CacheEntity(cacheKey = key, jsonPayload = json.toString(), updatedAt = System.currentTimeMillis()))
    }

    suspend fun load(key: String): JsonElement? = withContext(Dispatchers.IO) {
        val row = dao.get(key) ?: return@withContext null
        try { JsonParser.parseString(row.jsonPayload) } catch (e: Exception) { null }
    }

    suspend fun lastUpdated(key: String): Long? = withContext(Dispatchers.IO) { dao.get(key)?.updatedAt }

    suspend fun clear(key: String) = withContext(Dispatchers.IO) { dao.delete(key) }

    suspend fun clearAll() = withContext(Dispatchers.IO) { dao.clearAll() }

    companion object {
        const val KEY_APP_CONFIG = "app_config"
        fun keyForList(tabId: String) = "list_$tabId"
        fun keyForForm(tabId: String) = "form_$tabId"
    }
}
