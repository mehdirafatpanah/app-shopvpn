package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.TextMuted
import com.shopvpn.admin.ui.theme.StrokeSubtle
import com.shopvpn.admin.ui.theme.AccentCyan
import kotlinx.coroutines.launch

private data class TicketRow(val id: Int, val user: String, val subject: String, val status: String, val updated: String)
private data class TicketMessage(val id: Int, val sender: String, val message: String, val createdAt: String)

private fun JsonObject.str(key: String) = this[key]?.takeIf { !it.isJsonNull }?.asString ?: ""
private fun JsonObject.int(key: String) = this[key]?.takeIf { !it.isJsonNull }?.asInt ?: 0

private fun extractArray(root: com.google.gson.JsonElement, key: String? = null): List<JsonObject> {
    val arr = when {
        root.isJsonArray -> root.asJsonArray
        root.isJsonObject && key != null && root.asJsonObject[key]?.isJsonArray == true -> root.asJsonObject[key].asJsonArray
        root.isJsonObject && root.asJsonObject["items"]?.isJsonArray == true -> root.asJsonObject["items"].asJsonArray
        root.isJsonObject && root.asJsonObject["results"]?.isJsonArray == true -> root.asJsonObject["results"].asJsonArray
        root.isJsonObject && root.asJsonObject["data"]?.isJsonArray == true -> root.asJsonObject["data"].asJsonArray
        else -> null
    } ?: return emptyList()
    return arr.mapNotNull { it.takeIf { x -> x.isJsonObject }?.asJsonObject }
}

@Composable
fun TicketScreen(tab: TabConfig, api: ApiClient, onDataChanged: () -> Unit = {}) {
    var selected by remember(tab.id) { mutableStateOf<Int?>(null) }
    if (selected != null) {
        TicketDetailScreen(selected!!, api, onDataChanged = onDataChanged) { selected = null }
    } else {
        TicketListScreen(tab, api) { selected = it }
    }
}

@Composable
private fun TicketListScreen(tab: TabConfig, api: ApiClient, onOpen: (Int) -> Unit) {
    var tickets by remember(tab.id) { mutableStateOf<List<TicketRow>>(emptyList()) }
    var query by remember(tab.id) { mutableStateOf("") }
    var status by remember(tab.id) { mutableStateOf("all") }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            val path = if (status == "all") "/api/tickets" else "/api/tickets?status=$status"
            tickets = extractArray(api.get(path)).map { o ->
                TicketRow(o.int("id"), o.str("username").ifBlank { o.str("user_id") }, o.str("subject"), o.str("status"), o.str("updated_at"))
            }
        } catch (e: Exception) { error = e.message ?: "خطا در دریافت تیکت‌ها" }
        finally { loading = false }
    }
    LaunchedEffect(tab.id, status) { load() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("جستجو در تیکت‌ها...") })
            IconButton(onClick = { scope.launch { load() } }) { Icon(Icons.Filled.Refresh, null) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to "همه", "open" to "باز", "answered" to "پاسخ‌داده‌شده", "closed" to "بسته").forEach { (v, label) ->
                FilterChip(selected = status == v, onClick = { status = v }, label = { Text(label) })
            }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(error!!, textAlign = TextAlign.Center); Button({ scope.launch { load() } }) { Text("تلاش دوباره") } } }
            else -> {
                val filtered = tickets.filter { query.isBlank() || it.subject.contains(query, true) || it.user.contains(query, true) || it.id.toString().contains(query) }
                if (filtered.isEmpty()) EmptyState(title = "تیکتی برای نمایش نیست")
                else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { t ->
                        ElevatedAppCard(Modifier.fillMaxWidth().clickable { onOpen(t.id) }) {
                            Column(Modifier.padding(14.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("#${t.id}  ${t.subject}", style = MaterialTheme.typography.titleSmall)
                                    StatusChip(t.status)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text("کاربر: ${t.user}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                Text(t.updated, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TicketDetailScreen(ticketId: Int, api: ApiClient, onDataChanged: () -> Unit = {}, onBack: () -> Unit) {
    var ticket by remember(ticketId) { mutableStateOf<JsonObject?>(null) }
    var messages by remember(ticketId) { mutableStateOf<List<TicketMessage>>(emptyList()) }
    var input by remember(ticketId) { mutableStateOf("") }
    var loading by remember(ticketId) { mutableStateOf(true) }
    var busy by remember(ticketId) { mutableStateOf(false) }
    var error by remember(ticketId) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            val root = api.get("/api/tickets/$ticketId/messages")
            if (!root.isJsonObject) throw IllegalStateException("پاسخ نامعتبر سرور")
            val o = root.asJsonObject
            ticket = o["ticket"]?.takeIf { it.isJsonObject }?.asJsonObject
            messages = extractArray(o, "messages").map { m -> TicketMessage(m.int("id"), m.str("sender"), m.str("message"), m.str("created_at")) }
        } catch (e: Exception) { error = e.message ?: "خطا در دریافت تیکت" }
        finally { loading = false }
    }
    LaunchedEffect(ticketId) { load() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "بازگشت") }
            Column(Modifier.weight(1f)) {
                Text(ticket?.str("subject")?.ifBlank { "تیکت #$ticketId" } ?: "تیکت #$ticketId", style = MaterialTheme.typography.titleMedium)
                Text("#${ticketId}  •  ${ticket?.str("status") ?: "در حال بارگذاری"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            IconButton(onClick = { scope.launch { load() } }) { Icon(Icons.Filled.Refresh, "تازه‌سازی") }
        }
        HorizontalDivider(color = StrokeSubtle)
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(error!!, textAlign = TextAlign.Center); Spacer(Modifier.height(10.dp)); Button({ scope.launch { load() } }) { Text("تلاش دوباره") } } }
            else -> {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(messages, key = { it.id }) { m ->
                        val isAdmin = m.sender == "admin"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isAdmin) Arrangement.Start else Arrangement.End) {
                            ElevatedAppCard(Modifier.fillMaxWidth(.88f)) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (isAdmin) "پشتیبانی" else "کاربر", color = if (isAdmin) BrandPrimary else AccentCyan, style = MaterialTheme.typography.labelMedium)
                                        Spacer(Modifier.weight(1f)); Text(m.createdAt, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    }
                                    Spacer(Modifier.height(5.dp)); Text(m.message, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
                if (ticket?.str("status") != "closed") {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), minLines = 1, maxLines = 4, placeholder = { Text("پاسخ را بنویس...") })
                        Spacer(Modifier.width(6.dp))
                        FilledIconButton(enabled = !busy && input.isNotBlank(), onClick = {
                            scope.launch {
                                busy = true
                                try { val body = JsonObject(); body.addProperty("message", input.trim()); api.post("/api/tickets/$ticketId/reply", body.toString()); input = ""; load() }
                                catch (e: Exception) { error = e.message }
                                finally { busy = false }
                            }
                        }) { Icon(Icons.Filled.Send, "ارسال") }
                    }
                    OutlinedButton(enabled = !busy, onClick = {
                        scope.launch { busy = true; try { api.post("/api/tickets/$ticketId/close"); load(); onDataChanged() } catch (e: Exception) { error = e.message } finally { busy = false } }
                    }, colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger), modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) { Text("بستن تیکت") }
                }
            }
        }
    }
}
