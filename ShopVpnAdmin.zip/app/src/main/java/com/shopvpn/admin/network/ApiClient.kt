package com.shopvpn.admin.network

import com.google.gson.JsonElement
import com.google.gson.JsonParser
import com.shopvpn.admin.data.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : Exception(message)

/**
 * کلاینت عمومی HTTP که مسیرها را دینامیک از پیکربندی سرور (SDUI) می‌گیرد،
 * نه از یک اینترفیس Retrofit ثابت — چون خودِ تب‌ها و اندپوینت‌هایشان می‌توانند
 * بدون آپدیت اپ عوض شوند.
 */
class ApiClient(private val session: SessionManager) {

    private val client: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .addInterceptor { chain ->
                val builder = chain.request().newBuilder()
                session.token?.let { builder.addHeader("Authorization", "Bearer $it") }
                chain.proceed(builder.build())
            }
            .build()
    }

    private fun fullUrl(path: String): String {
        val base = session.baseUrl?.trimEnd('/') ?: throw IllegalStateException("سرور تنظیم نشده")
        return if (path.startsWith("http")) path else base + (if (path.startsWith("/")) path else "/$path")
    }

    suspend fun get(path: String): JsonElement = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(fullUrl(path)).get().build()
        execute(request)
    }

    suspend fun post(path: String, bodyJson: String = "{}"): JsonElement = withContext(Dispatchers.IO) {
        val body = bodyJson.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(fullUrl(path)).post(body).build()
        execute(request)
    }

    suspend fun delete(path: String, bodyJson: String? = null): JsonElement = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(fullUrl(path))
        builder.delete(bodyJson?.toRequestBody("application/json; charset=utf-8".toMediaType()))
        execute(builder.build())
    }

    private fun execute(request: Request): JsonElement {
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val parsed: JsonElement = if (text.isNotBlank()) {
                try { JsonParser.parseString(text) } catch (e: Exception) { com.google.gson.JsonObject() }
            } else com.google.gson.JsonObject()
            if (!response.isSuccessful) {
                val detail = if (parsed.isJsonObject && parsed.asJsonObject.has("detail")) {
                    parsed.asJsonObject.get("detail").asString
                } else "خطای سرور (${response.code})"
                throw ApiException(response.code, detail)
            }
            return parsed
        }
    }

    /** بررسی سریع اتصال: تلاش برای گرفتن /api/me. */
    suspend fun testConnection(): Boolean = try {
        get("/api/me")
        true
    } catch (e: Exception) {
        false
    }
}

class NetworkUnavailableException : IOException("اتصال به سرور برقرار نشد. آدرس و اینترنت را بررسی کنید.")
