package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.ActionConfig
import com.shopvpn.admin.data.model.FieldConfig
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.InitialsBadge
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import kotlinx.coroutines.launch

private fun JsonObject.stringOf(key: String): String {
    if (!has(key) || this[key].isJsonNull) return ""
    val el = this[key]
    return if (el.isJsonPrimitive) el.asString else el.toString()
}

private fun ActionConfig.isVisibleFor(item: JsonObject): Boolean =
    visible_if_field == null || item.stringOf(visible_if_field).equals(visible_if_value ?: "", ignoreCase = true)

private fun extractItems(root: JsonElement): List<JsonObject> = when {
    root.isJsonArray -> root.asJsonArray.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    root.isJsonObject && root.asJsonObject.has("items") && root.asJsonObject["items"].isJsonArray ->
        (root.asJsonObject["items"] as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    root.isJsonObject && root.asJsonObject.has("results") && root.asJsonObject["results"].isJsonArray ->
        (root.asJsonObject["results"] as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    root.isJsonObject && root.asJsonObject.has("data") && root.asJsonObject["data"].isJsonArray ->
        (root.asJsonObject["data"] as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    else -> emptyList()
}

private fun JsonElement.intOrNull(): Int? =
    if (isJsonPrimitive && asJsonPrimitive.isNumber) asInt else null

/**
 * برخی اندپوینت‌ها (مثل /api/users) صفحه‌بندی واقعی سمت سرور دارند و
 * {items, total, page, limit} برمی‌گردانند - دقیقاً همان چیزی که پنل وب با
 * جستجوی سروری + pager صفحه‌به‌صفحه از آن استفاده می‌کند. اپ قبلاً فقط
 * همان صفحه‌ی اول (۲۵ کاربر) را می‌گرفت و total/page/limit را نادیده
 * می‌گرفت، پس با هر تعداد کاربر بیشتر از ۲۵ تا، جستجو/اسکرول عملاً کار
 * نمی‌کرد. اینجا این فیلدها را هم می‌خوانیم تا لود بیشتر (infinite scroll)
 * و جستجوی سمت سرور ممکن شود.
 */
private data class PagedResult(val items: List<JsonObject>, val total: Int?, val limit: Int?, val page: Int)

private fun extractPaged(root: JsonElement, requestedPage: Int): PagedResult {
    val items = extractItems(root)
    if (root.isJsonObject) {
        val obj = root.asJsonObject
        val total = obj["total"]?.intOrNull()
        val limit = obj["limit"]?.intOrNull()
        val page = obj["page"]?.intOrNull() ?: requestedPage
        return PagedResult(items, total, limit, page)
    }
    return PagedResult(items, null, null, requestedPage)
}

@Composable
fun ListScreen(tab: TabConfig, api: ApiClient) {
    var items by remember(tab.id) { mutableStateOf<List<JsonObject>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var loadingMore by remember(tab.id) { mutableStateOf(false) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var query by remember(tab.id) { mutableStateOf("") }
    var activeFilters by remember(tab.id) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var openDetailId by remember(tab.id) { mutableStateOf<String?>(null) }
    var showCreateDialog by remember(tab.id) { mutableStateOf(false) }
    var showPanelWizard by remember(tab.id) { mutableStateOf(false) }
    var editingItem by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var configBankItem by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    // برای اندپوینت‌های صفحه‌بندی‌شده (مثل /api/users که ۲۵تا ۲۵تا برمی‌گرداند):
    // page/currentTotal همون چیزیه که سرور برگردونده، تا هم لود بیشتر با اسکرول
    // ممکن بشه و هم بشه فهمید آیا آیتم بیشتری برای گرفتن هست یا نه.
    var currentPage by remember(tab.id) { mutableStateOf(1) }
    var currentTotal by remember(tab.id) { mutableStateOf<Int?>(null) }
    val hasMore by remember(tab.id) { derivedStateOf { val t = currentTotal; t != null && items.size < t } }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    suspend fun load(reset: Boolean = true) {
        if (reset) { loading = true; currentPage = 1 } else { loadingMore = true }
        error = null
        try {
            val base = tab.source ?: return
            // فیلترهای فعال (مثلاً وضعیت سفارش) و متن جستجو (وقتی تب از جستجوی
            // سروری پشتیبانی کند، مثل /api/users?q=...) باید به سرور فرستاده
            // بشن، نه فقط روی همون یک صفحه‌ای که قبلاً گرفته شده فیلتر محلی
            // بخوره — وگرنه با بیشتر از یک صفحه کاربر/آیتم، جستجو و اسکرول
            // عملاً کاری نمی‌کردند (فقط همون صفحه‌ی اول قابل دیدن بود).
            val params = activeFilters.filterValues { it != "all" }.toMutableMap()
            if (tab.search && query.isNotBlank()) params["q"] = query
            val targetPage = if (reset) 1 else currentPage + 1
            params["page"] = targetPage.toString()
            val url = if (params.isEmpty()) base else {
                val sep = if (base.contains("?")) "&" else "?"
                base + sep + params.entries.joinToString("&") { (k, v) ->
                    "${java.net.URLEncoder.encode(k, "UTF-8")}=${java.net.URLEncoder.encode(v, "UTF-8")}"
                }
            }
            val res = api.get(url)
            val paged = extractPaged(res, targetPage)
            items = if (reset) paged.items else items + paged.items
            currentTotal = paged.total
            currentPage = paged.page
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری"
        } finally {
            loading = false
            loadingMore = false
        }
    }

    // بارگذاری اولیه + هر بار که فیلتر عوض بشه فوری، و هر بار که متن جستجو
    // عوض بشه با کمی تاخیر (debounce) تا هر حرف باعث یک درخواست جدا به سرور نشه.
    LaunchedEffect(tab.id, activeFilters, query) {
        if (tab.search && query.isNotBlank()) kotlinx.coroutines.delay(400)
        load(reset = true)
    }

    // اسکرول به نزدیکی انتهای لیست = لود صفحه‌ی بعدی (فقط وقتی سرور گفته باشه
    // آیتم بیشتری هست، یعنی currentTotal بزرگتر از تعداد آیتم‌های لود شده).
    LaunchedEffect(tab.id, listState) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .collect { lastVisible ->
                if (lastVisible != null && lastVisible >= items.size - 3 && hasMore && !loading && !loadingMore) {
                    load(reset = false)
                }
            }
    }

    val filtered = items
        .filter { obj -> query.isBlank() || tab.fields.any { f -> obj.stringOf(f.key).contains(query, ignoreCase = true) } }
        .filter { obj -> activeFilters.all { (k, v) -> v == "all" || obj.stringOf(k).equals(v, ignoreCase = true) } }

    Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (tab.search) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    placeholder = { Text("جستجو در ${tab.title}...") },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
            IconButton(onClick = { scope.launch { load(reset = true) } }) {
                Icon(Icons.Filled.Refresh, contentDescription = "تازه‌سازی")
            }
        }

        if (tab.filters.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                tab.filters.forEach { filter ->
                    val current = activeFilters[filter.key] ?: "all"
                    val options = listOf("all" to "همه") + filter.options.map { it to it }
                    options.forEach { (value, label) ->
                        FilterChip(
                            selected = current == value,
                            onClick = {
                                activeFilters = activeFilters + (filter.key to value)
                            },
                            label = { Text(label) },
                        )
                    }
                }
            }
        }

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                    Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            filtered.isEmpty() -> EmptyState(
                title = "چیزی برای نمایش نیست",
                subtitle = if (query.isNotBlank()) "نتیجه‌ای برای «$query» پیدا نشد" else null,
                icon = Icons.Filled.Inbox,
            )
            else -> LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(filtered) { item ->
                    ItemCard(
                        item = item,
                        fields = tab.fields,
                        actions = tab.actions.filter { it.isVisibleFor(item) },
                        idField = tab.item_id_field ?: "id",
                        busyAction = busyAction,
                        clickable = tab.detail_source != null || tab.edit_form != null,
                        onOpenDetail = {
                            if (tab.detail_source != null) openDetailId = it
                            else if (tab.edit_form != null) editingItem = item
                        },
                        onAction = { action, idValue ->
                            scope.launch {
                                busyAction = action.id + idValue
                                try {
                                    val endpoint = action.endpoint.replace("{id}", idValue).replace("{tg_id}", idValue)
                                    if (action.method.equals("DELETE", true)) api.delete(endpoint)
                                    else api.post(endpoint)
                                    load()
                                } catch (e: Exception) {
                                    error = e.message
                                } finally {
                                    busyAction = null
                                }
                            }
                        },
                        onToggle = { field, idValue ->
                            scope.launch {
                                try {
                                    api.post(field.toggle_endpoint!!.replace("{id}", idValue).replace("{tg_id}", idValue))
                                    load()
                                } catch (e: Exception) {
                                    error = e.message
                                }
                            }
                        },
                        configBankEnabled = tab.config_bank_source != null,
                        onOpenConfigBank = { configBankItem = item },
                    )
                }
                if (currentTotal != null) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), Alignment.Center) {
                            if (loadingMore) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            else Text(
                                "${items.size} از ${currentTotal}",
                                style = MaterialTheme.typography.bodySmall,
                                color = androidx.compose.ui.graphics.Color.Gray,
                            )
                        }
                    }
                }
            }
        }
    }

    if (tab.create_form != null) {
        FloatingActionButton(
            onClick = { if (tab.id == "panels") showPanelWizard = true else showCreateDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) { Icon(Icons.Filled.Add, contentDescription = "افزودن") }
    }
    }

    if (openDetailId != null && tab.detail_source != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { openDetailId = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(modifier = Modifier.fillMaxSize()) {
                if (tab.detail_type == "user") {
                    UserDetailScreen(
                        title = tab.title,
                        detailSourceTemplate = tab.detail_source!!,
                        servicesSourceTemplate = tab.services_source,
                        bankConfigsSourceTemplate = tab.bank_configs_source,
                        walletEndpointTemplate = tab.wallet_endpoint,
                        messageEndpointTemplate = tab.message_endpoint,
                        idValue = openDetailId!!,
                        actions = tab.actions,
                        api = api,
                        onClose = { openDetailId = null },
                    )
                } else {
                    DetailScreen(
                        title = tab.title,
                        detailSourceTemplate = tab.detail_source!!,
                        idValue = openDetailId!!,
                        actions = tab.actions,
                        api = api,
                        receiptSourceTemplate = tab.receipt_source,
                        onClose = { openDetailId = null },
                    )
                }
            }
        }
    }

    if (showCreateDialog && tab.create_form != null) {
        CreateEditFormDialog(
            config = tab.create_form,
            api = api,
            onDismiss = { showCreateDialog = false },
            onSaved = { showCreateDialog = false; scope.launch { load() } },
        )
    }

    if (showPanelWizard) {
        PanelWizardDialog(
            api = api,
            onDismiss = { showPanelWizard = false },
            onSaved = { showPanelWizard = false; scope.launch { load() } },
        )
    }

    if (editingItem != null && tab.edit_form != null) {
        val item = editingItem!!
        val idValue = item.stringOf(tab.item_id_field ?: "id")
        val initial = item.entrySet().associate { (k, v) ->
            // فیلدهای غیر-primitive (مثل "config" آبجکت درگاه سفارشی) برای
            // فیلدهای نوع "json" به‌صورت رشته‌ی JSON خودشان پیش‌فرض می‌شوند؛
            // در غیر این صورت رشته‌ی خالی می‌ماند تا کاربر کامل تایپ کند.
            k to (if (v.isJsonNull) "" else if (v.isJsonPrimitive) v.asString else v.toString())
        }
        CreateEditFormDialog(
            config = tab.edit_form,
            api = api,
            idValue = idValue,
            initialValues = initial,
            onDismiss = { editingItem = null },
            onSaved = { editingItem = null; scope.launch { load() } },
        )
    }
    if (configBankItem != null && tab.config_bank_source != null) {
        val idValue = configBankItem!!.stringOf(tab.item_id_field ?: "id")
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { configBankItem = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(modifier = Modifier.fillMaxSize()) {
                ConfigBankScreen(
                    sourceTemplate = tab.config_bank_source!!,
                    idValue = idValue,
                    api = api,
                    onClose = { configBankItem = null },
                )
            }
        }
    }
}

@Composable
private fun ItemCard(
    item: JsonObject,
    fields: List<FieldConfig>,
    actions: List<ActionConfig>,
    idField: String,
    busyAction: String?,
    clickable: Boolean,
    onOpenDetail: (String) -> Unit,
    onAction: (ActionConfig, String) -> Unit,
    onToggle: (FieldConfig, String) -> Unit,
    configBankEnabled: Boolean = false,
    onOpenConfigBank: () -> Unit = {},
) {
    val idValue = item.stringOf(idField)
    var showConfirm by remember { mutableStateOf<ActionConfig?>(null) }
    val titleField = fields.firstOrNull { it.type == "title" }
    val badgeFields = fields.filter { it.type == "badge" }
    val otherFields = fields.filter { it != titleField && it.type != "badge" && it.type != "toggle" }
    val toggleFields = fields.filter { it.type == "toggle" }

    ElevatedAppCard(
        modifier = Modifier.fillMaxWidth().let {
            if (clickable) it.clickable { onOpenDetail(idValue) } else it
        },
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (titleField != null) {
                    InitialsBadge(item.stringOf(titleField.key).ifBlank { "#" })
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    if (titleField != null) {
                        Text(item.stringOf(titleField.key), style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    }
                    if (otherFields.isNotEmpty()) {
                        Text(
                            otherFields.joinToString("  ·  ") { f ->
                                val v = item.stringOf(f.key)
                                if (f.type == "currency") "${f.label}: $v تومان" else "${f.label}: $v"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                        )
                    }
                }
                if (badgeFields.size == 1) StatusChip(item.stringOf(badgeFields.first().key))
            }

            if (badgeFields.size > 1) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    badgeFields.forEach { StatusChip(item.stringOf(it.key)) }
                }
            }

            toggleFields.forEach { field ->
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(field.label, style = MaterialTheme.typography.bodySmall)
                    val v = item.stringOf(field.key)
                    Switch(checked = v == "true" || v == "1", onCheckedChange = { onToggle(field, idValue) })
                }
            }

            if (configBankEnabled && item.stringOf("is_auto_provision") !in listOf("true", "1")) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onOpenConfigBank) { Text("بانک کانفیگ") }
            }

            if (actions.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    actions.forEach { action ->
                        val isBusy = busyAction == action.id + idValue
                        val color = when (action.style) {
                            "success" -> StatusSuccess
                            "danger" -> StatusDanger
                            else -> BrandPrimary
                        }
                        Button(
                            onClick = { if (action.confirm) showConfirm = action else onAction(action, idValue) },
                            enabled = !isBusy,
                            shape = MaterialTheme.shapes.small,
                            colors = ButtonDefaults.buttonColors(containerColor = color),
                        ) {
                            if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            else Text(action.label)
                        }
                    }
                }
            }
        }
    }

    showConfirm?.let { action ->
        AlertDialog(
            onDismissRequest = { showConfirm = null },
            title = { Text("مطمئنی؟") },
            text = { Text("${action.label} برای این مورد اجرا شود؟") },
            confirmButton = {
                TextButton(onClick = { onAction(action, idValue); showConfirm = null }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = null }) { Text("انصراف") } },
        )
    }
}
