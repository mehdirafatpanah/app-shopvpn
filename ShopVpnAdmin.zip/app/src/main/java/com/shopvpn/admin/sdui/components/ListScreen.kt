package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.ActionConfig
import com.shopvpn.admin.data.model.FieldConfig
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import kotlinx.coroutines.launch

private fun JsonObject.stringOf(key: String): String {
    if (!has(key) || this[key].isJsonNull) return ""
    val el = this[key]
    return if (el.isJsonPrimitive) el.asString else el.toString()
}

private fun extractItems(root: JsonElement): List<JsonObject> = when {
    root.isJsonArray -> root.asJsonArray.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    root.isJsonObject && root.asJsonObject.has("items") && root.asJsonObject["items"].isJsonArray ->
        (root.asJsonObject["items"] as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    root.isJsonObject && root.asJsonObject.has("results") && root.asJsonObject["results"].isJsonArray ->
        (root.asJsonObject["results"] as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
    else -> emptyList()
}

@Composable
fun ListScreen(tab: TabConfig, api: ApiClient) {
    var items by remember(tab.id) { mutableStateOf<List<JsonObject>>(emptyList()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var query by remember(tab.id) { mutableStateOf("") }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var openDetailId by remember(tab.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(tab.source ?: return)
            items = extractItems(res)
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    val filtered = if (query.isBlank()) items else items.filter { obj ->
        tab.fields.any { f -> obj.stringOf(f.key).contains(query, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (tab.search) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text("جستجو در ${tab.title}...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
        }

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                    Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("چیزی برای نمایش نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(filtered) { item ->
                    ItemCard(
                        item = item,
                        fields = tab.fields,
                        actions = tab.actions,
                        idField = tab.item_id_field ?: "id",
                        busyAction = busyAction,
                        clickable = tab.detail_source != null,
                        onOpenDetail = { openDetailId = it },
                        onAction = { action, idValue ->
                            scope.launch {
                                busyAction = action.id + idValue
                                try {
                                    val endpoint = action.endpoint.replace("{id}", idValue)
                                    if (action.method.equals("DELETE", true)) api.delete(endpoint)
                                    else api.post(endpoint)
                                    load()
                                } catch (e: Exception) {
                                    error = e.message
                                } finally {
                                    busyAction = null
                                }
                            }
                        },
                        onToggle = { field, idValue ->
                            scope.launch {
                                try {
                                    api.post(field.toggle_endpoint!!.replace("{id}", idValue))
                                    load()
                                } catch (e: Exception) {
                                    error = e.message
                                }
                            }
                        },
                    )
                }
            }
        }
    }

    if (openDetailId != null && tab.detail_source != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { openDetailId = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(modifier = Modifier.fillMaxSize()) {
                DetailScreen(
                    title = tab.title,
                    detailSourceTemplate = tab.detail_source!!,
                    idValue = openDetailId!!,
                    actions = tab.actions,
                    api = api,
                    onClose = { openDetailId = null },
                )
            }
        }
    }
}

@Composable
private fun ItemCard(
    item: JsonObject,
    fields: List<FieldConfig>,
    actions: List<ActionConfig>,
    idField: String,
    busyAction: String?,
    clickable: Boolean,
    onOpenDetail: (String) -> Unit,
    onAction: (ActionConfig, String) -> Unit,
    onToggle: (FieldConfig, String) -> Unit,
) {
    val idValue = item.stringOf(idField)
    var showConfirm by remember { mutableStateOf<ActionConfig?>(null) }

    Card(
        modifier = Modifier.fillMaxWidth().let {
            if (clickable) it.clickable { onOpenDetail(idValue) } else it
        },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            fields.forEach { field ->
                val value = item.stringOf(field.key)
                when (field.type) {
                    "title" -> Text(value, style = MaterialTheme.typography.titleMedium)
                    "toggle" -> Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(field.label, style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = value == "true" || value == "1",
                            onCheckedChange = { onToggle(field, idValue) },
                        )
                    }
                    "badge" -> AssistChip(onClick = {}, label = { Text(value) })
                    "currency" -> Text(
                        "${field.label}: $value",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                    else -> Text(
                        "${field.label}: $value",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(2.dp))
            }

            if (actions.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    actions.forEach { action ->
                        val isBusy = busyAction == action.id + idValue
                        val color = when (action.style) {
                            "success" -> MaterialTheme.colorScheme.secondary
                            "danger" -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.primary
                        }
                        Button(
                            onClick = { if (action.confirm) showConfirm = action else onAction(action, idValue) },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = color),
                        ) {
                            if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            else Text(action.label)
                        }
                    }
                }
            }
        }
    }

    showConfirm?.let { action ->
        AlertDialog(
            onDismissRequest = { showConfirm = null },
            title = { Text("مطمئنی؟") },
            text = { Text("${action.label} برای این مورد اجرا شود؟") },
            confirmButton = {
                TextButton(onClick = { onAction(action, idValue); showConfirm = null }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = null }) { Text("انصراف") } },
        )
    }
}
