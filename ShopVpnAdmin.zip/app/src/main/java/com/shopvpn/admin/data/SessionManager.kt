package com.shopvpn.admin.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * آدرس سرور و توکن دسترسی (PAT) را با EncryptedSharedPreferences (پشتیبان
 * Android Keystore) روی گوشی نگه می‌دارد. هیچ‌کدام از این دو هیچ‌وقت
 * جای دیگری لاگ یا ارسال نمی‌شوند مگر به همان سرور خودِ کاربر.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "shopvpn_admin_session",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    var baseUrl: String?
        get() = prefs.getString(KEY_BASE_URL, null)
        set(value) = prefs.edit().putString(KEY_BASE_URL, value?.trimEnd('/')).apply()

    var token: String?
        get() = prefs.getString(KEY_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    var biometricLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC, false)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC, value).apply()

    // پیش‌فرض روشن؛ کاربر از تنظیمات می‌تونه به تیره سوییچ کنه — نگاه کن به
    // ThemeController در ui/theme/Color.kt که این مقدار رو در onCreate می‌خونه.
    var darkModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_DARK_MODE, value).apply()

    // شناسه‌ی تب‌هایی که کاربر نوتیف‌شون رو خاموش کرده (خالی یعنی همه فعالن).
    // فیلتر واقعی توی PushService انجام می‌شه؛ اگه سرور دسته‌بندی (category) رو
    // توی data payload نفرسته، این تنظیم بی‌اثره و همه‌چیز مثل قبل نشون داده می‌شه.
    //
    // عمداً به‌جای putStringSet/getStringSet از یک رشته‌ی جدا‌شده با کاما استفاده
    // می‌کنیم: EncryptedSharedPreferences (به‌خصوص نسخه‌های alpha کتابخانه‌ی
    // androidx.security.crypto که این پروژه استفاده می‌کنه) با نوع StringSet
    // مشکل شناخته‌شده‌ی پایداری/رمزگشایی داره - از جمله موقعی که ست خالی می‌شه
    // (یعنی وقتی آخرین دسته‌ی غیرفعال دوباره فعال میشه) یا بعد از ری‌استارت پروسه.
    // نتیجه‌ی عملیش دقیقاً همون چیزیه که کاربر گزارش کرده: خاموش‌کردن یه اعلان
    // موقتاً جواب میده ولی به محض این‌که مقدار دوباره از دیسک خونده بشه (باز
    // کردن دوباره‌ی اپ، یا حتی گاهی همون لحظه) انگار هیچ‌وقت خاموش نشده. رشته‌ی
    // ساده از این کلاس باگ‌ها کاملاً در امانه.
    var disabledNotificationCategories: Set<String>
        get() = prefs.getString(KEY_DISABLED_NOTIF_CATS, "")
            .orEmpty()
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
        set(value) = prefs.edit().putString(KEY_DISABLED_NOTIF_CATS, value.joinToString(",")).apply()

    fun isNotificationCategoryEnabled(categoryId: String): Boolean =
        categoryId !in disabledNotificationCategories

    fun setNotificationCategoryEnabled(categoryId: String, enabled: Boolean) {
        val current = disabledNotificationCategories.toMutableSet()
        if (enabled) current.remove(categoryId) else current.add(categoryId)
        disabledNotificationCategories = current
    }

    // یک‌بار پرسیدن کافیه؛ اگه کاربر رد کرد، اندروید دیگه دیالوگ سیستمی رو
    // دوباره نشون نمی‌ده (فقط از تنظیمات خودِ اپ قابل تغییره) — پس دفعه‌ی بعد
    // باید مستقیم کاربر رو به صفحه‌ی تنظیمات اپ بفرستیم، نه دوباره launch() بزنیم
    // که سایلنت هیچ اتفاقی نمی‌افته و کاربر گیج می‌مونه.
    var notifPermissionAsked: Boolean
        get() = prefs.getBoolean(KEY_NOTIF_ASKED, false)
        set(value) = prefs.edit().putBoolean(KEY_NOTIF_ASKED, value).apply()

    // مشابه بالا برای معافیت از بهینه‌سازی باتری — فقط یک‌بار خودکار پرسیده
    // می‌شه تا هر بار باز کردن اپ مزاحم کاربر نشه.
    var batteryOptimizationAsked: Boolean
        get() = prefs.getBoolean(KEY_BATTERY_ASKED, false)
        set(value) = prefs.edit().putBoolean(KEY_BATTERY_ASKED, value).apply()

    val isConnected: Boolean
        get() = !baseUrl.isNullOrBlank() && !token.isNullOrBlank()

    fun clear() {
        prefs.edit().remove(KEY_BASE_URL).remove(KEY_TOKEN).apply()
    }

    companion object {
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_TOKEN = "token"
        private const val KEY_BIOMETRIC = "biometric_lock"
        private const val KEY_DARK_MODE = "dark_mode_enabled"
        private const val KEY_DISABLED_NOTIF_CATS = "disabled_notification_categories"
        private const val KEY_NOTIF_ASKED = "notif_permission_asked"
        private const val KEY_BATTERY_ASKED = "battery_optimization_asked"
    }
}
