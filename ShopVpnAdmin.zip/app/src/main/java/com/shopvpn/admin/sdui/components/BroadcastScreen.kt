package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private const val MAX_LEN = 4000

private data class BroadcastResult(val total: Int, val success: Int, val failed: Int)

/**
 * تب «پیام همگانی»: بک‌اند این تب فقط یک متن ساده می‌گیرد و به همه‌ی
 * کاربران ربات می‌فرستد (بدون انتخاب مخاطب یا ضمیمه — دقیقاً همان چیزی که
 * BroadcastBody در server.py می‌پذیرد)، پس یک فرم native تک‌فیلدی با
 * تاییدیه‌ی ارسال کاملاً کافی است.
 */
@Composable
fun BroadcastScreen(tab: TabConfig, api: ApiClient) {
    var text by remember(tab.id) { mutableStateOf("") }
    var sending by remember(tab.id) { mutableStateOf(false) }
    var confirmOpen by remember(tab.id) { mutableStateOf(false) }
    var result by remember(tab.id) { mutableStateOf<BroadcastResult?>(null) }
    var errorMsg by remember(tab.id) { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    suspend fun send() {
        val submitUrl = tab.submit_url ?: return
        sending = true
        errorMsg = null
        try {
            val body = JsonObject()
            body.addProperty("message", text.trim())
            val res = api.post(submitUrl, body.toString())
            if (res.isJsonObject) {
                val o = res.asJsonObject
                result = BroadcastResult(
                    total = o["total"]?.asInt ?: 0,
                    success = o["success"]?.asInt ?: 0,
                    failed = o["failed"]?.asInt ?: 0,
                )
                text = ""
            }
        } catch (e: Exception) {
            errorMsg = e.message ?: "ارسال ناموفق بود"
        } finally {
            sending = false
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("ارسال پیام همگانی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "این پیام برای همه‌ی کاربران ربات (غیرمسدود) به‌صورت متنی ارسال می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                    )
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { if (it.length <= MAX_LEN) text = it },
                        placeholder = { Text("متن پیام را بنویس...") },
                        minLines = 6,
                        maxLines = 10,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "${text.length} / $MAX_LEN",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (text.length >= MAX_LEN) StatusDanger else TextMuted,
                        )
                        Button(
                            onClick = { confirmOpen = true },
                            enabled = text.isNotBlank() && !sending,
                        ) {
                            if (sending) {
                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.Campaign, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("ارسال به همه")
                            }
                        }
                    }
                    if (errorMsg != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(errorMsg!!, color = StatusDanger, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            result?.let { r ->
                Spacer(Modifier.height(14.dp))
                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("📢 ارسال تمام شد", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("کل", style = MaterialTheme.typography.labelSmall, color = TextMuted); Text("${r.total}") }
                            Column {
                                Text("موفق", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("${r.success}", color = StatusSuccess, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("ناموفق", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("${r.failed}", color = StatusDanger, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmOpen) {
        AlertDialog(
            onDismissRequest = { confirmOpen = false },
            title = { Text("تایید ارسال همگانی") },
            text = {
                Column {
                    Text("این پیام برای همه‌ی کاربران ربات ارسال می‌شود و قابل بازگشت نیست. مطمئنی؟")
                    Spacer(Modifier.height(10.dp))
                    Text(text, style = MaterialTheme.typography.bodySmall, color = TextMuted, maxLines = 6)
                }
            },
            confirmButton = {
                TextButton(onClick = { confirmOpen = false; scope.launch { send() } }) { Text("بله، ارسال کن") }
            },
            dismissButton = { TextButton(onClick = { confirmOpen = false }) { Text("انصراف") } },
        )
    }
}
