package com.shopvpn.admin.sdui

import androidx.compose.runtime.Composable
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.data.local.LocalCacheRepository
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.sdui.components.DashboardScreen
import com.shopvpn.admin.sdui.components.FormScreen
import com.shopvpn.admin.sdui.components.BannersScreen
import com.shopvpn.admin.sdui.components.AccountScreen
import com.shopvpn.admin.sdui.components.BroadcastScreen
import com.shopvpn.admin.sdui.components.ButtonRegistryScreen
import com.shopvpn.admin.sdui.components.ListScreen
import com.shopvpn.admin.sdui.components.MapScreen
import com.shopvpn.admin.sdui.components.SettingsGroupScreen
import com.shopvpn.admin.sdui.components.SettingsScreen
import com.shopvpn.admin.sdui.components.SupportScreen
import com.shopvpn.admin.sdui.components.TicketScreen
import com.shopvpn.admin.sdui.components.ResellersScreen
import com.shopvpn.admin.sdui.components.SystemScreen
import com.shopvpn.admin.sdui.components.WebViewScreen

/**
 * قلب معماری Server-Driven UI: این تابع هیچ صفحه‌ای را از قبل نمی‌شناسد،
 * فقط بر اساس مقدار "screen" که سرور در /api/app/config فرستاده تصمیم
 * می‌گیرد کدام کامپوننت عمومی (لیست/داشبورد/تنظیمات/وب‌ویو) را نشان دهد.
 * یک تب جدید با یکی از این چهار نوع، بدون هیچ آپدیت اپ، همین الان کار می‌کند.
 */
@Composable
fun RenderScreen(
    tab: TabConfig,
    api: ApiClient,
    session: SessionManager,
    cache: LocalCacheRepository,
    onLoggedOut: () -> Unit,
    allTabs: List<TabConfig> = emptyList(),
    // بعد از یه اکشن موفق (تایید/رد سفارش، مسدودکردن و ...) صدا زده می‌شه تا
    // شمارنده‌ی بالای تب‌ها (badge) هم رفرش بشه؛ قبلاً این شمارنده فقط زمان
    // باز شدن اپ یک‌بار گرفته می‌شد، پس بعد از تایید/رد یه سفارش تا وقتی اپ
    // رو نمی‌بستی و دوباره باز نمی‌کردی، عدد قبلی روی تب می‌موند.
    onDataChanged: () -> Unit = {},
) {
    when (tab.screen) {
        "dashboard" -> DashboardScreen(tab, api)
        "list" -> ListScreen(tab, api, onDataChanged = onDataChanged)
        "form" -> FormScreen(tab, api, cache)
        "buttons" -> ButtonRegistryScreen(tab, api, cache)
        "settings_group" -> SettingsGroupScreen(tab, api)
        "banners" -> BannersScreen(tab, api, session)
        "server_map" -> MapScreen(tab, api)
        "broadcast" -> BroadcastScreen(tab, api)
        "support" -> SupportScreen(tab, api)
        "tickets" -> TicketScreen(tab, api, onDataChanged = onDataChanged)
        "resellers" -> ResellersScreen(tab, api)
        "account" -> AccountScreen(tab, api)
        "system_status" -> SystemScreen(tab, api)
        "settings" -> SettingsScreen(session, api, onLoggedOut, allTabs)
        "webview" -> {
            val encodedNext = android.net.Uri.encode(tab.url ?: "/")
            val bridgeUrl = "/app/webview-bridge?token=${session.token}&next=$encodedNext"
            WebViewScreen(bridgeUrl, session)
        }
        else -> ListScreen(tab, api, onDataChanged = onDataChanged) // نوع ناشناخته -> فال‌بک به لیست عمومی
    }
}
