package com.shopvpn.admin.sdui

import androidx.compose.runtime.Composable
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.sdui.components.DashboardScreen
import com.shopvpn.admin.sdui.components.ListScreen
import com.shopvpn.admin.sdui.components.SettingsScreen
import com.shopvpn.admin.sdui.components.WebViewScreen

/**
 * قلب معماری Server-Driven UI: این تابع هیچ صفحه‌ای را از قبل نمی‌شناسد،
 * فقط بر اساس مقدار "screen" که سرور در /api/app/config فرستاده تصمیم
 * می‌گیرد کدام کامپوننت عمومی (لیست/داشبورد/تنظیمات/وب‌ویو) را نشان دهد.
 * یک تب جدید با یکی از این چهار نوع، بدون هیچ آپدیت اپ، همین الان کار می‌کند.
 */
@Composable
fun RenderScreen(
    tab: TabConfig,
    api: ApiClient,
    session: SessionManager,
    onLoggedOut: () -> Unit,
) {
    when (tab.screen) {
        "dashboard" -> DashboardScreen(tab, api)
        "list" -> ListScreen(tab, api)
        "settings" -> SettingsScreen(session, api, onLoggedOut)
        "webview" -> {
            val encodedNext = android.net.Uri.encode(tab.url ?: "/")
            val bridgeUrl = "/app/webview-bridge?token=${session.token}&next=$encodedNext"
            WebViewScreen(bridgeUrl, session)
        }
        else -> ListScreen(tab, api) // نوع ناشناخته -> فال‌بک به لیست عمومی
    }
}
