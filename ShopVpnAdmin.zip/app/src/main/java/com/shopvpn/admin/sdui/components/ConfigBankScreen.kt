package com.shopvpn.admin.sdui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import kotlinx.coroutines.launch

private fun JsonObject.s(key: String): String {
    val el = this[key] ?: return ""
    return if (el.isJsonNull) "" else if (el.isJsonPrimitive) el.asString else ""
}

/**
 * بانک کانفیگ یک محصول (غیر اتصال‌مستقیم): افزودن چندخطی لینک، مشاهده‌ی
 * لینک‌های آزاد، کپی و حذف — معادل مودال «بانک کانفیگ» در پنل وب.
 */
@Composable
fun ConfigBankScreen(
    sourceTemplate: String,
    idValue: String,
    api: ApiClient,
    onClose: () -> Unit,
) {
    val endpoint = sourceTemplate.replace("{id}", idValue).replace("{product_id}", idValue)
    val context = LocalContext.current

    var configs by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var usedCount by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var newLinks by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var deletingId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(endpoint).asJsonObject
            configs = res["items"]?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }.orEmpty()
            usedCount = res["used_count"]?.takeIf { it.isJsonPrimitive }?.asInt ?: 0
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(idValue) { load() }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("بانک کانفیگ") },
            navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت") } },
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error ?: "خطا")
                    Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("لینک‌های آزاد", configs.size.toString())
                        Stat("تحویل‌شده", usedCount.toString())
                        Stat("مجموع", (configs.size + usedCount).toString())
                    }
                }

                item {
                    OutlinedTextField(
                        value = newLinks,
                        onValueChange = { newLinks = it },
                        placeholder = { Text("هر خط یک لینک کانفیگ...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 5,
                    )
                }

                item {
                    Button(
                        onClick = {
                            if (newLinks.isBlank()) return@Button
                            scope.launch {
                                adding = true
                                try {
                                    val body = JsonObject().apply { addProperty("links", newLinks) }
                                    api.post(endpoint, body.toString())
                                    newLinks = ""
                                    load()
                                } catch (e: Exception) { error = e.message } finally { adding = false }
                            }
                        },
                        enabled = !adding,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (adding) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("افزودن لینک‌ها")
                    }
                }

                item { Text("لینک‌های آزاد (${configs.size})", style = MaterialTheme.typography.titleMedium) }

                if (configs.isEmpty()) {
                    item { EmptyState(title = "خالی است") }
                } else {
                    items(configs, key = { it.s("id") }) { cfg ->
                        val cfgId = cfg.s("id")
                        val link = cfg.s("link")
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(link, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("config", link))
                                    }) { Text("کپی") }
                                    val isBusy = deletingId == cfgId
                                    OutlinedButton(
                                        onClick = {
                                            scope.launch {
                                                deletingId = cfgId
                                                try { api.delete("/api/configs/$cfgId"); load() } catch (e: Exception) { error = e.message } finally { deletingId = null }
                                            }
                                        },
                                        enabled = !isBusy,
                                    ) {
                                        if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("حذف")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
