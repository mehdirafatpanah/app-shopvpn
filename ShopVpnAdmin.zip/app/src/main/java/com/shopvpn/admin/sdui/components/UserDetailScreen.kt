package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.ActionConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private fun JsonObject.s(key: String): String {
    val el = this[key] ?: return ""
    return if (el.isJsonNull) "" else if (el.isJsonPrimitive) el.asString else ""
}

private fun JsonObject.n(key: String): Double {
    val el = this[key] ?: return 0.0
    return if (el.isJsonPrimitive && el.asJsonPrimitive.isNumber) el.asDouble else 0.0
}

private fun JsonObject.b(key: String): Boolean {
    val el = this[key] ?: return false
    return el.isJsonPrimitive && el.asJsonPrimitive.isBoolean && el.asBoolean
}

private val SVC_EVENT_LABEL = mapOf(
    "purchase" to "خرید", "renewal" to "تمدید", "toggle" to "فعال/غیرفعال",
    "auto_renew_toggle" to "تمدید خودکار", "rename" to "تغییر نام", "transfer" to "انتقال",
    "cut_access" to "قطع دسترسی", "auto_renew" to "تمدید خودکار (خودکار انجام‌شده)",
)

/**
 * صفحه‌ی جزئیات کاربر: معادل native مودال «کاربر ...» در پنل وب — کیف‌پول
 * و اعمال شارژ/کسر، سفارش‌های اخیر، شارژهای کیف‌پول، سرویس‌های مستقیم-پنل
 * با اکشن‌های فعال/غیرفعال، تغییر نام، تمدید خودکار، انتقال، قطع دسترسی،
 * تاریخچه و حذف، و کانفیگ‌های بانک محصول با فعال/غیرفعال و حذف — دقیقاً
 * معادل همان بخش‌ها در پنل وب.
 */
@Composable
fun UserDetailScreen(
    title: String,
    detailSourceTemplate: String,
    servicesSourceTemplate: String?,
    bankConfigsSourceTemplate: String?,
    walletEndpointTemplate: String?,
    idValue: String,
    actions: List<ActionConfig>,
    api: ApiClient,
    onClose: () -> Unit,
) {
    fun tpl(template: String) = template.replace("{id}", idValue).replace("{tg_id}", idValue)

    var data by remember { mutableStateOf<JsonObject?>(null) }
    var services by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var bankConfigs by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var walletDelta by remember { mutableStateOf("") }

    var renameTarget by remember { mutableStateOf<JsonObject?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var transferTarget by remember { mutableStateOf<JsonObject?>(null) }
    var transferValue by remember { mutableStateOf("") }
    var cutTarget by remember { mutableStateOf<JsonObject?>(null) }
    var deleteSvcTarget by remember { mutableStateOf<JsonObject?>(null) }
    var deleteBankTarget by remember { mutableStateOf<JsonObject?>(null) }
    var historyTarget by remember { mutableStateOf<JsonObject?>(null) }
    var historyRows by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var historyLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            data = api.get(tpl(detailSourceTemplate)).asJsonObject
            services = if (servicesSourceTemplate != null) {
                api.get(tpl(servicesSourceTemplate)).asJsonArray.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
            } else emptyList()
            bankConfigs = if (bankConfigsSourceTemplate != null) {
                try {
                    api.get(tpl(bankConfigsSourceTemplate)).asJsonArray.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
                } catch (e: Exception) { emptyList() }
            } else emptyList()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    suspend fun runSvcAction(endpoint: String, body: String = "{}") {
        api.post(endpoint, body)
    }

    LaunchedEffect(idValue) { load() }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title) },
            navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت") } },
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error ?: "خطا")
                    Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            data == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("چیزی پیدا نشد") }
            else -> {
                val d = data!!
                val u = d["user"]?.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject()
                val referral = d["referral"]?.takeIf { it.isJsonObject }?.asJsonObject
                val isReseller = d.b("is_reseller")
                val orders = d["orders"]?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }.orEmpty()
                val topups = d["topups"]?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }.orEmpty()
                val isBlocked = u.b("is_blocked")
                val displayName = u.s("username").let { if (it.isNotBlank()) "@$it" else u.s("first_name").ifBlank { "کاربر #$idValue" } }
                val visibleActions = actions.filter { it.visible_if_field == null || u.s(it.visible_if_field) == (it.visible_if_value ?: "") }

                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(displayName, style = MaterialTheme.typography.titleLarge)
                                Text("ID: $idValue", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                            StatusChip(if (isBlocked) "مسدود" else "فعال")
                        }
                    }

                    item {
                        val stats = buildList {
                            add("کیف پول" to "${u.n("referral_credit").toLong()} تومان")
                            if (referral != null) add("زیرمجموعه‌ها" to referral.n("count").toLong().toString())
                            add("تاریخ عضویت" to u.s("joined_at").ifBlank { "-" })
                            add("تست دریافتی" to if (u.b("test_used")) "بله" else "خیر")
                            if (isReseller) add("اعتبار نمایندگی" to "${d.n("reseller_credit").toLong()} گیگ")
                            if (u.s("referred_by").isNotBlank()) add("دعوت‌شده توسط" to "#${u.s("referred_by")}")
                        }
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                stats.forEach { (label, value) ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(label, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                        Text(value, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    }

                    if (visibleActions.isNotEmpty()) {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                visibleActions.forEach { action ->
                                    val isBusy = busyAction == action.id
                                    val color = when (action.style) { "success" -> StatusSuccess; "danger" -> StatusDanger; else -> BrandPrimary }
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                busyAction = action.id
                                                try {
                                                    val endpoint = tpl(action.endpoint)
                                                    if (action.method.equals("DELETE", true)) api.delete(endpoint) else api.post(endpoint)
                                                    load()
                                                } catch (e: Exception) { error = e.message } finally { busyAction = null }
                                            }
                                        },
                                        enabled = !isBusy,
                                        shape = MaterialTheme.shapes.small,
                                        colors = ButtonDefaults.buttonColors(containerColor = color),
                                    ) {
                                        if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text(action.label)
                                    }
                                }
                            }
                        }
                    }

                    if (walletEndpointTemplate != null) {
                        item {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = walletDelta,
                                    onValueChange = { walletDelta = it },
                                    placeholder = { Text("مبلغ (مثبت=افزایش، منفی=کاهش)") },
                                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                )
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = {
                                    val delta = walletDelta.toIntOrNull()
                                    if (delta == null || delta == 0) return@Button
                                    scope.launch {
                                        try {
                                            val body = JsonObject().apply { addProperty("delta", delta) }
                                            api.post(tpl(walletEndpointTemplate), body.toString())
                                            walletDelta = ""
                                            load()
                                        } catch (e: Exception) { error = e.message }
                                    }
                                }) { Text("اعمال") }
                            }
                        }
                    }

                    if (services.isNotEmpty()) {
                        item { Text("سرویس‌های مستقیم-پنل", style = MaterialTheme.typography.titleMedium) }
                        items(services) { svc ->
                            val enabled = svc.b("enabled")
                            val isTest = svc.b("is_test")
                            val autoRenew = svc.b("auto_renew")
                            val durationDays = svc.n("duration_days")
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(svc.s("display_name").ifBlank { svc.s("username") } + if (isTest) " (تست)" else "", style = MaterialTheme.typography.titleSmall)
                                        StatusChip(if (enabled) "فعال" else "غیرفعال")
                                    }
                                    Text("${svc.n("volume_gb").toLong()} گیگ / ${durationDays.toLong()} روز", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    if (!isTest) {
                                        Spacer(Modifier.height(8.dp))
                                        val svcId = svc.s("id")
                                        Row(
                                            Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        ) {
                                            OutlinedButton(onClick = {
                                                scope.launch {
                                                    try { runSvcAction("/api/custom-configs/$svcId/toggle"); load() } catch (e: Exception) { error = e.message }
                                                }
                                            }) { Text(if (enabled) "غیرفعال کردن" else "فعال کردن") }
                                            OutlinedButton(onClick = { renameTarget = svc; renameValue = svc.s("display_name").ifBlank { svc.s("username") } }) { Text("تغییر نام") }
                                            if (durationDays > 0) {
                                                OutlinedButton(onClick = {
                                                    scope.launch {
                                                        try {
                                                            val body = JsonObject().apply { addProperty("enabled", !autoRenew) }
                                                            runSvcAction("/api/custom-configs/$svcId/auto-renew", body = body.toString())
                                                            load()
                                                        } catch (e: Exception) { error = e.message }
                                                    }
                                                }) { Text(if (autoRenew) "قطع تمدید خودکار" else "تمدید خودکار") }
                                            }
                                            OutlinedButton(onClick = { transferTarget = svc; transferValue = "" }) { Text("انتقال") }
                                            OutlinedButton(onClick = { cutTarget = svc }) { Text("قطع دسترسی") }
                                            OutlinedButton(onClick = {
                                                historyTarget = svc
                                                scope.launch {
                                                    historyLoading = true
                                                    try {
                                                        historyRows = api.get("/api/custom-configs/$svcId/history").asJsonArray.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }
                                                    } catch (e: Exception) { error = e.message } finally { historyLoading = false }
                                                }
                                            }) { Text("تاریخچه") }
                                            OutlinedButton(
                                                onClick = { deleteSvcTarget = svc },
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                                            ) { Text("حذف") }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (bankConfigs.isNotEmpty()) {
                        item { Text("کانفیگ‌های بانک محصول", style = MaterialTheme.typography.titleMedium) }
                        items(bankConfigs) { cfg ->
                            val cfgId = cfg.s("id")
                            val isDisabled = cfg.b("is_disabled")
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column(Modifier.weight(1f)) {
                                            Text(cfg.s("product_name").ifBlank { "نامشخص" }, style = MaterialTheme.typography.titleSmall)
                                            Text(
                                                cfg.s("order_id").let { if (it.isNotBlank()) "سفارش #$it" else "-" },
                                                style = MaterialTheme.typography.bodySmall, color = TextMuted,
                                            )
                                        }
                                        StatusChip(if (isDisabled) "غیرفعال" else "فعال")
                                    }
                                    val link = cfg.s("link")
                                    if (link.isNotBlank()) {
                                        Text(link, style = MaterialTheme.typography.bodySmall, color = TextMuted, maxLines = 1)
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(onClick = {
                                            scope.launch {
                                                try {
                                                    val body = JsonObject().apply { addProperty("disabled", !isDisabled) }
                                                    api.post("/api/user-configs/$cfgId/disable", body.toString())
                                                    load()
                                                } catch (e: Exception) { error = e.message }
                                            }
                                        }) { Text(if (isDisabled) "فعال کردن" else "غیرفعال کردن") }
                                        OutlinedButton(
                                            onClick = { deleteBankTarget = cfg },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                                        ) { Text("حذف") }
                                    }
                                }
                            }
                        }
                    }

                    if (orders.isNotEmpty()) {
                        item { Text("سفارش‌های اخیر", style = MaterialTheme.typography.titleMedium) }
                        items(orders.take(10)) { o ->
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("#${o.s("id")} ${o.s("product_name").ifBlank { "-" }}", style = MaterialTheme.typography.bodyMedium)
                                        Text(o.s("created_at"), style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${o.n("final_price").toLong()} تومان", style = MaterialTheme.typography.bodyMedium)
                                        StatusChip(o.s("status"))
                                    }
                                }
                            }
                        }
                    }

                    if (topups.isNotEmpty()) {
                        item { Text("شارژهای کیف‌پول", style = MaterialTheme.typography.titleMedium) }
                        items(topups.take(10)) { t ->
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("#${t.s("id")}  ${t.s("created_at")}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${t.n("amount").toLong()} تومان", style = MaterialTheme.typography.bodyMedium)
                                        StatusChip(t.s("status"))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    renameTarget?.let { svc ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("تغییر نام سرویس") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it },
                    placeholder = { Text("فقط حروف انگلیسی، عدد و آندرلاین، ۳ تا ۲۰ کاراکتر") },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val svcId = svc.s("id")
                    val newName = renameValue.trim()
                    renameTarget = null
                    scope.launch {
                        try {
                            val body = JsonObject().apply { addProperty("new_name", newName) }
                            runSvcAction("/api/custom-configs/$svcId/rename", body = body.toString())
                            load()
                        } catch (e: Exception) { error = e.message }
                    }
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("انصراف") } },
        )
    }

    transferTarget?.let { svc ->
        AlertDialog(
            onDismissRequest = { transferTarget = null },
            title = { Text("انتقال سرویس") },
            text = {
                OutlinedTextField(
                    value = transferValue,
                    onValueChange = { transferValue = it },
                    placeholder = { Text("آی‌دی عددی تلگرام کاربر مقصد") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val svcId = svc.s("id")
                    val targetId = transferValue.trim().toLongOrNull()
                    transferTarget = null
                    if (targetId == null) return@TextButton
                    scope.launch {
                        try {
                            val body = JsonObject().apply { addProperty("target_telegram_id", targetId) }
                            runSvcAction("/api/custom-configs/$svcId/transfer", body = body.toString())
                            load()
                        } catch (e: Exception) { error = e.message }
                    }
                }) { Text("انتقال") }
            },
            dismissButton = { TextButton(onClick = { transferTarget = null }) { Text("انصراف") } },
        )
    }

    cutTarget?.let { svc ->
        AlertDialog(
            onDismissRequest = { cutTarget = null },
            title = { Text("قطع دسترسی") },
            text = { Text("لینک فعلی از کار می‌افتد و لینک جدیدی با همان حجم/زمان باقی‌مانده صادر می‌شود. ادامه می‌دهید؟") },
            confirmButton = {
                TextButton(onClick = {
                    val svcId = svc.s("id")
                    cutTarget = null
                    scope.launch {
                        try { runSvcAction("/api/custom-configs/$svcId/cut-access"); load() } catch (e: Exception) { error = e.message }
                    }
                }) { Text("تایید") }
            },
            dismissButton = { TextButton(onClick = { cutTarget = null }) { Text("انصراف") } },
        )
    }

    deleteSvcTarget?.let { svc ->
        AlertDialog(
            onDismissRequest = { deleteSvcTarget = null },
            title = { Text("حذف سرویس") },
            text = { Text("این سرویس برای همیشه از پنل VPN و از این کاربر حذف می‌شود و غیرقابل بازگشت است. ادامه می‌دهید؟") },
            confirmButton = {
                TextButton(onClick = {
                    val svcId = svc.s("id")
                    deleteSvcTarget = null
                    scope.launch {
                        try { api.delete("/api/custom-configs/$svcId"); load() } catch (e: Exception) { error = e.message }
                    }
                }) { Text("حذف", color = StatusDanger) }
            },
            dismissButton = { TextButton(onClick = { deleteSvcTarget = null }) { Text("انصراف") } },
        )
    }

    deleteBankTarget?.let { cfg ->
        AlertDialog(
            onDismissRequest = { deleteBankTarget = null },
            title = { Text("حذف کانفیگ") },
            text = { Text("این کانفیگ برای همیشه حذف می‌شود و این عملیات غیرقابل بازگشت است. ادامه می‌دهید؟") },
            confirmButton = {
                TextButton(onClick = {
                    val cfgId = cfg.s("id")
                    deleteBankTarget = null
                    scope.launch {
                        try { api.delete("/api/user-configs/$cfgId"); load() } catch (e: Exception) { error = e.message }
                    }
                }) { Text("حذف", color = StatusDanger) }
            },
            dismissButton = { TextButton(onClick = { deleteBankTarget = null }) { Text("انصراف") } },
        )
    }

    historyTarget?.let {
        AlertDialog(
            onDismissRequest = { historyTarget = null },
            title = { Text("تاریخچه‌ی سرویس") },
            text = {
                if (historyLoading) CircularProgressIndicator()
                else Column {
                    if (historyRows.isEmpty()) Text("تاریخچه‌ای ثبت نشده.")
                    historyRows.forEach { r ->
                        Text("${SVC_EVENT_LABEL[r.s("event_type")] ?: r.s("event_type")} — ${r.s("detail")} (${r.s("created_at")})", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { historyTarget = null }) { Text("بستن") } },
        )
    }
}
