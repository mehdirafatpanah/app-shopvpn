package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.theme.StatusDanger
import kotlinx.coroutines.launch

/** تب «حساب من»: در پنل وب یک انتخاب‌گر تمِ مرورگر هم دارد که این‌جا معنی
 * ندارد (اپ اندروید ظاهر Material خودش را دارد)، پس فقط تغییر پسورد مانده. */
@Composable
fun AccountScreen(tab: TabConfig, api: ApiClient) {
    var current by remember { mutableStateOf("") }
    var new1 by remember { mutableStateOf("") }
    var showCurrent by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    suspend fun save() {
        val submitUrl = tab.submit_url ?: return
        saving = true
        errorMsg = null
        try {
            val body = JsonObject()
            body.addProperty("current_password", current)
            body.addProperty("new_password", new1)
            api.post(submitUrl, body.toString())
            current = ""; new1 = ""
            snackbarHostState.showSnackbar("پسورد تغییر کرد")
        } catch (e: Exception) {
            errorMsg = e.message ?: "خطا در تغییر پسورد"
        } finally {
            saving = false
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("تغییر پسورد", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = current,
                        onValueChange = { current = it },
                        label = { Text("پسورد فعلی") },
                        singleLine = true,
                        visualTransformation = if (showCurrent) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showCurrent = !showCurrent }) {
                                Icon(if (showCurrent) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = new1,
                        onValueChange = { new1 = it },
                        label = { Text("پسورد جدید (حداقل ۸ کاراکتر)") },
                        singleLine = true,
                        visualTransformation = if (showNew) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showNew = !showNew }) {
                                Icon(if (showNew) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (errorMsg != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(errorMsg!!, color = StatusDanger, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = { scope.launch { save() } },
                        enabled = !saving && current.isNotBlank() && new1.length >= 8,
                    ) {
                        if (saving) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        else Text("تغییر پسورد")
                    }
                }
            }
        }
    }
}
