package com.shopvpn.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.theme.*

private val MenuAccents = listOf(
    AccentViolet, AccentBlue, AccentCyan, AccentGreen, AccentAmber, AccentPink
)

@Composable
fun AllSectionsScreen(
    serverName: String,
    tenant: String,
    tabs: List<TabConfig>,
    badgeCounts: Map<String, Int>,
    onSelect: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, tabs) {
        if (query.isBlank()) tabs else tabs.filter {
            it.title.contains(query.trim(), ignoreCase = true) ||
                (it.section ?: "").contains(query.trim(), ignoreCase = true)
        }
    }
    val grouped = filtered.groupBy { it.section?.takeIf(String::isNotBlank) ?: "عمومی" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            // A compact command header replaces the old large gradient banner.
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(15.dp))
                        .background(BrandPrimary.copy(.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Widgets, null, tint = BrandPrimary, modifier = Modifier.size(25.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("مرکز دسترسی", style = MaterialTheme.typography.titleLarge)
                    Text("$serverName  •  $tenant", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("جستجو در بخش‌ها") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                shape = RoundedCornerShape(17.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandPrimary,
                    unfocusedBorderColor = StrokeSubtle,
                    focusedContainerColor = BgElevated1,
                    unfocusedContainerColor = BgElevated1,
                )
            )
        }

        if (filtered.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 50.dp), contentAlignment = Alignment.Center) {
                    Text("بخشی پیدا نشد", color = TextMuted)
                }
            }
        } else {
            grouped.entries.forEachIndexed { groupIndex, entry ->
                item {
                    MenuSectionHeader(entry.key, entry.value.size)
                }
                items(entry.value) { tab ->
                    val index = tabs.indexOf(tab).coerceAtLeast(0)
                    val accent = MenuAccents[(index + groupIndex) % MenuAccents.size]
                    val count = badgeCounts[tab.id] ?: 0
                    CompactMenuRow(
                        title = tab.title,
                        accent = accent,
                        icon = iconFor(tab.icon),
                        badgeCount = count,
                        onClick = { onSelect(tab.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuSectionHeader(title: String, count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(4.dp).height(20.dp).clip(RoundedCornerShape(50)).background(BrandPrimary)
        )
        Spacer(Modifier.width(9.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.weight(1f))
        Text("$count بخش", style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

@Composable
private fun CompactMenuRow(
    title: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeCount: Int,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(BgElevated1)
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                .background(accent.copy(.11f)),
            contentAlignment = Alignment.Center
        ) {
            BadgedBox(badge = {
                if (badgeCount > 0) Badge { Text(if (badgeCount > 9) "9+" else badgeCount.toString()) }
            }) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(23.dp))
            }
        }
        Spacer(Modifier.width(13.dp))
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, maxLines = 1)
        Icon(Icons.Filled.ChevronLeft, null, tint = TextMuted, modifier = Modifier.size(21.dp))
    }
}
