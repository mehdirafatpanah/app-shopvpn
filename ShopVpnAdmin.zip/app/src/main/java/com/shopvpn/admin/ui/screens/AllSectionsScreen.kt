package com.shopvpn.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.components.*
import com.shopvpn.admin.ui.theme.*

private val TilePalette = listOf(
    AccentViolet to TileVioletBg, AccentCyan to TileCyanBg, AccentPink to TilePinkBg,
    AccentAmber to TileAmberBg, AccentGreen to TileGreenBg, AccentBlue to TileBlueBg,
)

@Composable
fun AllSectionsScreen(
    serverName: String,
    tenant: String,
    tabs: List<TabConfig>,
    badgeCounts: Map<String, Int>,
    onSelect: (String) -> Unit,
) {
    val grouped = tabs.groupBy { it.section ?: "عمومی" }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            BrandGradientCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(.13f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(serverName.firstOrNull()?.uppercase() ?: "S", color = Color.White,
                            style = MaterialTheme.typography.titleLarge)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text("مرکز دسترسی", color = Color.White.copy(.72f),
                            style = MaterialTheme.typography.labelMedium)
                        Text(serverName, color = Color.White,
                            style = MaterialTheme.typography.titleLarge)
                        Text("پنل $tenant", color = Color.White.copy(.65f),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        grouped.entries.forEachIndexed { groupIdx, (section, sectionTabs) ->
            item { SectionLabel(section) }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height((((sectionTabs.size + 1) / 2) * 96).dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    userScrollEnabled = false,
                ) {
                    items(sectionTabs) { tab ->
                        val paletteIndex = (groupIdx + sectionTabs.indexOf(tab)) % TilePalette.size
                        val (accent, tileBg) = TilePalette[paletteIndex]
                        val count = badgeCounts[tab.id] ?: 0
                        ElevatedAppCard(
                            modifier = Modifier.fillMaxWidth().height(88.dp)
                                .clickable { onSelect(tab.id) },
                            tint = tileBg
                        ) {
                            Row(
                                Modifier.fillMaxSize().padding(13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BadgedBox(badge = {
                                    if (count > 0) Badge(containerColor = AccentPink) {
                                        Text(if (count > 9) "9+" else count.toString())
                                    }
                                }) {
                                    NeonIconTile(iconFor(tab.icon), accent, size = 42.dp)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(tab.title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                                    Text("باز کردن", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                                Icon(Icons.Filled.ChevronLeft, null, tint = TextMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
