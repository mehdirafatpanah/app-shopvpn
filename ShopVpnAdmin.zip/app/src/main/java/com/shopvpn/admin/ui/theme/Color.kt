package com.shopvpn.admin.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0B0E17)
val SurfaceGlass = Color(0xFF161B2C)
val SurfaceGlassLight = Color(0xFF1F2740)
val AccentViolet = Color(0xFF7C5CFF)
val AccentTeal = Color(0xFF00E5C7)
val AccentDanger = Color(0xFFFF5C7C)
val AccentSuccess = Color(0xFF33D17A)
val TextPrimary = Color(0xFFF3F5FA)
val TextSecondary = Color(0xFF9AA3B8)
