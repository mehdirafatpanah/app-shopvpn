package com.shopvpn.admin.ui.theme

import androidx.compose.ui.graphics.Color

// ShopVPN Admin — Cyber Minimal palette
val BgBase = Color(0xFF050711)
val BgElevated1 = Color(0xFF0B1020)
val BgElevated2 = Color(0xFF10172A)
val BgElevated3 = Color(0xFF17213A)
val StrokeSubtle = Color(0xFF1D2A47)
val StrokeStrong = Color(0xFF304A78)

val BrandStart = Color(0xFF6D5CFF)
val BrandEnd = Color(0xFF00D7FF)
val BrandPrimary = Color(0xFF7C67FF)
val BrandPrimaryOn = Color.White
val AccentCyan = Color(0xFF19D9FF)
val AccentAmber = Color(0xFFFFB84D)
val AccentPink = Color(0xFFFF4F9A)

val StatusSuccess = Color(0xFF35E38A)
val StatusSuccessBg = Color(0xFF0C2A22)
val StatusWarning = Color(0xFFFFB84D)
val StatusWarningBg = Color(0xFF30240D)
val StatusDanger = Color(0xFFFF5578)
val StatusDangerBg = Color(0xFF35101D)
val StatusInfo = Color(0xFF4DA7FF)
val StatusInfoBg = Color(0xFF0C2340)
val StatusNeutral = Color(0xFF8E9BB7)
val StatusNeutralBg = Color(0xFF151D30)

val TextPrimary = Color(0xFFF5F7FF)
val TextSecondary = Color(0xFFAAB5CF)
val TextMuted = Color(0xFF687591)
