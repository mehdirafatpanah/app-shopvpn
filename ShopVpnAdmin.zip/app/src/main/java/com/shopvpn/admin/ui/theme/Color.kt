package com.shopvpn.admin.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

/**
 * ShopVPN Nexus design system.
 * Premium dark admin UI with restrained cyber accents.
 */
object ThemeController {
    var isDark by mutableStateOf(true)
}

private object Light {
    val Bg = Color(0xFFF5F7FB)
    val Elevated1 = Color(0xFFFFFFFF)
    val Elevated2 = Color(0xFFF0F3F8)
    val Elevated3 = Color(0xFFE7ECF4)
    val NavBarBg = Color(0xF5FFFFFF)
    val StrokeSubtle = Color(0xFFE1E7F0)
    val StrokeStrong = Color(0xFFC9D2E0)
    val GlassFill = Color(0xCCFFFFFF)
    val GlassFillStrong = Color(0xF2FFFFFF)
    val GlassBorder = Color(0xFFE0E6EF)
    val GlassSheen = Color(0xFFFFFFFF)

    val BrandStart = Color(0xFF5B5CFF)
    val BrandEnd = Color(0xFF19C6B4)
    val BrandPrimary = Color(0xFF5B5CFF)
    val BrandPrimaryOn = Color.White

    val AccentViolet = Color(0xFF6C63FF)
    val AccentCyan = Color(0xFF10B9A6)
    val AccentPink = Color(0xFFE34F9B)
    val AccentAmber = Color(0xFFD48A20)
    val AccentGreen = Color(0xFF16A36B)
    val AccentBlue = Color(0xFF4387F5)

    val TileVioletBg = Color(0x146C63FF)
    val TileCyanBg = Color(0x1410B9A6)
    val TilePinkBg = Color(0x14E34F9B)
    val TileAmberBg = Color(0x14D48A20)
    val TileGreenBg = Color(0x1416A36B)
    val TileBlueBg = Color(0x144387F5)

    val StatusSuccess = Color(0xFF139A63)
    val StatusSuccessBg = Color(0xFFE5F7F0)
    val StatusWarning = Color(0xFFB97712)
    val StatusWarningBg = Color(0xFFFFF3DD)
    val StatusDanger = Color(0xFFD84458)
    val StatusDangerBg = Color(0xFFFDEBED)
    val StatusInfo = Color(0xFF3977DA)
    val StatusInfoBg = Color(0xFFEAF1FF)
    val StatusNeutral = Color(0xFF657087)
    val StatusNeutralBg = Color(0xFFEDF0F5)

    val TextPrimary = Color(0xFF121722)
    val TextSecondary = Color(0xFF5D687C)
    val TextMuted = Color(0xFF8B95A7)
}

private object Dark {
    val Bg = Color(0xFF070A12)
    val Elevated1 = Color(0xFF0D121D)
    val Elevated2 = Color(0xFF121A29)
    val Elevated3 = Color(0xFF182236)
    val NavBarBg = Color(0xF20B101A)
    val StrokeSubtle = Color(0xFF202B3D)
    val StrokeStrong = Color(0xFF31415A)
    val GlassFill = Color(0xB80F1624)
    val GlassFillStrong = Color(0xE6141D2D)
    val GlassBorder = Color(0x242F4059)
    val GlassSheen = Color(0x12FFFFFF)

    val BrandStart = Color(0xFF716BFF)
    val BrandEnd = Color(0xFF18D0BE)
    val BrandPrimary = Color(0xFF817BFF)
    val BrandPrimaryOn = Color.White

    val AccentViolet = Color(0xFF817BFF)
    val AccentCyan = Color(0xFF27D6C4)
    val AccentPink = Color(0xFFFF6EAF)
    val AccentAmber = Color(0xFFF0B65D)
    val AccentGreen = Color(0xFF45E39D)
    val AccentBlue = Color(0xFF69A1FF)

    val TileVioletBg = Color(0x1C817BFF)
    val TileCyanBg = Color(0x1C27D6C4)
    val TilePinkBg = Color(0x1CFF6EAF)
    val TileAmberBg = Color(0x1CF0B65D)
    val TileGreenBg = Color(0x1C45E39D)
    val TileBlueBg = Color(0x1C69A1FF)

    val StatusSuccess = Color(0xFF45E39D)
    val StatusSuccessBg = Color(0xFF0D2B22)
    val StatusWarning = Color(0xFFF0B65D)
    val StatusWarningBg = Color(0xFF30250E)
    val StatusDanger = Color(0xFFFF7182)
    val StatusDangerBg = Color(0xFF35131B)
    val StatusInfo = Color(0xFF69A1FF)
    val StatusInfoBg = Color(0xFF10223C)
    val StatusNeutral = Color(0xFF9AA6BA)
    val StatusNeutralBg = Color(0xFF151C29)

    val TextPrimary = Color(0xFFF4F7FC)
    val TextSecondary = Color(0xFFAAB5C8)
    val TextMuted = Color(0xFF68758A)
}

private inline fun tok(light: Color, dark: Color): Color = if (ThemeController.isDark) dark else light

val BgBase: Color get() = tok(Light.Bg, Dark.Bg)
val BgElevated1: Color get() = tok(Light.Elevated1, Dark.Elevated1)
val BgElevated2: Color get() = tok(Light.Elevated2, Dark.Elevated2)
val BgElevated3: Color get() = tok(Light.Elevated3, Dark.Elevated3)
val NavBarBg: Color get() = tok(Light.NavBarBg, Dark.NavBarBg)
val StrokeSubtle: Color get() = tok(Light.StrokeSubtle, Dark.StrokeSubtle)
val StrokeStrong: Color get() = tok(Light.StrokeStrong, Dark.StrokeStrong)
val GlassFill: Color get() = tok(Light.GlassFill, Dark.GlassFill)
val GlassFillStrong: Color get() = tok(Light.GlassFillStrong, Dark.GlassFillStrong)
val GlassBorder: Color get() = tok(Light.GlassBorder, Dark.GlassBorder)
val GlassSheen: Color get() = tok(Light.GlassSheen, Dark.GlassSheen)
val BrandStart: Color get() = tok(Light.BrandStart, Dark.BrandStart)
val BrandEnd: Color get() = tok(Light.BrandEnd, Dark.BrandEnd)
val BrandPrimary: Color get() = tok(Light.BrandPrimary, Dark.BrandPrimary)
val BrandPrimaryOn: Color get() = tok(Light.BrandPrimaryOn, Dark.BrandPrimaryOn)
val AccentViolet: Color get() = tok(Light.AccentViolet, Dark.AccentViolet)
val AccentCyan: Color get() = tok(Light.AccentCyan, Dark.AccentCyan)
val AccentPink: Color get() = tok(Light.AccentPink, Dark.AccentPink)
val AccentAmber: Color get() = tok(Light.AccentAmber, Dark.AccentAmber)
val AccentGreen: Color get() = tok(Light.AccentGreen, Dark.AccentGreen)
val AccentBlue: Color get() = tok(Light.AccentBlue, Dark.AccentBlue)
val TileVioletBg: Color get() = tok(Light.TileVioletBg, Dark.TileVioletBg)
val TileCyanBg: Color get() = tok(Light.TileCyanBg, Dark.TileCyanBg)
val TilePinkBg: Color get() = tok(Light.TilePinkBg, Dark.TilePinkBg)
val TileAmberBg: Color get() = tok(Light.TileAmberBg, Dark.TileAmberBg)
val TileGreenBg: Color get() = tok(Light.TileGreenBg, Dark.TileGreenBg)
val TileBlueBg: Color get() = tok(Light.TileBlueBg, Dark.TileBlueBg)
val StatusSuccess: Color get() = tok(Light.StatusSuccess, Dark.StatusSuccess)
val StatusSuccessBg: Color get() = tok(Light.StatusSuccessBg, Dark.StatusSuccessBg)
val StatusWarning: Color get() = tok(Light.StatusWarning, Dark.StatusWarning)
val StatusWarningBg: Color get() = tok(Light.StatusWarningBg, Dark.StatusWarningBg)
val StatusDanger: Color get() = tok(Light.StatusDanger, Dark.StatusDanger)
val StatusDangerBg: Color get() = tok(Light.StatusDangerBg, Dark.StatusDangerBg)
val StatusInfo: Color get() = tok(Light.StatusInfo, Dark.StatusInfo)
val StatusInfoBg: Color get() = tok(Light.StatusInfoBg, Dark.StatusInfoBg)
val StatusNeutral: Color get() = tok(Light.StatusNeutral, Dark.StatusNeutral)
val StatusNeutralBg: Color get() = tok(Light.StatusNeutralBg, Dark.StatusNeutralBg)
val TextPrimary: Color get() = tok(Light.TextPrimary, Dark.TextPrimary)
val TextSecondary: Color get() = tok(Light.TextSecondary, Dark.TextSecondary)
val TextMuted: Color get() = tok(Light.TextMuted, Dark.TextMuted)

val BentoJumboNumber = androidx.compose.ui.text.TextStyle(
    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
    fontSize = 31.sp,
    color = TextPrimary,
    letterSpacing = (-0.35).sp
)
