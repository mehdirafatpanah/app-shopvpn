package com.shopvpn.admin.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * سوییچ سراسری روشن/تیره. مقداردهی اولیه در ShopVpnAdminApp.onCreate از روی
 * SessionManager.darkModeEnabled انجام می‌شود. چون این یک Compose state است،
 * هر تابع پایین که مقدارش را در حین کامپوز می‌خواند (یعنی همه‌ی توکن‌های این
 * فایل) با تغییر آن خودکار ری‌کامپوز می‌شود — بدون این‌که هیچ صفحه‌ای مجبور
 * باشد صراحتاً این آبجکت را وارد کند یا کد خودش را عوض کند.
 */
object ThemeController {
    var isDark by mutableStateOf(false)
}

// ShopVPN Admin — Modern Banking palette (روشن + تیره)
private object Light {
    val Bg = Color(0xFFF4F6FA)
    val Elevated1 = Color(0xFFFFFFFF)
    val Elevated2 = Color(0xFFEDF0F6)
    val Elevated3 = Color(0xFFE3E7F0)
    val NavBarBg = Color(0xF2FFFFFF)
    val StrokeSubtle = Color(0xFFE2E6EF)
    val StrokeStrong = Color(0xFFC7CEDC)

    val GlassFill = Color(0x00000000)
    val GlassFillStrong = Color(0x0A0B1E3D)
    val GlassBorder = Color(0xFFE2E6EF)
    val GlassSheen = Color(0x00FFFFFF)

    val BrandStart = Color(0xFF0B3D91)
    val BrandEnd = Color(0xFF0EA5A0)
    val BrandPrimary = Color(0xFF0B3D91)
    val BrandPrimaryOn = Color.White

    val AccentViolet = Color(0xFF4F46E5)
    val AccentCyan = Color(0xFF0EA5A0)
    val AccentPink = Color(0xFFDB2777)
    val AccentAmber = Color(0xFFB45309)
    val AccentGreen = Color(0xFF15803D)
    val AccentBlue = Color(0xFF1D4ED8)

    val TileVioletBg = Color(0x1F4F46E5)
    val TileCyanBg = Color(0x1F0EA5A0)
    val TilePinkBg = Color(0x1FDB2777)
    val TileAmberBg = Color(0x1FB45309)
    val TileGreenBg = Color(0x1F15803D)
    val TileBlueBg = Color(0x1F1D4ED8)

    val StatusSuccess = Color(0xFF15803D)
    val StatusSuccessBg = Color(0xFFE3F5E9)
    val StatusWarning = Color(0xFFB45309)
    val StatusWarningBg = Color(0xFFFBF0DE)
    val StatusDanger = Color(0xFFC62839)
    val StatusDangerBg = Color(0xFFFCE7E9)
    val StatusInfo = Color(0xFF1D4ED8)
    val StatusInfoBg = Color(0xFFE5ECFC)
    val StatusNeutral = Color(0xFF5B6373)
    val StatusNeutralBg = Color(0xFFE9EBF0)

    val TextPrimary = Color(0xFF121826)
    val TextSecondary = Color(0xFF525C70)
    val TextMuted = Color(0xFF8891A3)
}

private object Dark {
    val Bg = Color(0xFF0A0F1C)
    val Elevated1 = Color(0xFF10182A)
    val Elevated2 = Color(0xFF161F35)
    val Elevated3 = Color(0xFF1C2740)
    val NavBarBg = Color(0xF00A0F1C)
    val StrokeSubtle = Color(0xFF232E48)
    val StrokeStrong = Color(0xFF344366)

    val GlassFill = Color(0x0AFFFFFF)
    val GlassFillStrong = Color(0x14FFFFFF)
    val GlassBorder = Color(0x1FFFFFFF)
    val GlassSheen = Color(0x22FFFFFF)

    val BrandStart = Color(0xFF1E4FBF)
    val BrandEnd = Color(0xFF14B8A6)
    val BrandPrimary = Color(0xFF4C82F0)
    val BrandPrimaryOn = Color.White

    val AccentViolet = Color(0xFF7C7AF0)
    val AccentCyan = Color(0xFF2DD4C6)
    val AccentPink = Color(0xFFEC6BAE)
    val AccentAmber = Color(0xFFE0A855)
    val AccentGreen = Color(0xFF4ADE80)
    val AccentBlue = Color(0xFF5B9BFF)

    val TileVioletBg = Color(0x297C7AF0)
    val TileCyanBg = Color(0x292DD4C6)
    val TilePinkBg = Color(0x29EC6BAE)
    val TileAmberBg = Color(0x29E0A855)
    val TileGreenBg = Color(0x294ADE80)
    val TileBlueBg = Color(0x295B9BFF)

    val StatusSuccess = Color(0xFF4ADE80)
    val StatusSuccessBg = Color(0xFF0E2B22)
    val StatusWarning = Color(0xFFE0A855)
    val StatusWarningBg = Color(0xFF302408)
    val StatusDanger = Color(0xFFFF6B7A)
    val StatusDangerBg = Color(0xFF351019)
    val StatusInfo = Color(0xFF5B9BFF)
    val StatusInfoBg = Color(0xFF0D2038)
    val StatusNeutral = Color(0xFF8E96B8)
    val StatusNeutralBg = Color(0xFF171F30)

    val TextPrimary = Color(0xFFF3F5FA)
    val TextSecondary = Color(0xFFA9B1C6)
    val TextMuted = Color(0xFF6B7690)
}

private inline fun tok(light: Color, dark: Color): Color = if (ThemeController.isDark) dark else light

val BgBase: Color get() = tok(Light.Bg, Dark.Bg)
val BgElevated1: Color get() = tok(Light.Elevated1, Dark.Elevated1)
val BgElevated2: Color get() = tok(Light.Elevated2, Dark.Elevated2)
val BgElevated3: Color get() = tok(Light.Elevated3, Dark.Elevated3)
val NavBarBg: Color get() = tok(Light.NavBarBg, Dark.NavBarBg)
val StrokeSubtle: Color get() = tok(Light.StrokeSubtle, Dark.StrokeSubtle)
val StrokeStrong: Color get() = tok(Light.StrokeStrong, Dark.StrokeStrong)

val GlassFill: Color get() = tok(Light.GlassFill, Dark.GlassFill)
val GlassFillStrong: Color get() = tok(Light.GlassFillStrong, Dark.GlassFillStrong)
val GlassBorder: Color get() = tok(Light.GlassBorder, Dark.GlassBorder)
val GlassSheen: Color get() = tok(Light.GlassSheen, Dark.GlassSheen)

val BrandStart: Color get() = tok(Light.BrandStart, Dark.BrandStart)
val BrandEnd: Color get() = tok(Light.BrandEnd, Dark.BrandEnd)
val BrandPrimary: Color get() = tok(Light.BrandPrimary, Dark.BrandPrimary)
val BrandPrimaryOn: Color get() = tok(Light.BrandPrimaryOn, Dark.BrandPrimaryOn)

val AccentViolet: Color get() = tok(Light.AccentViolet, Dark.AccentViolet)
val AccentCyan: Color get() = tok(Light.AccentCyan, Dark.AccentCyan)
val AccentPink: Color get() = tok(Light.AccentPink, Dark.AccentPink)
val AccentAmber: Color get() = tok(Light.AccentAmber, Dark.AccentAmber)
val AccentGreen: Color get() = tok(Light.AccentGreen, Dark.AccentGreen)
val AccentBlue: Color get() = tok(Light.AccentBlue, Dark.AccentBlue)

val TileVioletBg: Color get() = tok(Light.TileVioletBg, Dark.TileVioletBg)
val TileCyanBg: Color get() = tok(Light.TileCyanBg, Dark.TileCyanBg)
val TilePinkBg: Color get() = tok(Light.TilePinkBg, Dark.TilePinkBg)
val TileAmberBg: Color get() = tok(Light.TileAmberBg, Dark.TileAmberBg)
val TileGreenBg: Color get() = tok(Light.TileGreenBg, Dark.TileGreenBg)
val TileBlueBg: Color get() = tok(Light.TileBlueBg, Dark.TileBlueBg)

val StatusSuccess: Color get() = tok(Light.StatusSuccess, Dark.StatusSuccess)
val StatusSuccessBg: Color get() = tok(Light.StatusSuccessBg, Dark.StatusSuccessBg)
val StatusWarning: Color get() = tok(Light.StatusWarning, Dark.StatusWarning)
val StatusWarningBg: Color get() = tok(Light.StatusWarningBg, Dark.StatusWarningBg)
val StatusDanger: Color get() = tok(Light.StatusDanger, Dark.StatusDanger)
val StatusDangerBg: Color get() = tok(Light.StatusDangerBg, Dark.StatusDangerBg)
val StatusInfo: Color get() = tok(Light.StatusInfo, Dark.StatusInfo)
val StatusInfoBg: Color get() = tok(Light.StatusInfoBg, Dark.StatusInfoBg)
val StatusNeutral: Color get() = tok(Light.StatusNeutral, Dark.StatusNeutral)
val StatusNeutralBg: Color get() = tok(Light.StatusNeutralBg, Dark.StatusNeutralBg)

val TextPrimary: Color get() = tok(Light.TextPrimary, Dark.TextPrimary)
val TextSecondary: Color get() = tok(Light.TextSecondary, Dark.TextSecondary)
val TextMuted: Color get() = tok(Light.TextMuted, Dark.TextMuted)
