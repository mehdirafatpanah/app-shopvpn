package com.shopvpn.admin

import android.app.Application
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.network.ApiClient

class ShopVpnAdminApp : Application() {

    lateinit var session: SessionManager
        private set
    lateinit var api: ApiClient
        private set

    override fun onCreate() {
        super.onCreate()
        session = SessionManager(this)
        api = ApiClient(session)
    }
}
