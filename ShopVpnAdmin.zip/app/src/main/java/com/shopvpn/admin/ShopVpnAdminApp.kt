package com.shopvpn.admin

import android.app.Application
import android.webkit.WebView
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.data.local.LocalCacheRepository
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.push.NotificationHelper

class ShopVpnAdminApp : Application() {

    lateinit var session: SessionManager
        private set
    lateinit var api: ApiClient
        private set
    lateinit var cache: LocalCacheRepository
        private set

    override fun onCreate() {
        super.onCreate()
        // فقط در بیلد دیباگ (همون APK ای که GitHub Actions می‌سازه): با این خط
        // می‌تونی از chrome://inspect (روی کامپیوتر، گوشی با USB وصل) داخل
        // WebView تب‌های «webview» (پیام همگانی، بنرها، دکمه‌های ربات و ...)
        // رو با Console/Network واقعی ببینی — دقیقاً همونی که لازم داریم برای
        // فهمیدن چرا یک تب فقط یک صفحه‌ی سیاه/خالی نشون می‌ده.
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }
        session = SessionManager(this)
        api = ApiClient(session)
        cache = LocalCacheRepository(this)

        // کانال نوتیف باید همین‌جا و همیشه ساخته بشه، نه فقط وقتی پوشی می‌رسه؛
        // وگرنه اولین نوتیفی که وقتی اپ بسته است می‌رسه، اندروید خودش یه کانال
        // ضعیف (بدون heads-up) می‌سازه که دیگه قابل اصلاح نیست.
        NotificationHelper.ensureChannel(this)
    }
}
