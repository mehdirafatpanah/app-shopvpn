package com.shopvpn.admin.sdui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.SectionLabel
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private fun JsonObject?.numOf(key: String): Double? =
    this?.get(key)?.takeIf { !it.isJsonNull && it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble

private fun JsonObject?.strOf(key: String): String? =
    this?.get(key)?.takeIf { !it.isJsonNull }?.asString

private fun JsonObject?.objOf(key: String): JsonObject? =
    this?.get(key)?.takeIf { it.isJsonObject }?.asJsonObject

@Composable
private fun UsageBar(label: String, percent: Double?, detail: String) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("${percent?.toInt() ?: 0}٪", style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = ((percent ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f),
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = if ((percent ?: 0.0) > 85) StatusDanger else BrandPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(detail, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

/**
 * تب «سیستم و نگهداری»: آمار لحظه‌ای CPU/RAM/دیسک، وضعیت یادآوری‌های
 * خودکار، موجودی کم محصولات و وضعیت بکاپ + گرفتن بکاپ فوری.
 *
 * «بازیابی از فایل بکاپ» و «بازنشانی کارخانه‌ای» فقط وقتی که سرور آن‌ها را
 * در پیکربندی فرستاده باشد نشان داده می‌شوند (یعنی فقط برای owner - همان
 * محدودیت require_owner سمت سرور)، چون هر دو مخرب/غیرقابل‌برگشت‌اند؛ هر دو
 * علاوه بر تاییدیه‌ی دوگانه‌ی محلی، سمت سرور هم عبارت تاییدی دقیق (RESTORE /
 * RESET) الزامی دارند.
 */
@Composable
fun SystemScreen(tab: TabConfig, api: ApiClient) {
    var stats by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var jobs by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var backup by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var creatingBackup by remember(tab.id) { mutableStateOf(false) }
    var restoring by remember(tab.id) { mutableStateOf(false) }
    var resetting by remember(tab.id) { mutableStateOf(false) }
    var pendingRestoreUri by remember(tab.id) { mutableStateOf<android.net.Uri?>(null) }
    var restoreConfirmText by remember(tab.id) { mutableStateOf("") }
    var showResetDialog by remember(tab.id) { mutableStateOf(false) }
    var resetConfirmText by remember(tab.id) { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val pickBackupFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingRestoreUri = uri
            restoreConfirmText = ""
        }
    }

    suspend fun load() {
        loading = true
        error = null
        try {
            tab.source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { stats = it.asJsonObject } }
            tab.jobs_source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { jobs = it.asJsonObject } }
            tab.backup_status_source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { backup = it.asJsonObject } }
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری وضعیت سیستم"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    suspend fun createBackup() {
        val endpoint = tab.backup_create_endpoint ?: return
        creatingBackup = true
        try {
            val res = api.post(endpoint)
            val o = res.takeIf { it.isJsonObject }?.asJsonObject
            snackbarHostState.showSnackbar(
                "بکاپ گرفته شد (${o.numOf("size_mb")?.let { "%.1f".format(it) } ?: "?"} مگابایت) — به ${o.numOf("sent")?.toInt() ?: 0} ادمین ارسال شد",
            )
            load()
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "گرفتن بکاپ ناموفق بود")
        } finally {
            creatingBackup = false
        }
    }

    suspend fun restoreBackup(uri: android.net.Uri) {
        val endpoint = tab.backup_restore_endpoint ?: return
        restoring = true
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("فایل خوانده نشد.")
            val res = api.uploadFileWithFields(
                endpoint, "file", "restore.db", "application/octet-stream", bytes,
                textFields = mapOf("confirm_phrase" to restoreConfirmText.trim()),
            )
            val o = res.takeIf { it.isJsonObject }?.asJsonObject
            snackbarHostState.showSnackbar("بازیابی انجام شد. بکاپ قبل از بازیابی: ${o.strOf("pre_restore_backup") ?: "?"}")
            pendingRestoreUri = null
            restoreConfirmText = ""
            load()
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "بازیابی ناموفق بود")
        } finally {
            restoring = false
        }
    }

    suspend fun factoryReset() {
        val endpoint = tab.factory_reset_endpoint ?: return
        resetting = true
        try {
            api.postForm(endpoint, mapOf("confirm_phrase" to resetConfirmText.trim()))
            snackbarHostState.showSnackbar("بازگشت به حالت کارخانه انجام شد.")
            showResetDialog = false
            resetConfirmText = ""
            load()
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "بازنشانی ناموفق بود")
        } finally {
            resetting = false
        }
    }


    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null && stats == null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                else -> Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    SectionLabel("منابع سرور")
                    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            val cpu = stats.objOf("cpu")
                            val ram = stats.objOf("ram")
                            val disk = stats.objOf("disk")
                            UsageBar("پردازنده (CPU)", cpu.numOf("percent"), "${cpu.numOf("cores")?.toInt() ?: "?"} هسته")
                            UsageBar(
                                "حافظه (RAM)", ram.numOf("percent"),
                                "${ram.numOf("used_gb")} از ${ram.numOf("total_gb")} گیگ",
                            )
                            UsageBar(
                                "دیسک", disk.numOf("percent"),
                                "${disk.numOf("used_gb")} از ${disk.numOf("total_gb")} گیگ",
                            )
                        }
                    }

                    val renewal = jobs.objOf("renewal")
                    if (renewal != null) {
                        SectionLabel("یادآوری‌های تمدید/حجم")
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("آخرین اجرا: ${renewal.strOf("last_run") ?: "هنوز اجرا نشده"}", style = MaterialTheme.typography.bodySmall)
                                Text("یادآوری تاریخ ارسال‌شده: ${renewal.numOf("last_date_sent")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                                Text("یادآوری حجم ارسال‌شده: ${renewal.numOf("last_volume_sent")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (backup != null) {
                        SectionLabel("بکاپ دیتابیس")
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("آخرین بکاپ: ${backup.strOf("last_backup_at") ?: "ثبت نشده"}", style = MaterialTheme.typography.bodySmall)
                                Text("حجم آخرین بکاپ: ${backup.numOf("last_backup_size_mb") ?: "—"} مگابایت", style = MaterialTheme.typography.bodySmall)
                                Text("تعداد نسخه‌های نگه‌داشته‌شده: ${backup.numOf("count")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { scope.launch { createBackup() } }, enabled = !creatingBackup) {
                                    if (creatingBackup) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("📥 گرفتن بکاپ فوری و ارسال به تلگرام")
                                }
                                Spacer(Modifier.height(6.dp))
                                if (tab.backup_restore_endpoint != null) {
                                    OutlinedButton(
                                        onClick = { pickBackupFileLauncher.launch(arrayOf("application/octet-stream", "application/vnd.sqlite3", "*/*")) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { Text("📤 بازیابی از فایل بکاپ (.db)") }
                                } else {
                                    Text(
                                        "بازیابی از فایل بکاپ و حذف فایل‌های یتیم فقط از پنل وب (دسکتاپ) در دسترس است.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted,
                                    )
                                }
                            }
                        }
                    }

                    if (tab.factory_reset_endpoint != null) {
                        SectionLabel("منطقه‌ی خطر")
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    "بازگشت به حالت کارخانه همه‌ی داده‌ی فروشگاه را پاک می‌کند و فقط خودت (owner) باقی می‌مانی. یک بکاپ ایمنی خودکار قبل از پاک‌سازی گرفته می‌شود، اما این عملیات در خودِ فروشگاه غیرقابل‌بازگشت است.",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                                Spacer(Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { showResetDialog = true },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                                ) { Text("⚠️ بازنشانی کارخانه‌ای") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (pendingRestoreUri != null && tab.backup_restore_endpoint != null) {
        AlertDialog(
            onDismissRequest = { if (!restoring) { pendingRestoreUri = null; restoreConfirmText = "" } },
            title = { Text("بازیابی دیتابیس از فایل") },
            text = {
                Column {
                    Text(
                        "این کار کل دیتابیس فعلی را با فایل انتخاب‌شده جایگزین می‌کند و غیرقابل‌برگشت است (به‌جز از روی بکاپ دیگر). برای تایید، عبارت RESTORE را دقیقاً تایپ کن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = restoreConfirmText,
                        onValueChange = { restoreConfirmText = it },
                        placeholder = { Text("RESTORE") },
                        singleLine = true,
                        enabled = !restoring,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { val uri = pendingRestoreUri; if (uri != null) scope.launch { restoreBackup(uri) } },
                    enabled = !restoring && restoreConfirmText.trim().uppercase() == "RESTORE",
                ) {
                    if (restoring) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("بازیابی", color = StatusDanger)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreUri = null; restoreConfirmText = "" }, enabled = !restoring) { Text("انصراف") }
            },
        )
    }

    if (showResetDialog && tab.factory_reset_endpoint != null) {
        AlertDialog(
            onDismissRequest = { if (!resetting) { showResetDialog = false; resetConfirmText = "" } },
            title = { Text("بازنشانی کارخانه‌ای") },
            text = {
                Column {
                    Text(
                        "همه‌ی داده‌ی این فروشگاه پاک می‌شود. برای تایید، عبارت RESET را دقیقاً تایپ کن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = resetConfirmText,
                        onValueChange = { resetConfirmText = it },
                        placeholder = { Text("RESET") },
                        singleLine = true,
                        enabled = !resetting,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { scope.launch { factoryReset() } },
                    enabled = !resetting && resetConfirmText.trim().uppercase() == "RESET",
                ) {
                    if (resetting) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("بازنشانی", color = StatusDanger)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false; resetConfirmText = "" }, enabled = !resetting) { Text("انصراف") }
            },
        )
    }
}
