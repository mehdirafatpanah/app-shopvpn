package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.SectionLabel
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private fun JsonObject?.numOf(key: String): Double? =
    this?.get(key)?.takeIf { !it.isJsonNull && it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble

private fun JsonObject?.strOf(key: String): String? =
    this?.get(key)?.takeIf { !it.isJsonNull }?.asString

private fun JsonObject?.objOf(key: String): JsonObject? =
    this?.get(key)?.takeIf { it.isJsonObject }?.asJsonObject

@Composable
private fun UsageBar(label: String, percent: Double?, detail: String) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("${percent?.toInt() ?: 0}٪", style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = ((percent ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f),
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = if ((percent ?: 0.0) > 85) StatusDanger else BrandPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(detail, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

/**
 * تب «سیستم و نگهداری»: آمار لحظه‌ای CPU/RAM/دیسک، وضعیت یادآوری‌های
 * خودکار، موجودی کم محصولات و وضعیت بکاپ + گرفتن بکاپ فوری.
 *
 * عمداً «بازیابی از فایل بکاپ» و «حذف فایل‌های یتیم» این‌جا نیامده — چون
 * بازیابی، کل دیتابیس را جایگزین می‌کند و یک لمس اشتباه روی موبایل ریسک
 * بسیار بزرگی است؛ این دو عملیات مخرب فعلاً فقط در پنل وب (روی دسکتاپ) در
 * دسترس می‌مانند.
 */
@Composable
fun SystemScreen(tab: TabConfig, api: ApiClient) {
    var stats by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var jobs by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var backup by remember(tab.id) { mutableStateOf<JsonObject?>(null) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var creatingBackup by remember(tab.id) { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            tab.source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { stats = it.asJsonObject } }
            tab.jobs_source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { jobs = it.asJsonObject } }
            tab.backup_status_source?.let { s -> api.get(s).takeIf { it.isJsonObject }?.let { backup = it.asJsonObject } }
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری وضعیت سیستم"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    suspend fun createBackup() {
        val endpoint = tab.backup_create_endpoint ?: return
        creatingBackup = true
        try {
            val res = api.post(endpoint)
            val o = res.takeIf { it.isJsonObject }?.asJsonObject
            snackbarHostState.showSnackbar(
                "بکاپ گرفته شد (${o.numOf("size_mb")?.let { "%.1f".format(it) } ?: "?"} مگابایت) — به ${o.numOf("sent")?.toInt() ?: 0} ادمین ارسال شد",
            )
            load()
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "گرفتن بکاپ ناموفق بود")
        } finally {
            creatingBackup = false
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null && stats == null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                else -> Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    SectionLabel("منابع سرور")
                    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            val cpu = stats.objOf("cpu")
                            val ram = stats.objOf("ram")
                            val disk = stats.objOf("disk")
                            UsageBar("پردازنده (CPU)", cpu.numOf("percent"), "${cpu.numOf("cores")?.toInt() ?: "?"} هسته")
                            UsageBar(
                                "حافظه (RAM)", ram.numOf("percent"),
                                "${ram.numOf("used_gb")} از ${ram.numOf("total_gb")} گیگ",
                            )
                            UsageBar(
                                "دیسک", disk.numOf("percent"),
                                "${disk.numOf("used_gb")} از ${disk.numOf("total_gb")} گیگ",
                            )
                        }
                    }

                    val renewal = jobs.objOf("renewal")
                    if (renewal != null) {
                        SectionLabel("یادآوری‌های تمدید/حجم")
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("آخرین اجرا: ${renewal.strOf("last_run") ?: "هنوز اجرا نشده"}", style = MaterialTheme.typography.bodySmall)
                                Text("یادآوری تاریخ ارسال‌شده: ${renewal.numOf("last_date_sent")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                                Text("یادآوری حجم ارسال‌شده: ${renewal.numOf("last_volume_sent")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (backup != null) {
                        SectionLabel("بکاپ دیتابیس")
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("آخرین بکاپ: ${backup.strOf("last_backup_at") ?: "ثبت نشده"}", style = MaterialTheme.typography.bodySmall)
                                Text("حجم آخرین بکاپ: ${backup.numOf("last_backup_size_mb") ?: "—"} مگابایت", style = MaterialTheme.typography.bodySmall)
                                Text("تعداد نسخه‌های نگه‌داشته‌شده: ${backup.numOf("count")?.toInt() ?: 0}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { scope.launch { createBackup() } }, enabled = !creatingBackup) {
                                    if (creatingBackup) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("📥 گرفتن بکاپ فوری و ارسال به تلگرام")
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "بازیابی از فایل بکاپ و حذف فایل‌های یتیم فقط از پنل وب (دسکتاپ) در دسترس است.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
