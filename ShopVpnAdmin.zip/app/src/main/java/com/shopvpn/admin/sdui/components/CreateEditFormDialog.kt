package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.CreateEditFormConfig
import com.shopvpn.admin.data.model.FormFieldConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import kotlinx.coroutines.launch

/** گزینه‌های یک select_remote/multiselect را از هر شکل پاسخ ممکن (آرایه‌ی
 * رشته، آرایه‌ی آبجکت، یا آبجکتی با یک کلید محصور مثل items/results/permissions)
 * استخراج می‌کند. */
private fun parseRemoteOptions(root: JsonElement, valueKey: String, labelKey: String): List<List<String>> {
    val arr: JsonArray = when {
        root.isJsonArray -> root.asJsonArray
        root.isJsonObject -> {
            val obj = root.asJsonObject
            val wrapped = listOf("items", "results", "data", "permissions").firstNotNullOfOrNull { k ->
                if (obj.has(k) && obj[k].isJsonArray) obj[k].asJsonArray else null
            }
            wrapped ?: JsonArray()
        }
        else -> JsonArray()
    }
    return arr.mapNotNull { el ->
        when {
            el.isJsonPrimitive -> listOf(el.asString, el.asString)
            el.isJsonObject -> {
                val o = el.asJsonObject
                val v = o[valueKey]?.let { if (it.isJsonPrimitive) it.asString else null } ?: return@mapNotNull null
                val l = o[labelKey]?.let { if (it.isJsonPrimitive) it.asString else null } ?: v
                listOf(v, l)
            }
            else -> null
        }
    }
}

private fun putTypedValue(body: JsonObject, field: FormFieldConfig, raw: String) {
    when (field.type) {
        "bool" -> body.addProperty(field.key, raw == "1" || raw == "true")
        "number" -> {
            if (raw.isBlank()) {
                if (field.nullable) body.add(field.key, JsonNull.INSTANCE) else body.addProperty(field.key, 0)
                return
            }
            val d = raw.toDoubleOrNull() ?: 0.0
            if (d == d.toLong().toDouble()) body.addProperty(field.key, d.toLong()) else body.addProperty(field.key, d)
        }
        "select_remote" -> {
            if (raw.isBlank()) {
                body.add(field.key, JsonNull.INSTANCE)
            } else {
                val n = raw.toLongOrNull()
                if (n != null) body.addProperty(field.key, n) else body.addProperty(field.key, raw)
            }
        }
        "multiselect" -> {
            val arr = JsonArray()
            raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { arr.add(it) }
            body.add(field.key, arr)
        }
        "text", "textarea", "password", "color" -> {
            if (raw.isBlank() && field.nullable) body.add(field.key, JsonNull.INSTANCE)
            else body.addProperty(field.key, raw)
        }
        "json" -> {
            val text = raw.ifBlank { "{}" }
            val parsed = try {
                com.google.gson.JsonParser.parseString(text)
            } catch (e: Exception) {
                throw IllegalArgumentException("«${field.label}» یک JSON معتبر نیست: ${e.message}")
            }
            body.add(field.key, parsed)
        }
        else -> body.addProperty(field.key, raw)
    }
}

/**
 * دیالوگ عمومی ساخت/ویرایش: از روی CreateEditFormConfig (که سرور در
 * /api/app/config برای یک تب "list" می‌فرستد) یک فرم native می‌سازد. برای
 * فیلدهای select_remote، گزینه‌ها را در لحظه‌ی باز شدن از options_source
 * می‌گیرد. هیچ فیلدی این‌جا هاردکد نیست - افزودن فیلد جدید در سرور همان لحظه
 * در فرم موبایل ظاهر می‌شود.
 */
@Composable
fun CreateEditFormDialog(
    config: CreateEditFormConfig,
    api: ApiClient,
    idValue: String? = null,
    initialValues: Map<String, String> = emptyMap(),
    onDismiss: () -> Unit,
    onSaved: () -> Unit,
) {
    var values by remember { mutableStateOf(initialValues) }
    var resolvedFields by remember { mutableStateOf(config.fields) }
    var loadingOptions by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(config) {
        loadingOptions = true
        resolvedFields = config.fields.map { field ->
            if (field.type == "select_remote" && field.options_source != null) {
                try {
                    val res = api.get(field.options_source)
                    var opts = parseRemoteOptions(res, field.option_value_key, field.option_label_key)
                    if (field.nullable) opts = listOf(listOf("", "— بدون انتخاب —")) + opts
                    field.copy(options = opts)
                } catch (e: Exception) {
                    field
                }
            } else field
        }
        loadingOptions = false
    }

    suspend fun save() {
        saving = true
        error = null
        try {
            val body = JsonObject()
            resolvedFields.forEach { f -> putTypedValue(body, f, values[f.key] ?: "") }
            val endpoint = config.submit_url.replace("{id}", idValue ?: "")
            if (config.method.equals("PUT", true)) api.put(endpoint, body.toString())
            else api.post(endpoint, body.toString())
            onSaved()
        } catch (e: Exception) {
            error = e.message ?: "خطا در ذخیره"
        } finally {
            saving = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TopAppBar(
                    title = { Text(config.title) },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت")
                        }
                    },
                    actions = {
                        TextButton(onClick = { scope.launch { save() } }, enabled = !saving) {
                            if (saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("ذخیره")
                            }
                        }
                    },
                )

                if (error != null) {
                    Text(
                        error!!,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                    )
                }

                if (loadingOptions) {
                    Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(resolvedFields.filter { f ->
                            f.depends_on == null || (values[f.depends_on] == "1" || values[f.depends_on] == "true")
                        }) { field ->
                            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.padding(12.dp)) {
                                    if (field.type == "multiselect") {
                                        MultiSelectField(
                                            field = field,
                                            value = values[field.key] ?: "",
                                            onValueChange = { values = values + (field.key to it) },
                                        )
                                    } else {
                                        val effective = if (field.type == "select_remote") field.copy(type = "select") else field
                                        FormFieldInput(
                                            field = effective,
                                            value = values[field.key] ?: "",
                                            onValueChange = { values = values + (field.key to it) },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MultiSelectField(field: FormFieldConfig, value: String, onValueChange: (String) -> Unit) {
    val selected = value.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    Column {
        Text(field.label, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        field.options.forEach { opt ->
            val optValue = opt.getOrNull(0) ?: ""
            val optLabel = opt.getOrNull(1) ?: optValue
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(optLabel, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                Checkbox(
                    checked = optValue in selected,
                    onCheckedChange = { checked ->
                        val newSet = if (checked) selected + optValue else selected - optValue
                        onValueChange(newSet.joinToString(","))
                    },
                )
            }
        }
    }
}
