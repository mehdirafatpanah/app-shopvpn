package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private fun JsonObject.s(k: String) = this[k]?.takeIf { !it.isJsonNull }?.asString ?: ""
private fun JsonObject.n(k: String) = this[k]?.takeIf { !it.isJsonNull && it.isJsonPrimitive }?.asDouble ?: 0.0

@Composable
fun ResellersScreen(tab: TabConfig, api: ApiClient) {
    var rows by remember(tab.id) { mutableStateOf<List<JsonObject>>(emptyList()) }
    var query by remember(tab.id) { mutableStateOf("") }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            val root = api.get("/api/resellers")
            rows = when {
                root.isJsonArray -> root.asJsonArray.mapNotNull { it.takeIf { x -> x.isJsonObject }?.asJsonObject }
                root.isJsonObject && root.asJsonObject["items"]?.isJsonArray == true -> root.asJsonObject["items"].asJsonArray.mapNotNull { it.takeIf { x -> x.isJsonObject }?.asJsonObject }
                root.isJsonObject && root.asJsonObject["resellers"]?.isJsonArray == true -> root.asJsonObject["resellers"].asJsonArray.mapNotNull { it.takeIf { x -> x.isJsonObject }?.asJsonObject }
                else -> emptyList()
            }
        } catch (e: Exception) { error = e.message ?: "خطا در دریافت نمایندگی‌ها" }
        finally { loading = false }
    }
    LaunchedEffect(tab.id) { load() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("جستجو در نمایندگی‌ها...") })
            IconButton({ scope.launch { load() } }) { Icon(Icons.Filled.Refresh, "تازه‌سازی") }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(error!!, textAlign = TextAlign.Center); Button({ scope.launch { load() } }) { Text("تلاش دوباره") } } }
            else -> {
                val filtered = rows.filter { r -> query.isBlank() || r.s("telegram_id").contains(query) || r.s("username").contains(query, true) || r.s("first_name").contains(query, true) }
                if (filtered.isEmpty()) EmptyState(title = "نماینده‌ای برای نمایش نیست")
                else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.s("telegram_id") }) { r ->
                        val active = r["is_reseller"]?.takeIf { !it.isJsonNull }?.asBoolean ?: false
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(r.s("first_name").ifBlank { r.s("username").ifBlank { "کاربر #${r.s("telegram_id")}" } }, style = MaterialTheme.typography.titleMedium)
                                        Text("Telegram ID: ${r.s("telegram_id")}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    }
                                    StatusChip(if (active) "فعال" else "غیرفعال")
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("اعتبار: ${r.n("reseller_credit_gb").toInt()} GB", color = TextMuted)
                                    Text("فروش: ${r.n("sold_configs").toInt()} کانفیگ / ${r.n("sold_volume_gb")} GB", color = TextMuted)
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        scope.launch {
                                            val body = JsonObject(); body.addProperty("enabled", !active)
                                            try { api.post("/api/resellers/${r.s("telegram_id")}/status", body.toString()); load() } catch (e: Exception) { error = e.message }
                                        }
                                    }, colors = ButtonDefaults.buttonColors(containerColor = if (active) StatusDanger else StatusSuccess)) { Text(if (active) "غیرفعال" else "فعال") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
