package com.shopvpn.admin.sdui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusDangerBg
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.StatusSuccessBg
import com.shopvpn.admin.ui.theme.StatusWarning
import com.shopvpn.admin.ui.theme.StatusWarningBg
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

private fun JsonObject.s(k: String) = this[k]?.takeIf { !it.isJsonNull }?.asString ?: ""
private fun JsonObject.n(k: String) = this[k]?.takeIf { !it.isJsonNull && it.isJsonPrimitive }?.asDouble ?: 0.0
private fun JsonObject.bool(k: String): Boolean {
    val el = this[k] ?: return false
    if (el.isJsonNull || !el.isJsonPrimitive) return false
    val p = el.asJsonPrimitive
    return when {
        p.isBoolean -> p.asBoolean
        // ستون‌های is_active/is_reseller/web_panel_enabled و مشابه در دیتابیس
        // INTEGER (0/1) هستند و بدون تبدیل صریح (مثل is_blocked در /api/users)
        // به JSON فرستاده می‌شوند؛ Gson روی JsonPrimitive عددی، .asBoolean را
        // با Boolean.parseBoolean(toString()) حساب می‌کند که برای هم "0" و هم
        // "1" مقدار false برمی‌گرداند - یعنی همه‌ی نماینده‌ها همیشه «غیرفعال»
        // نشان داده می‌شدند حتی وقتی واقعاً فعال بودند. اینجا خود عدد را
        // مستقیم می‌خوانیم تا این مشکل رفع شود.
        p.isNumber -> p.asDouble != 0.0
        p.isString -> p.asString == "true" || p.asString == "1"
        else -> false
    }
}

private fun jsonArrayOf(root: com.google.gson.JsonElement): List<JsonObject> =
    if (root.isJsonArray) root.asJsonArray.mapNotNull { it.takeIf { x -> x.isJsonObject }?.asJsonObject } else emptyList()

private fun statusLabel(status: String) = when (status) {
    "pending_review" -> "در انتظار بررسی"
    "awaiting_payment" -> "در انتظار پرداخت"
    "awaiting_payment_review" -> "در انتظار تایید رسید"
    "awaiting_bot_info" -> "در انتظار توکن بات"
    "completed" -> "تکمیل‌شده"
    "rejected" -> "ردشده"
    "payment_rejected" -> "پرداخت ردشده"
    "cancelled" -> "کنسل‌شده"
    else -> status
}

private val RESELLER_REQUEST_OPEN_STATUSES =
    setOf("pending_review", "awaiting_payment", "awaiting_payment_review", "awaiting_bot_info")

@Composable
fun ResellersScreen(tab: TabConfig, api: ApiClient) {
    var subTab by remember(tab.id) { mutableStateOf("bots") }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                "bots" to "نماینده‌های کامل",
                "credit" to "نمایندگی اعتباری",
                "requests" to "درخواست‌ها",
            ).forEach { (v, label) ->
                FilterChip(selected = subTab == v, onClick = { subTab = v }, label = { Text(label) }, modifier = Modifier.weight(1f))
            }
        }
        when (subTab) {
            "bots" -> ResellerBotsTab(api)
            "credit" -> ResellerCreditTab(api)
            else -> ResellerRequestsTab(api)
        }
    }
}

// ------------------------------------------------------------- نماینده‌های کامل (سطح ۱)

@Composable
private fun ResellerBotsTab(api: ApiClient) {
    var rows by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var manageTarget by remember { mutableStateOf<JsonObject?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            rows = jsonArrayOf(api.get("/api/reseller-bots"))
        } catch (e: Exception) {
            error = e.message ?: "خطا در دریافت نماینده‌ها"
        } finally {
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    when {
        loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Button({ scope.launch { load() } }) { Text("تلاش دوباره") }
            }
        }
        else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${rows.size} نماینده‌ی صاحب بات", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                    IconButton({ scope.launch { load() } }) { Icon(Icons.Filled.Refresh, "تازه‌سازی") }
                }
            }
            if (rows.isEmpty()) {
                item { EmptyState(title = "هیچ نماینده‌ی صاحب باتی ثبت نشده") }
            } else {
                items(rows, key = { it.n("id").toInt() }) { b ->
                    val isFull = b.n("reseller_level").toInt() == 1
                    val active = b.bool("is_active")
                    ElevatedAppCard(Modifier.fillMaxWidth().clickable { manageTarget = b }) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(b.s("owner_name").ifBlank { "مالک #${b.n("owner_telegram_id").toLong()}" }, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        b.s("bot_username").let { if (it.isNotBlank()) "@$it" else "بدون یوزرنیم بات" },
                                        style = MaterialTheme.typography.bodySmall, color = TextMuted,
                                    )
                                }
                                StatusChip(if (active) "فعال" else "غیرفعال")
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isFull) "سطح: کامل" else "سطح: ۲", color = TextMuted)
                                Text("${b.n("revenue_toman").toLong()} تومان / ${b.n("paid_orders").toInt()} سفارش", color = TextMuted)
                            }
                        }
                    }
                }
            }
        }
    }

    manageTarget?.let { bot ->
        ResellerBotManageDialog(
            bot = bot, api = api,
            onDismiss = { manageTarget = null },
            onChanged = { manageTarget = null; scope.launch { load() } },
        )
    }
}

@Composable
private fun ResellerBotManageDialog(bot: JsonObject, api: ApiClient, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val botId = bot.n("id").toInt()
    val isFull = bot.n("reseller_level").toInt() == 1
    val active = bot.bool("is_active")
    val webPanelEnabled = bot.bool("web_panel_enabled")
    var ownerName by remember { mutableStateOf(bot.s("owner_name")) }
    var ownerId by remember { mutableStateOf(bot.n("owner_telegram_id").toLong().toString()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var purgeDb by remember { mutableStateOf(false) }
    var loginLink by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    fun run(action: suspend () -> Unit) {
        scope.launch {
            busy = true; error = null
            try { action() } catch (e: Exception) { error = e.message ?: "خطا" }
            finally { busy = false }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TopAppBar(
                    title = { Text("مدیریت نماینده #$botId") },
                    navigationIcon = { IconButton(onDismiss) { Icon(Icons.Filled.ArrowBackIosNew, "بازگشت") } },
                )
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
                }
                if (info != null) {
                    Text(info!!, color = StatusSuccess, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
                }
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("وضعیت فعلی: ${if (active) "فعال" else "غیرفعال"} — سطح: ${if (isFull) "کامل" else "۲"}")
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = { run { api.post("/api/reseller-bots/$botId/toggle"); onChanged() } },
                                    enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = if (active) StatusDanger else StatusSuccess),
                                ) { Text(if (active) "غیرفعال کردن" else "فعال کردن") }
                            }
                        }
                    }
                    item {
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("مشخصات مالک", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(ownerName, { ownerName = it }, label = { Text("نام مالک") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    ownerId, { ownerId = it }, label = { Text("آیدی عددی تلگرام مالک") }, singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                                )
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    run {
                                        val idVal = ownerId.trim().toLongOrNull()
                                        val body = JsonObject()
                                        if (ownerName.isNotBlank()) body.addProperty("owner_name", ownerName) else body.add("owner_name", JsonNull.INSTANCE)
                                        if (idVal != null) body.addProperty("owner_telegram_id", idVal) else body.add("owner_telegram_id", JsonNull.INSTANCE)
                                        api.put("/api/reseller-bots/$botId", body.toString())
                                        info = "ذخیره شد."
                                    }
                                }, enabled = !busy) { Text("ذخیره مشخصات مالک") }
                            }
                        }
                    }
                    item {
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("سطح نمایندگی", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    run {
                                        val body = JsonObject().apply { addProperty("level", if (isFull) 2 else 1) }
                                        api.post("/api/reseller-bots/$botId/level", body.toString())
                                        onChanged()
                                    }
                                }, enabled = !busy) { Text("تغییر به «${if (isFull) "سطح ۲ (محدود)" else "کامل"}»") }
                            }
                        }
                    }
                    if (isFull) {
                        item {
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("پنل وب اختصاصی", style = MaterialTheme.typography.titleSmall)
                                    Spacer(Modifier.height(8.dp))
                                    if (webPanelEnabled) {
                                        Button(onClick = {
                                            run {
                                                val r = api.get("/api/reseller-bots/$botId/web-panel/login-link")
                                                loginLink = r.asJsonObject.s("login_link")
                                            }
                                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("نمایش لینک ورود ثابت") }
                                        Spacer(Modifier.height(8.dp))
                                        Button(onClick = {
                                            run {
                                                val r = api.post("/api/reseller-bots/$botId/web-panel/regenerate")
                                                info = if (r.asJsonObject.bool("sent_to_owner")) "لینک جدید ساخته و برای نماینده ارسال شد." else "لینک ساخته شد ولی ارسال به نماینده ناموفق بود."
                                            }
                                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("ساخت لینک راه‌اندازی جدید") }
                                        Spacer(Modifier.height(8.dp))
                                        Button(
                                            onClick = { run { api.post("/api/reseller-bots/$botId/web-panel/disable"); onChanged() } },
                                            enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                                        ) { Text("غیرفعال کردن پنل وب") }
                                    } else {
                                        Button(onClick = {
                                            run {
                                                val r = api.post("/api/reseller-bots/$botId/web-panel/enable")
                                                info = if (r.asJsonObject.bool("sent_to_owner")) "پنل وب فعال شد و لینک راه‌اندازی برای نماینده ارسال شد." else "پنل وب فعال شد ولی ارسال لینک ناموفق بود."
                                                onChanged()
                                            }
                                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("فعال‌سازی پنل وب") }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Button(
                                    onClick = { confirmDelete = true }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                                ) { Text("حذف این نماینده") }
                            }
                        }
                    }
                }
            }
        }
    }

    loginLink?.let { link ->
        AlertDialog(
            onDismissRequest = { loginLink = null },
            title = { Text("لینک ورود ثابت پنل وب") },
            text = {
                Column {
                    Text(link)
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { clipboard.setText(AnnotatedString(link)) }) {
                        Icon(Icons.Filled.ContentCopy, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp)); Text("کپی")
                    }
                }
            },
            confirmButton = { TextButton({ loginLink = null }) { Text("بستن") } },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف نماینده") },
            text = {
                Column {
                    Text("آیا از حذف نماینده #$botId مطمئنی؟ این کار برگشت‌پذیر نیست.")
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { purgeDb = !purgeDb }) {
                        Checkbox(checked = purgeDb, onCheckedChange = { purgeDb = it })
                        Text("دیتابیس این نماینده هم کامل پاک شود")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    run { api.delete("/api/reseller-bots/$botId?purge_db=$purgeDb"); onChanged() }
                }) { Text("حذف قطعی", color = StatusDanger) }
            },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("انصراف") } },
        )
    }
}

// --------------------------------------------------------- نمایندگی اعتباری (سطح ۲)

@Composable
private fun ResellerCreditTab(api: ApiClient) {
    var rows by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var creditTarget by remember { mutableStateOf<String?>(null) }
    var panelTarget by remember { mutableStateOf<JsonObject?>(null) }
    var logTarget by remember { mutableStateOf<String?>(null) }
    var findDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            rows = jsonArrayOf(api.get("/api/resellers"))
        } catch (e: Exception) {
            error = e.message ?: "خطا در دریافت نمایندگی‌ها"
        } finally {
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("جستجو در نمایندگی‌ها...") })
            IconButton({ findDialog = true }) { Icon(Icons.Filled.Add, "فعال‌سازی نماینده با آیدی") }
            IconButton({ scope.launch { load() } }) { Icon(Icons.Filled.Refresh, "تازه‌سازی") }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Button({ scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            else -> {
                val filtered = rows.filter { r ->
                    query.isBlank() || r.s("telegram_id").contains(query) ||
                        r.s("username").contains(query, true) || r.s("first_name").contains(query, true)
                }
                if (filtered.isEmpty()) {
                    EmptyState(title = "نماینده‌ی اعتباری‌ای ثبت نشده", subtitle = "از دکمه‌ی + بالا با آیدی عددی تلگرام، نمایندگی فعال کن.")
                } else {
                    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filtered, key = { it.s("telegram_id") }) { r ->
                            val active = r.bool("is_reseller")
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(r.s("first_name").ifBlank { r.s("username").ifBlank { "کاربر #${r.s("telegram_id")}" } }, style = MaterialTheme.typography.titleMedium)
                                            Text("Telegram ID: ${r.s("telegram_id")}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                        }
                                        StatusChip(if (active) "فعال" else "غیرفعال")
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("اعتبار: ${r.n("reseller_credit_gb").toInt()} GB", color = TextMuted)
                                        Text("فروش: ${r.n("sold_configs").toInt()} کانفیگ / ${r.n("sold_volume_gb")} GB", color = TextMuted)
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton({ creditTarget = r.s("telegram_id") }) { Text("اعتبار") }
                                        OutlinedButton({ panelTarget = r }) { Text("پنل") }
                                        OutlinedButton({ logTarget = r.s("telegram_id") }) { Text("تاریخچه") }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                try {
                                                    val body = JsonObject().apply { addProperty("enabled", !active) }
                                                    api.post("/api/resellers/${r.s("telegram_id")}/status", body.toString()); load()
                                                } catch (e: Exception) { error = e.message }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (active) StatusDanger else StatusSuccess),
                                    ) { Text(if (active) "غیرفعال" else "فعال") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    creditTarget?.let { tgId ->
        ResellerCreditDialog(tgId = tgId, api = api, onDismiss = { creditTarget = null }, onSaved = { creditTarget = null; scope.launch { load() } })
    }
    panelTarget?.let { r ->
        ResellerPanelDialog(r = r, api = api, onDismiss = { panelTarget = null }, onSaved = { panelTarget = null; scope.launch { load() } })
    }
    logTarget?.let { tgId ->
        ResellerLogDialog(tgId = tgId, api = api, onDismiss = { logTarget = null })
    }
    if (findDialog) {
        ResellerFindDialog(api = api, onDismiss = { findDialog = false }, onChanged = { findDialog = false; scope.launch { load() } })
    }
}

@Composable
private fun ResellerCreditDialog(tgId: String, api: ApiClient, onDismiss: () -> Unit, onSaved: () -> Unit) {
    var delta by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنظیم اعتبار حجمی #$tgId") },
        text = {
            Column {
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp))
                OutlinedTextField(
                    delta, { delta = it }, label = { Text("مقدار (گیگ، منفی برای کسر)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(reason, { reason = it }, label = { Text("دلیل (اختیاری)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val d = delta.trim().toIntOrNull()
                if (d == null || d == 0) { error = "مقدار نامعتبر است."; return@TextButton }
                scope.launch {
                    busy = true
                    try {
                        val body = JsonObject().apply {
                            addProperty("delta_gb", d)
                            if (reason.isNotBlank()) addProperty("reason", reason)
                        }
                        api.post("/api/resellers/$tgId/credit", body.toString())
                        onSaved()
                    } catch (e: Exception) { error = e.message ?: "خطا"; busy = false }
                }
            }) { Text("ثبت") }
        },
        dismissButton = { TextButton(onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun ResellerPanelDialog(r: JsonObject, api: ApiClient, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val tgId = r.s("telegram_id")
    var panels by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loadingPanels by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf(r.n("reseller_panel_id").let { if (it > 0) it.toInt().toString() else "" }) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        try {
            panels = jsonArrayOf(api.get("/api/reseller-panels-lite")).map { o -> o.n("id").toInt().toString() to o.s("name") }
        } catch (e: Exception) {
            error = e.message
        } finally {
            loadingPanels = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پنل اختصاصی نماینده #$tgId") },
        text = {
            Column {
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
                if (loadingPanels) {
                    CircularProgressIndicator(Modifier.size(20.dp))
                } else {
                    Box {
                        OutlinedButton({ expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(panels.firstOrNull { it.first == selected }?.second ?: "پیش‌فرض خودکار")
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            DropdownMenuItem(text = { Text("پیش‌فرض خودکار") }, onClick = { selected = ""; expanded = false })
                            panels.forEach { (id, name) ->
                                DropdownMenuItem(text = { Text(name) }, onClick = { selected = id; expanded = false })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                scope.launch {
                    busy = true
                    try {
                        val body = JsonObject()
                        val idVal = selected.toIntOrNull()
                        if (idVal != null) body.addProperty("panel_server_id", idVal) else body.add("panel_server_id", JsonNull.INSTANCE)
                        api.post("/api/resellers/$tgId/panel", body.toString())
                        onSaved()
                    } catch (e: Exception) { error = e.message ?: "خطا"; busy = false }
                }
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun ResellerLogDialog(tgId: String, api: ApiClient, onDismiss: () -> Unit) {
    var rows by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        try {
            rows = jsonArrayOf(api.get("/api/resellers/$tgId/log"))
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تاریخچه اعتبار #$tgId") },
        text = {
            when {
                loading -> CircularProgressIndicator(Modifier.size(20.dp))
                error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
                rows.isEmpty() -> Text("رکوردی نیست.")
                else -> Box(Modifier.heightIn(max = 320.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(rows) { l ->
                            val delta = l.n("delta_gb").toInt()
                            Column {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(l.s("created_at"), style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    Text("${if (delta > 0) "+" else ""}$delta", color = if (delta > 0) StatusSuccess else StatusDanger)
                                }
                                if (l.s("reason").isNotBlank()) Text(l.s("reason"), style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("بستن") } },
    )
}

@Composable
private fun ResellerFindDialog(api: ApiClient, onDismiss: () -> Unit, onChanged: () -> Unit) {
    var idInput by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<JsonObject?>(null) }
    var isReseller by remember { mutableStateOf(false) }
    var creditFor by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun search() {
        val id = idInput.trim()
        if (id.toLongOrNull() == null) { error = "آیدی نامعتبر است."; return }
        scope.launch {
            loading = true; error = null; found = null
            try {
                val res = api.get("/api/users/$id").asJsonObject
                found = res
                isReseller = res.bool("is_reseller")
            } catch (e: Exception) {
                error = "کاربری با این آیدی پیدا نشد؛ باید حداقل یک‌بار بات را استارت کرده باشد."
            } finally {
                loading = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جستجوی کاربر برای نمایندگی") },
        text = {
            Column {
                Text(
                    "آیدی عددی تلگرام کاربر را وارد کن؛ کاربر باید قبلاً حداقل یک‌بار بات را استارت کرده باشد.",
                    style = MaterialTheme.typography.bodySmall, color = TextMuted,
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        idInput, { idInput = it }, Modifier.weight(1f), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), placeholder = { Text("آیدی عددی تلگرام") },
                    )
                    IconButton({ search() }) { Icon(Icons.Filled.Search, "جستجو") }
                }
                if (loading) { Spacer(Modifier.height(8.dp)); CircularProgressIndicator(Modifier.size(20.dp)) }
                if (error != null) { Spacer(Modifier.height(8.dp)); Text(error!!, color = MaterialTheme.colorScheme.error) }
                found?.let { data ->
                    val user = data["user"]?.takeIf { it.isJsonObject }?.asJsonObject
                    val name = user?.s("first_name")?.ifBlank { user.s("username") }?.ifBlank { "#$idInput" } ?: "#$idInput"
                    Spacer(Modifier.height(10.dp))
                    ElevatedAppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(name, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            StatusChip(if (isReseller) "نماینده‌ی فعال" else "نماینده نیست")
                            Spacer(Modifier.height(4.dp))
                            Text("اعتبار فعلی: ${data.n("reseller_credit").toInt()} گیگ", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                val body = JsonObject().apply { addProperty("enabled", !isReseller) }
                                                api.post("/api/resellers/$idInput/status", body.toString())
                                                isReseller = !isReseller
                                                onChanged()
                                            } catch (e: Exception) { error = e.message }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isReseller) StatusDanger else StatusSuccess),
                                ) { Text(if (isReseller) "غیرفعال کردن نمایندگی" else "فعال‌سازی نمایندگی") }
                                OutlinedButton({ creditFor = idInput.trim() }) { Text("تنظیم اعتبار") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("بستن") } },
    )

    creditFor?.let { tgId ->
        ResellerCreditDialog(tgId = tgId, api = api, onDismiss = { creditFor = null }, onSaved = { creditFor = null; onChanged() })
    }
}

// -------------------------------------------------------------- درخواست‌های نمایندگی

@Composable
private fun RequestStatusChip(status: String) {
    val (fg, bg) = when (status) {
        "completed" -> StatusSuccess to StatusSuccessBg
        "rejected", "payment_rejected", "cancelled" -> StatusDanger to StatusDangerBg
        else -> StatusWarning to StatusWarningBg
    }
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(statusLabel(status), style = MaterialTheme.typography.labelMedium, color = fg)
    }
}

@Composable
private fun ResellerRequestsTab(api: ApiClient) {
    var all by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var filter by remember { mutableStateOf("open") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var manageTarget by remember { mutableStateOf<JsonObject?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true; error = null
        try {
            all = jsonArrayOf(api.get("/api/reseller-requests"))
        } catch (e: Exception) {
            error = e.message ?: "خطا در دریافت درخواست‌ها"
        } finally {
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    val filtered = when (filter) {
        "open" -> all.filter { RESELLER_REQUEST_OPEN_STATUSES.contains(it.s("status")) }
        "all" -> all
        else -> all.filter { it.s("status") == filter }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("open" to "باز", "all" to "همه", "completed" to "تکمیل‌شده", "rejected" to "ردشده", "cancelled" to "کنسل‌شده").forEach { (v, l) ->
                FilterChip(selected = filter == v, onClick = { filter = v }, label = { Text(l) })
            }
            Spacer(Modifier.weight(1f))
            IconButton({ scope.launch { load() } }) { Icon(Icons.Filled.Refresh, "تازه‌سازی") }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Button({ scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            filtered.isEmpty() -> EmptyState(title = "درخواستی در این وضعیت نیست")
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.n("id").toInt() }) { r ->
                    ElevatedAppCard(Modifier.fillMaxWidth().clickable { manageTarget = r }) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    r.s("username").let { if (it.isNotBlank()) "@$it" else "#${r.n("user_id").toLong()}" },
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                RequestStatusChip(r.s("status"))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "حجم: ${r.n("volume_gb").toInt()} گیگ" +
                                    (if (r.n("price_toman") > 0) " — هزینه: ${r.n("price_toman").toLong()} تومان" else ""),
                                color = TextMuted,
                            )
                        }
                    }
                }
            }
        }
    }

    manageTarget?.let { req ->
        ResellerRequestManageDialog(
            req = req, api = api,
            onDismiss = { manageTarget = null },
            onChanged = { manageTarget = null; scope.launch { load() } },
        )
    }
}

@Composable
private fun ResellerRequestManageDialog(req: JsonObject, api: ApiClient, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val reqId = req.n("id").toInt()
    val status = req.s("status")
    var price by remember { mutableStateOf("") }
    var panels by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var selectedPanel by remember { mutableStateOf("") }
    var panelExpanded by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var showRejectFor by remember { mutableStateOf<String?>(null) }
    var receiptBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(status) {
        if (status == "pending_review") {
            try {
                panels = jsonArrayOf(api.get("/api/reseller-panels-lite")).map { o -> o.n("id").toInt().toString() to o.s("name") }
            } catch (_: Exception) { /* اختیاری */ }
        }
    }

    fun run(action: suspend () -> Unit) {
        scope.launch {
            busy = true; error = null
            try { action() } catch (e: Exception) { error = e.message ?: "خطا" }
            finally { busy = false }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TopAppBar(
                    title = { Text("درخواست نمایندگی #$reqId") },
                    navigationIcon = { IconButton(onDismiss) { Icon(Icons.Filled.ArrowBackIosNew, "بازگشت") } },
                )
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
                }
                if (info != null) {
                    Text(info!!, color = StatusSuccess, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
                }
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        ElevatedAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("کاربر: " + req.s("username").let { if (it.isNotBlank()) "@$it" else "#${req.n("user_id").toLong()}" })
                                Text("حجم درخواستی: ${req.n("volume_gb").toInt()} گیگ")
                                if (req.s("request_text").isNotBlank()) Text("توضیحات: ${req.s("request_text")}")
                                Text("وضعیت: ${statusLabel(status)}")
                                if (req.n("price_toman") > 0) Text("هزینه‌ی ثبت‌شده: ${req.n("price_toman").toLong()} تومان")
                                if (req.s("reject_reason").isNotBlank()) Text("دلیل رد: ${req.s("reject_reason")}")
                            }
                        }
                    }
                    if (status == "pending_review") {
                        item {
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    OutlinedTextField(
                                        price, { price = it }, label = { Text("هزینه‌ی نمایندگی (تومان)") }, singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Box {
                                        OutlinedButton({ panelExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text(panels.firstOrNull { it.first == selectedPanel }?.second ?: "پنل اختصاصی: پیش‌فرض خودکار")
                                        }
                                        DropdownMenu(expanded = panelExpanded, onDismissRequest = { panelExpanded = false }) {
                                            DropdownMenuItem(text = { Text("پیش‌فرض خودکار") }, onClick = { selectedPanel = ""; panelExpanded = false })
                                            panels.forEach { (id, name) -> DropdownMenuItem(text = { Text(name) }, onClick = { selectedPanel = id; panelExpanded = false }) }
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Button(onClick = {
                                        val p = price.trim().toIntOrNull()
                                        if (p == null || p <= 0) { error = "مبلغ نامعتبر است." } else {
                                            run {
                                                val body = JsonObject().apply {
                                                    addProperty("price_toman", p)
                                                    selectedPanel.toIntOrNull()?.let { addProperty("panel_server_id", it) }
                                                }
                                                api.post("/api/reseller-requests/$reqId/quote", body.toString())
                                                onChanged()
                                            }
                                        }
                                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("تایید و ارسال هزینه به کاربر") }
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = { showRejectFor = "rejected" }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                                    ) { Text("رد درخواست") }
                                }
                            }
                        }
                    }
                    if (status == "awaiting_payment_review") {
                        item {
                            ElevatedAppCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Button(onClick = {
                                        run {
                                            val res = api.get("/api/reseller-requests/$reqId/receipt-base64").asJsonObject
                                            val bytes = Base64.decode(res.s("data_base64"), Base64.DEFAULT)
                                            receiptBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                        }
                                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("نمایش رسید پرداخت") }
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = { run { api.post("/api/reseller-requests/$reqId/approve-payment"); onChanged() } },
                                        enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                    ) { Text("تایید پرداخت") }
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = { showRejectFor = "payment_rejected" }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                                    ) { Text("رد پرداخت") }
                                }
                            }
                        }
                    }
                    if (status !in setOf("pending_review", "awaiting_payment_review") && status !in RESELLER_REQUEST_OPEN_STATUSES) {
                        item { Text("در وضعیت فعلی، عملیاتی جز لغو دستی روی این درخواست ممکن نیست.", color = TextMuted, modifier = Modifier.padding(horizontal = 4.dp)) }
                    }
                    if (RESELLER_REQUEST_OPEN_STATUSES.contains(status)) {
                        item {
                            OutlinedButton(
                                onClick = { run { api.post("/api/reseller-requests/$reqId/cancel"); onChanged() } },
                                enabled = !busy, modifier = Modifier.fillMaxWidth(),
                            ) { Text("لغو دستی این درخواست") }
                        }
                    }
                }
            }
        }
    }

    receiptBitmap?.let { bmp ->
        Dialog(onDismissRequest = { receiptBitmap = null }) {
            Image(bitmap = bmp.asImageBitmap(), contentDescription = "رسید پرداخت")
        }
    }

    showRejectFor?.let { kind ->
        var reason by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRejectFor = null },
            title = { Text("دلیل رد") },
            text = {
                OutlinedTextField(reason, { reason = it }, label = { Text("دلیل رد (برای کاربر ارسال می‌شود)") }, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = {
                    if (reason.isBlank()) { error = "دلیل رد الزامی است." } else {
                        val k = kind
                        showRejectFor = null
                        run {
                            val body = JsonObject().apply { addProperty("reason", reason); addProperty("kind", k) }
                            api.post("/api/reseller-requests/$reqId/reject", body.toString())
                            onChanged()
                        }
                    }
                }) { Text("ثبت رد") }
            },
            dismissButton = { TextButton({ showRejectFor = null }) { Text("انصراف") } },
        )
    }
}
