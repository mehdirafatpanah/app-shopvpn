package com.shopvpn.admin.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AuroraDarkScheme = darkColorScheme(
    background = BgBase,
    surface = BgElevated1,
    surfaceVariant = BgElevated2,
    surfaceTint = BgElevated2,
    inverseSurface = BgElevated3,
    outline = StrokeSubtle,
    outlineVariant = StrokeSubtle,
    primary = BrandPrimary,
    onPrimary = BrandPrimaryOn,
    primaryContainer = BgElevated2,
    onPrimaryContainer = TextPrimary,
    secondary = AccentCyan,
    onSecondary = Color0F,
    tertiary = AccentPink,
    error = StatusDanger,
    onError = Color0F,
    errorContainer = StatusDangerBg,
    onErrorContainer = StatusDanger,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
)

// متریال ۳ برای onSecondary/onError رنگ تخت می‌خواهد؛ چون همیشه روی چیپ روشن
// می‌نشیند از یک سیاه تقریبی استفاده می‌کنیم تا کنتراست درست بماند.
private val Color0F = androidx.compose.ui.graphics.Color(0xFF0A0C14)

private val AppTypography = Typography(
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, color = TextPrimary, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextPrimary, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextPrimary, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, color = TextSecondary),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, color = TextMuted),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun ShopVpnAdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AuroraDarkScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
