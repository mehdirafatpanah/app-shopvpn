package com.shopvpn.admin.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CyberScheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF251C61),
    onPrimaryContainer = TextPrimary,
    secondary = AccentCyan,
    onSecondary = Color(0xFF00151B),
    secondaryContainer = Color(0xFF073341),
    onSecondaryContainer = TextPrimary,
    tertiary = AccentPink,
    background = BgBase,
    onBackground = TextPrimary,
    surface = BgElevated1,
    onSurface = TextPrimary,
    surfaceVariant = BgElevated2,
    onSurfaceVariant = TextSecondary,
    outline = StrokeSubtle,
    outlineVariant = StrokeSubtle,
    error = StatusDanger,
    onError = Color.White,
    errorContainer = StatusDangerBg,
    onErrorContainer = TextPrimary,
)

private val AppTypography = Typography(
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, color = TextPrimary, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextPrimary, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextPrimary, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, color = TextSecondary, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, color = TextMuted),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

@Composable
fun ShopVpnAdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CyberScheme, typography = AppTypography, shapes = AppShapes, content = content)
}
