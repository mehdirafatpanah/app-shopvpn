package com.shopvpn.admin.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// نگاشت شِمای M3 روی همون توکن‌های Color.kt که خودشون بسته به ThemeController.isDark
// عوض می‌شن — یعنی این‌جا دیگه لازم نیست بین دو ColorScheme جدا انتخاب کنیم، هر دو
// حالت از یک تعریف واحد میان که مقادیرش زنده عوض می‌شه.
private val BankScheme: ColorScheme
    @Composable get() = if (ThemeController.isDark) {
        darkColorScheme(
            primary = BrandPrimary, onPrimary = BrandPrimaryOn,
            primaryContainer = BgElevated3, onPrimaryContainer = TextPrimary,
            secondary = AccentCyan, onSecondary = Color(0xFF00201C),
            secondaryContainer = BgElevated2, onSecondaryContainer = TextPrimary,
            tertiary = AccentViolet,
            background = BgBase, onBackground = TextPrimary,
            surface = BgElevated1, onSurface = TextPrimary,
            surfaceVariant = BgElevated2, onSurfaceVariant = TextSecondary,
            outline = StrokeSubtle, outlineVariant = StrokeSubtle,
            error = StatusDanger, onError = Color.White,
            errorContainer = StatusDangerBg, onErrorContainer = TextPrimary,
        )
    } else {
        lightColorScheme(
            primary = BrandPrimary, onPrimary = BrandPrimaryOn,
            primaryContainer = Color(0xFFDCE7FA), onPrimaryContainer = BrandPrimary,
            secondary = AccentCyan, onSecondary = Color.White,
            secondaryContainer = BgElevated2, onSecondaryContainer = TextPrimary,
            tertiary = AccentViolet,
            background = BgBase, onBackground = TextPrimary,
            surface = BgElevated1, onSurface = TextPrimary,
            surfaceVariant = BgElevated2, onSurfaceVariant = TextSecondary,
            outline = StrokeSubtle, outlineVariant = StrokeSubtle,
            error = StatusDanger, onError = Color.White,
            errorContainer = StatusDangerBg, onErrorContainer = StatusDanger,
        )
    }

// تایپوگرافی «بانکی»: خنثی‌تر و کم‌کنتراست‌تر از نسخه‌ی قبلی (letter-spacing
// منفی شدید و ExtraBold همه‌جا حس اپلیکیشن سرگرمی/گیمینگ می‌داد، نه بانکی).
private val AppTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, color = TextPrimary, letterSpacing = (-0.2).sp),
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, color = TextPrimary, letterSpacing = (-0.1).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 21.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp, color = TextPrimary),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextPrimary, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextPrimary, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, color = TextSecondary, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, color = TextMuted),
)

// شماره‌ی بزرگ کارت‌های خلاصه (مثلاً موجودی/درآمد) — بیرون از مقیاس M3.
val BentoJumboNumber = TextStyle(fontWeight = FontWeight.Bold, fontSize = 32.sp, color = TextPrimary, letterSpacing = (-0.3).sp)

// رادیوس‌های ملایم‌تر و منظم‌تر (۸ تا ۲۴) به‌جای حباب‌های ۲۸-۳۴ نسخه‌ی قبلی —
// زبان بصری اپ‌های بانکی مدرن معمولاً محافظه‌کارتر و کمتر «حباب‌مانند» است.
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun ShopVpnAdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BankScheme, typography = AppTypography, shapes = AppShapes, content = content)
}
