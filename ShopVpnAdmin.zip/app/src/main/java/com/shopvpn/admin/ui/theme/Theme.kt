package com.shopvpn.admin.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val NexusTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, color = TextPrimary, letterSpacing = (-0.5).sp),
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, color = TextPrimary, letterSpacing = (-0.35).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 19.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextPrimary, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextSecondary, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, color = TextSecondary, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 10.5.sp, color = TextMuted),
)

private val NexusShapes = Shapes(
    extraSmall = RoundedCornerShape(7.dp),
    small = RoundedCornerShape(11.dp),
    medium = RoundedCornerShape(15.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp),
)

@Composable
private fun NexusScheme(): ColorScheme = if (ThemeController.isDark) {
    darkColorScheme(
        primary = BrandPrimary, onPrimary = BrandPrimaryOn,
        primaryContainer = BgElevated3, onPrimaryContainer = TextPrimary,
        secondary = AccentCyan, onSecondary = Color(0xFF001A17),
        secondaryContainer = BgElevated2, onSecondaryContainer = TextPrimary,
        tertiary = AccentPink,
        background = BgBase, onBackground = TextPrimary,
        surface = BgElevated1, onSurface = TextPrimary,
        surfaceVariant = BgElevated2, onSurfaceVariant = TextSecondary,
        outline = StrokeSubtle, outlineVariant = StrokeSubtle,
        error = StatusDanger, onError = Color.White,
        errorContainer = StatusDangerBg, onErrorContainer = TextPrimary,
    )
} else {
    lightColorScheme(
        primary = BrandPrimary, onPrimary = BrandPrimaryOn,
        primaryContainer = Color(0xFFE9E8FF), onPrimaryContainer = BrandPrimary,
        secondary = AccentCyan, onSecondary = Color.White,
        secondaryContainer = Color(0xFFDDF7F3), onSecondaryContainer = TextPrimary,
        tertiary = AccentPink,
        background = BgBase, onBackground = TextPrimary,
        surface = BgElevated1, onSurface = TextPrimary,
        surfaceVariant = BgElevated2, onSurfaceVariant = TextSecondary,
        outline = StrokeSubtle, outlineVariant = StrokeSubtle,
        error = StatusDanger, onError = Color.White,
        errorContainer = StatusDangerBg, onErrorContainer = StatusDanger,
    )
}

@Composable
fun ShopVpnAdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexusScheme(),
        typography = NexusTypography,
        shapes = NexusShapes,
        content = content
    )
}
