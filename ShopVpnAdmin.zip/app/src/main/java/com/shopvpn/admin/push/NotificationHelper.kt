package com.shopvpn.admin.push

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.shopvpn.admin.R

// نکته‌ی مهم: بعد از این‌که یک کانال با یک ID ساخته شد، تنظیمات importance/صدا/
// ویبره‌اش برای همیشه قفل می‌شه — هیچ آپدیت کدی نمی‌تونه عوضش کنه، فقط خود
// کاربر از تنظیمات سیستم. به همین دلیله که این ID با نسخه‌ی قبلی (که به‌خاطر
// ساخته‌شدن دیرهنگام و lazy، با importance پیش‌فرض/ضعیف قفل شده بود) فرق داره؛
// این باعث می‌شه کانال از صفر و با تنظیمات درست ساخته بشه.
const val NOTIFICATION_CHANNEL_ID = "shopvpn_admin_alerts_v2"

object NotificationHelper {

    /**
     * باید همیشه از Application.onCreate صدا زده بشه، نه فقط وقتی پوشی می‌رسه.
     * اگر کانال رو فقط داخل PushService.onMessageReceived بسازیم، اولین نوتیفی
     * که وقتی اپ کاملاً بسته/کیل بوده می‌رسه رو خودِ اندروید مستقیم از روی
     * متادیتای منیفست نشون می‌ده — بدون اجرای کد اپ — و چون کانال هنوز وجود
     * نداره، سیستم خودش یه کانال با importance معمولی (بدون heads-up، با صدای
     * عمومی) می‌سازه. بعد از اون قفل می‌مونه و هیچ‌وقت درست نمی‌شه.
     */
    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "اعلان‌های مدیریتی",
            NotificationManager.IMPORTANCE_HIGH, // لازم برای پاپ‌آپ (heads-up) بالای صفحه
        ).apply {
            description = "اعلان‌های مربوط به فروش، تیکت و وضعیت پنل ShopVPN"
            enableLights(true)
            lightColor = ContextCompat.getColor(context, R.color.brand_primary)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 300, 150, 300)
            setSound(soundUri, audioAttributes)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            setShowBadge(true)
        }
        manager.createNotificationChannel(channel)
    }
}
