package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.local.LocalCacheRepository
import com.shopvpn.admin.data.model.FormFieldConfig
import com.shopvpn.admin.data.model.FormSectionConfig
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

/**
 * فرم native که کاملاً از روی "form_sections" که سرور در /api/app/config
 * می‌فرستد ساخته می‌شود — هیچ فیلدی این‌جا هاردکد نیست. اگر فردا در پنل وب/
 * بک‌اند یک تنظیم جدید به settings_schema.py اضافه شود، همین لحظه (با یک
 * بازکردن دوباره‌ی تب) در اپ هم ظاهر می‌شود، بدون نیاز به آپدیت اپ.
 */
@Composable
fun FormScreen(tab: TabConfig, api: ApiClient, cache: LocalCacheRepository) {
    var values by remember(tab.id) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var dirty by remember(tab.id) { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var saving by remember(tab.id) { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val cacheKey = remember(tab.id) { LocalCacheRepository.keyForForm(tab.id) }

    fun applyValues(obj: JsonObject) {
        values = obj.entrySet().associate { (k, v) ->
            k to (if (v.isJsonNull) "" else if (v.isJsonPrimitive) v.asString else v.toString())
        }
    }

    suspend fun load() {
        val loadUrl = tab.load_url
        if (loadUrl == null) {
            error = "این تب پیکربندی نامعتبری دارد (load_url تعریف نشده)."
            loading = false
            return
        }
        // اول کش محلی، برای باز شدن فوری صفحه
        cache.load(cacheKey)?.let { if (it.isJsonObject) applyValues(it.asJsonObject) }
        loading = values.isEmpty()
        error = null
        try {
            val res = api.get(loadUrl)
            if (res.isJsonObject) {
                applyValues(res.asJsonObject)
                cache.save(cacheKey, res)
            }
        } catch (e: Exception) {
            if (values.isEmpty()) error = e.message ?: "خطا در بارگذاری تنظیمات"
            // اگر کش داشتیم، همان را نشان‌داده‌شده نگه دار و خطا را قورت بده
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    fun setValue(key: String, value: String) {
        values = values + (key to value)
        dirty = dirty + key
    }

    suspend fun save() {
        val submitUrl = tab.submit_url ?: return
        saving = true
        val failed = mutableListOf<String>()
        for (key in dirty.toList()) {
            try {
                val body = JsonObject()
                body.addProperty("key", key)
                body.addProperty("value", values[key] ?: "")
                api.post(submitUrl, body.toString())
            } catch (e: Exception) {
                failed += key
            }
        }
        dirty = failed.toSet()
        saving = false
        snackbarHostState.showSnackbar(
            if (failed.isEmpty()) "تغییرات ذخیره شد" else "ذخیره‌ی ${failed.size} مورد ناموفق بود",
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (dirty.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { scope.launch { save() } },
                    icon = {
                        if (saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Filled.Save, contentDescription = null)
                    },
                    text = { Text(if (saving) "در حال ذخیره..." else "ذخیره‌ی تغییرات (${dirty.size})") },
                )
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                    }
                }
                tab.form_sections.isEmpty() -> EmptyState(title = "فیلدی برای نمایش تعریف نشده")
                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    items(tab.form_sections) { section ->
                        FormSectionBlock(section, values, onValueChange = ::setValue)
                    }
                }
            }
        }
    }
}

@Composable
private fun FormSectionBlock(
    section: FormSectionConfig,
    values: Map<String, String>,
    onValueChange: (String, String) -> Unit,
) {
    Column {
        Text(
            section.title,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
        )
        Spacer(Modifier.height(4.dp))
        section.groups.forEach { group ->
            ElevatedAppCard(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        group.title,
                        style = MaterialTheme.typography.labelLarge,
                        color = TextMuted,
                    )
                    Spacer(Modifier.height(10.dp))
                    group.fields.forEachIndexed { index, field ->
                        FormFieldInput(field, values[field.key] ?: "", onValueChange = { onValueChange(field.key, it) })
                        if (index != group.fields.lastIndex) Spacer(Modifier.height(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
internal fun FormFieldInput(field: FormFieldConfig, value: String, onValueChange: (String) -> Unit) {
    when (field.type) {
        "bool" -> {
            val on = value == "1" || value == "true"
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(field.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = on, onCheckedChange = { onValueChange(if (it) "1" else "0") })
            }
        }
        "textarea" -> OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(field.label) },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier.fillMaxWidth(),
        )
        "json" -> OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(field.label) },
            minLines = 6,
            maxLines = 14,
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
            modifier = Modifier.fillMaxWidth(),
        )
        "password" -> {
            var visible by remember { mutableStateOf(false) }
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                label = { Text(field.label) },
                singleLine = true,
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        "number", "number_list", "select_int_nullable" -> OutlinedTextField(
            value = value,
            onValueChange = { new -> if (new.all { it.isDigit() || it == '.' || it == '-' || it == ',' || it == ' ' }) onValueChange(new) },
            label = { Text(field.label) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        "color" -> {
            val parsed = remember(value) {
                try { Color(android.graphics.Color.parseColor(if (value.startsWith("#")) value else "#$value")) }
                catch (e: Exception) { null }
            }
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                label = { Text(field.label) },
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                leadingIcon = {
                    Box(
                        Modifier.size(22.dp)
                            .background(parsed ?: Color.Transparent, MaterialTheme.shapes.small),
                    )
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        "select", "select_int_nullable" -> {
            var expanded by remember { mutableStateOf(false) }
            val currentLabel = field.options.firstOrNull { it.getOrNull(0) == value }?.getOrNull(1) ?: value
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = currentLabel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(field.label) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    field.options.forEach { opt ->
                        val optValue = opt.getOrNull(0) ?: ""
                        val optLabel = opt.getOrNull(1) ?: optValue
                        DropdownMenuItem(text = { Text(optLabel) }, onClick = { onValueChange(optValue); expanded = false })
                    }
                }
            }
        }
        else -> OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(field.label) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
