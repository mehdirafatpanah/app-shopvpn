package com.shopvpn.admin

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import com.google.gson.Gson
import com.shopvpn.admin.data.model.AppConfigResponse
import com.shopvpn.admin.push.registerCurrentFcmToken
import com.shopvpn.admin.sdui.RenderScreen
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.screens.OnboardingScreen
import com.shopvpn.admin.ui.theme.ShopVpnAdminTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShopVpnAdminApp

        setContent {
            ShopVpnAdminTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RootNavigator(app)
                }
            }
        }
    }
}

@Composable
private fun RootNavigator(app: ShopVpnAdminApp) {
    var connected by remember { mutableStateOf(app.session.isConnected) }
    var unlocked by remember { mutableStateOf(!app.session.biometricLockEnabled) }
    val context = LocalContext.current

    if (!connected) {
        OnboardingScreen(app.session, app.api, onConnected = { connected = true })
        return
    }

    if (!unlocked) {
        BiometricGate(onUnlocked = { unlocked = true }, onFallback = { unlocked = true })
        return
    }

    AppShell(app, onLoggedOut = { connected = false; unlocked = !app.session.biometricLockEnabled })
}

@Composable
private fun BiometricGate(onUnlocked: () -> Unit, onFallback: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    LaunchedEffect(Unit) {
        try {
            val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
            val prompt = androidx.biometric.BiometricPrompt(
                activity, executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                        onUnlocked()
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        onFallback() // دستگاه بیومتریک ندارد یا کاربر لغو کرد -> عبور بدون قفل اضافه
                    }
                },
            )
            val info = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به ShopVPN Admin")
                .setSubtitle("برای ادامه هویتت را تایید کن")
                .setNegativeButtonText("انصراف")
                .build()
            prompt.authenticate(info)
        } catch (e: Exception) {
            onFallback()
        }
    }
    Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun AppShell(app: ShopVpnAdminApp, onLoggedOut: () -> Unit) {
    var config by remember { mutableStateOf<AppConfigResponse?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var selectedTabId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val res = app.api.get("/api/app/config")
            val parsed = Gson().fromJson(res, AppConfigResponse::class.java)
            config = parsed
            selectedTabId = parsed.tabs.firstOrNull()?.id
            registerCurrentFcmToken(app)
        } catch (e: Exception) {
            error = e.message ?: "خطا در دریافت پیکربندی از سرور"
        }
    }

    when {
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onLoggedOut) { Text("قطع اتصال و اتصال دوباره") }
            }
        }
        config == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        else -> {
            val tabs = config!!.tabs
            val active = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()
            Scaffold(
                topBar = { TopAppBar(title = { Text(active.title) }) },
                bottomBar = {
                    NavigationBar {
                        tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = tab.id == active.id,
                                onClick = { selectedTabId = tab.id },
                                icon = { Icon(iconFor(tab.icon), contentDescription = tab.title) },
                                label = { Text(tab.title) },
                            )
                        }
                    }
                },
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    RenderScreen(active, app.api, app.session, onLoggedOut)
                }
            }
        }
    }
}
