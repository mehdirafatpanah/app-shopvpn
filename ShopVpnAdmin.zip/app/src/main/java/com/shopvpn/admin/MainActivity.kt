package com.shopvpn.admin

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.fragment.app.FragmentActivity
import com.shopvpn.admin.data.model.AppConfigResponse
import com.shopvpn.admin.data.model.appConfigGson
import com.shopvpn.admin.push.registerCurrentFcmToken
import com.shopvpn.admin.sdui.RenderScreen
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.components.*
import com.shopvpn.admin.ui.screens.AllSectionsScreen
import com.shopvpn.admin.ui.screens.OnboardingScreen
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShopVpnAdminApp
        setContent {
            ShopVpnAdminTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = BgBase) { RootNavigator(app) }
                }
            }
        }
    }
}

@Composable
private fun RootNavigator(app: ShopVpnAdminApp) {
    var connected by remember { mutableStateOf(app.session.isConnected) }
    var unlocked by remember { mutableStateOf(!app.session.biometricLockEnabled) }
    if (!connected) {
        OnboardingScreen(app.session, app.api, onConnected = { connected = true })
        return
    }
    if (!unlocked) {
        BiometricGate(onUnlocked = { unlocked = true }, onFallback = { unlocked = true })
        return
    }
    AppShell(app) { connected = false; unlocked = !app.session.biometricLockEnabled }
}

@Composable
private fun BiometricGate(onUnlocked: () -> Unit, onFallback: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    LaunchedEffect(Unit) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val prompt = androidx.biometric.BiometricPrompt(activity, executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) = onUnlocked()
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onFallback()
                })
            val info = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به ShopVPN Admin")
                .setSubtitle("برای ادامه هویتت را تایید کن")
                .setNegativeButtonText("انصراف").build()
            prompt.authenticate(info)
        } catch (_: Exception) { onFallback() }
    }
    CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
}

@Composable
private fun AppShell(app: ShopVpnAdminApp, onLoggedOut: () -> Unit) {
    var config by remember { mutableStateOf<AppConfigResponse?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var offline by remember { mutableStateOf(false) }
    var selectedTabId by remember { mutableStateOf<String?>(null) }
    var badgeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var showAllSections by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openAppNotificationSettings() {
        try {
            context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
        } catch (_: Exception) {
            try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", context.packageName, null))) } catch (_: Exception) {}
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    fun requestNotificationPermissionOrOpenSettings() {
        if (!app.session.notifPermissionAsked) {
            app.session.notifPermissionAsked = true
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else openAppNotificationSettings()
    }

    LaunchedEffect(Unit) {
        if (!hasNotificationPermission()) requestNotificationPermissionOrOpenSettings()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !app.session.batteryOptimizationAsked) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                app.session.batteryOptimizationAsked = true
                try { context.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:${context.packageName}"))) } catch (_: Exception) {}
            }
        }
    }

    suspend fun loadBadges() {
        try {
            val res = app.api.get("/api/notifications/summary")
            if (res.isJsonObject) badgeCounts = res.asJsonObject.entrySet()
                .filter { it.value.isJsonPrimitive && it.value.asJsonPrimitive.isNumber }
                .associate { it.key to it.value.asInt }
        } catch (_: Exception) {}
    }

    LaunchedEffect(Unit) {
        val cached = try { app.cache.load(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG) } catch (_: Exception) { null }
        if (cached != null) try {
            config = appConfigGson().fromJson(cached, AppConfigResponse::class.java)
            selectedTabId = config?.tabs?.firstOrNull()?.id
            offline = true
        } catch (_: Exception) {}
        try {
            val res = app.api.get("/api/app/config")
            val parsed = appConfigGson().fromJson(res, AppConfigResponse::class.java)
            config = parsed; offline = false
            selectedTabId = selectedTabId?.takeIf { id -> parsed.tabs.any { it.id == id } }
                ?: parsed.tabs.firstOrNull()?.id
            app.cache.save(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG, res)
            registerCurrentFcmToken(app, parsed); loadBadges()
        } catch (e: Exception) {
            if (config == null) error = e.message ?: "خطا در دریافت پیکربندی از سرور" else offline = true
        }
    }

    when {
        error != null -> CyberBackground {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                ElevatedAppCard(Modifier.fillMaxWidth(.86f)) {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        NeonIconTile(Icons.Filled.CloudOff, StatusDanger, size = 52.dp)
                        Spacer(Modifier.height(16.dp))
                        Text("اتصال برقرار نشد", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text(error ?: "خطا در دریافت اطلاعات", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = onLoggedOut, shape = RoundedCornerShape(13.dp)) { Text("اتصال دوباره") }
                    }
                }
            }
        }
        config == null -> CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
        else -> {
            val tabs = config!!.tabs
            if (tabs.isEmpty()) return
            val active = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()
            val bottomTabs = tabs.take(4)

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    NexusTopBar(
                        title = if (showAllSections) "همه بخش‌ها" else active.title,
                        subtitle = if (showAllSections) "${config!!.server_name}  •  پنل ${config!!.tenant}" else null,
                        offline = offline,
                        canGoBack = showAllSections,
                        onBack = { showAllSections = false },
                        onNotifications = {
                            if (!hasNotificationPermission()) requestNotificationPermissionOrOpenSettings()
                            else openAppNotificationSettings()
                            scope.launch { loadBadges() }
                        }
                    )
                },
                bottomBar = {
                    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                        NexusBottomBar(
                            tabs = bottomTabs,
                            activeId = active.id,
                            showAll = showAllSections,
                            badgeCounts = badgeCounts,
                            onTab = { showAllSections = false; selectedTabId = it },
                            onAll = { showAllSections = true }
                        )
                    }
                },
            ) { padding ->
                CyberBackground(Modifier.padding(padding)) {
                    if (showAllSections) {
                        AllSectionsScreen(config!!.server_name, config!!.tenant, tabs, badgeCounts) {
                            selectedTabId = it; showAllSections = false
                        }
                    } else {
                        RenderScreen(active, app.api, app.session, app.cache, onLoggedOut, allTabs = tabs)
                    }
                }
            }
        }
    }
}

@Composable
private fun NexusTopBar(
    title: String,
    subtitle: String?,
    offline: Boolean,
    canGoBack: Boolean,
    onBack: () -> Unit,
    onNotifications: () -> Unit
) {
    Surface(color = Color.Transparent, shadowElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (canGoBack) {
                IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Filled.ArrowForward, "بازگشت", tint = TextPrimary)
                }
                Spacer(Modifier.width(4.dp))
            } else {
                Box(
                    Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
                        .background(Brush.linearGradient(listOf(BrandStart, BrandEnd))),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(11.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (offline) {
                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(StatusWarning))
                        Spacer(Modifier.width(5.dp))
                        Text("حالت آفلاین", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                    } else if (subtitle != null) {
                        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1)
                    } else {
                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(StatusSuccess))
                        Spacer(Modifier.width(5.dp))
                        Text("سیستم آنلاین", style = MaterialTheme.typography.labelSmall, color = StatusSuccess)
                    }
                }
            }
            IconButton(onClick = onNotifications, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Filled.NotificationsNone, "اعلان‌ها", tint = TextSecondary)
            }
        }
    }
}

@Composable
private fun NexusBottomBar(
    tabs: List<com.shopvpn.admin.data.model.TabConfig>,
    activeId: String,
    showAll: Boolean,
    badgeCounts: Map<String, Int>,
    onTab: (String) -> Unit,
    onAll: () -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        color = NavBarBg,
        tonalElevation = 6.dp,
        shadowElevation = 10.dp,
        border = BorderStroke(1.dp, StrokeSubtle)
    ) {
        Row(
            Modifier.padding(horizontal = 6.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                NexusNavItem(
                    icon = iconFor(tab.icon), label = tab.title,
                    selected = tab.id == activeId && !showAll,
                    badgeCount = badgeCounts[tab.id] ?: 0,
                    onClick = { onTab(tab.id) },
                    modifier = Modifier.weight(1f)
                )
            }
            NexusNavItem(
                icon = Icons.Filled.GridView, label = "همه",
                selected = showAll, onClick = onAll, modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun NexusNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    badgeCount: Int = 0,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape)
            .background(if (selected) BrandPrimary.copy(.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BadgedBox(badge = {
            if (badgeCount > 0) Badge(containerColor = AccentPink) {
                Text(if (badgeCount > 9) "9+" else badgeCount.toString())
            }
        }) {
            Icon(icon, null, tint = if (selected) BrandPrimary else TextMuted, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = if (selected) BrandPrimary else TextMuted, maxLines = 1)
    }
}
