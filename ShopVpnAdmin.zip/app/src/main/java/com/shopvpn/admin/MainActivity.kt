package com.shopvpn.admin

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.fragment.app.FragmentActivity
import com.shopvpn.admin.data.model.AppConfigResponse
import com.shopvpn.admin.data.model.appConfigGson
import com.shopvpn.admin.push.registerCurrentFcmToken
import com.shopvpn.admin.sdui.RenderScreen
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.components.CyberBackground
import com.shopvpn.admin.ui.components.NeonIconTile
import com.shopvpn.admin.ui.screens.AllSectionsScreen
import com.shopvpn.admin.ui.screens.OnboardingScreen
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShopVpnAdminApp
        setContent {
            ShopVpnAdminTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = BgBase) { RootNavigator(app) }
                }
            }
        }
    }
}

@Composable
private fun RootNavigator(app: ShopVpnAdminApp) {
    var connected by remember { mutableStateOf(app.session.isConnected) }
    var unlocked by remember { mutableStateOf(!app.session.biometricLockEnabled) }
    if (!connected) {
        OnboardingScreen(app.session, app.api, onConnected = { connected = true })
        return
    }
    if (!unlocked) {
        BiometricGate(onUnlocked = { unlocked = true }, onFallback = { unlocked = true })
        return
    }
    AppShell(app) { connected = false; unlocked = !app.session.biometricLockEnabled }
}

@Composable
private fun BiometricGate(onUnlocked: () -> Unit, onFallback: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    LaunchedEffect(Unit) {
        try {
            val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
            val prompt = androidx.biometric.BiometricPrompt(activity, executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) = onUnlocked()
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onFallback()
                })
            val info = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به ShopVPN Admin").setSubtitle("برای ادامه هویتت را تایید کن")
                .setNegativeButtonText("انصراف").build()
            prompt.authenticate(info)
        } catch (_: Exception) { onFallback() }
    }
    CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
}

@Composable
private fun AppShell(app: ShopVpnAdminApp, onLoggedOut: () -> Unit) {
    var config by remember { mutableStateOf<AppConfigResponse?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var offline by remember { mutableStateOf(false) }
    var selectedTabId by remember { mutableStateOf<String?>(null) }
    var badgeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    // درور کشویی حذف شد؛ بخش‌های خارج از نوار پایین حالا از طریق یک صفحه‌ی
    // تمام‌صفحه‌ی گرید بنتو («همه‌ی بخش‌ها») در دسترس‌اند، نه یک منوی کناری جدا.
    var showAllSections by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED

    fun openAppNotificationSettings() {
        try {
            context.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            )
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.fromParts("package", context.packageName, null))
                )
            } catch (_: Exception) { }
        }
    }

    // اندروید ۱۳+ برای نمایش هر نوتیفیکیشن (از جمله پوش FCM) نیاز به اجازه‌ی
    // صریح کاربر دارد؛ بدون این درخواست، حتی با توکن FCM ثبت‌شده هم نوتیف نشان داده نمی‌شود.
    // نکته‌ی مهم: بعد از یک بار رد کردن توسط کاربر، اندروید دیگه دیالوگ سیستمی رو
    // نشون نمی‌ده (launch() سایلنت هیچ اثری نداره) — پس دفعه‌ی بعد باید مستقیم
    // کاربر رو به صفحه‌ی تنظیمات خودِ اپ بفرستیم، وگرنه کاربر برای همیشه پوش
    // نمی‌گیره و هیچ نشونه‌ای هم نمی‌بینه که چرا.
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* چه اجازه داده شود چه نه، بقیه‌ی اپ بدون مشکل کار می‌کند */ }

    fun requestNotificationPermissionOrOpenSettings() {
        if (!app.session.notifPermissionAsked) {
            app.session.notifPermissionAsked = true
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openAppNotificationSettings()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasNotificationPermission()) {
            requestNotificationPermissionOrOpenSettings()
        }

        // خیلی از گوشی‌ها (شیائومی/MIUI، هواوی، اوپو، ویوو، سامسونگ با «بهینه‌ساز
        // باتری» تهاجمی) اگه اپ رو از پس‌زمینه کیل کنن، پیام FCM اصلاً به کد اپ
        // نمی‌رسه (نه فقط بی‌صداست، اصلاً چیزی نمایش داده نمی‌شه) — این رایج‌ترین
        // دلیل «هیچ نوتیفی نمیاد» با وجود اینکه توکن درست ثبت شده. یک‌بار (نه هر
        // بار که اپ باز می‌شه) از کاربر می‌خوایم اپ رو از بهینه‌سازی باتری معاف کنه.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !app.session.batteryOptimizationAsked) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                app.session.batteryOptimizationAsked = true
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:${context.packageName}"))
                    )
                } catch (_: Exception) { /* بعضی OEM ها این اینتنت رو مسدود می‌کنن؛ بی‌خیالش می‌شیم */ }
            }
        }
    }

    suspend fun loadBadges() {
        try {
            val res = app.api.get("/api/notifications/summary")
            if (res.isJsonObject) badgeCounts = res.asJsonObject.entrySet()
                .filter { it.value.isJsonPrimitive && it.value.asJsonPrimitive.isNumber }
                .associate { it.key to it.value.asInt }
        } catch (_: Exception) { }
    }

    LaunchedEffect(Unit) {
        val cached = try { app.cache.load(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG) } catch (_: Exception) { null }
        if (cached != null) try {
            config = appConfigGson().fromJson(cached, AppConfigResponse::class.java)
            selectedTabId = config?.tabs?.firstOrNull()?.id
            offline = true
        } catch (_: Exception) { }
        try {
            val res = app.api.get("/api/app/config")
            val parsed = appConfigGson().fromJson(res, AppConfigResponse::class.java)
            config = parsed; offline = false
            selectedTabId = selectedTabId?.takeIf { id -> parsed.tabs.any { it.id == id } } ?: parsed.tabs.firstOrNull()?.id
            app.cache.save(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG, res)
            registerCurrentFcmToken(app, parsed); loadBadges()
        } catch (e: Exception) {
            if (config == null) error = e.message ?: "خطا در دریافت پیکربندی از سرور" else offline = true
        }
    }

    when {
        error != null -> CyberBackground {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Card(
                    modifier = Modifier.fillMaxWidth(.86f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BgElevated1),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StrokeSubtle),
                ) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        NeonIconTile(Icons.Filled.CloudOff, StatusDanger)
                        Spacer(Modifier.height(14.dp))
                        Text("اتصال برقرار نشد", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text(error ?: "خطا در دریافت اطلاعات", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onLoggedOut) { Text("اتصال دوباره") }
                    }
                }
            }
        }
        config == null -> CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
        else -> {
            val tabs = config!!.tabs
            if (tabs.isEmpty()) return
            val active = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()
            val bottomTabs = tabs.take(4)

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(if (showAllSections) "همه‌ی بخش‌ها" else active.title, style = MaterialTheme.typography.titleLarge)
                                if (offline) Text("آفلاین • آخرین داده ذخیره‌شده", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                            }
                        },
                        navigationIcon = {
                            if (showAllSections) IconButton(onClick = { showAllSections = false }) { Icon(Icons.Filled.ChevronRight, "بازگشت") }
                        },
                        actions = {
                            if (!offline) IconButton(onClick = {
                                // اگه دسترسی نوتیف داده نشده، درخواستش کن (یا اگه قبلاً رد شده و
                                // دیگه دیالوگ سیستمی نشون داده نمی‌شه، مستقیم تنظیمات اپ رو باز کن)؛
                                // اگه از قبل داده شده، همون تنظیمات نوتیف اپ رو باز کن تا خود کاربر
                                // مطمئن بشه چنل/صدا خاموش نیست — قبلاً این دکمه فقط badge ها رو
                                // رفرش می‌کرد و لمسش هیچ اثر قابل‌مشاهده‌ای نداشت.
                                if (!hasNotificationPermission()) {
                                    requestNotificationPermissionOrOpenSettings()
                                } else {
                                    openAppNotificationSettings()
                                }
                                scope.launch { loadBadges() }
                            }) { Icon(Icons.Filled.NotificationsNone, "اعلان‌ها") }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    )
                },
                bottomBar = {
                    // نوار پایین شناور شیشه‌ای: جای درور کناری + نوار پایین قبلی رو گرفته،
                    // با یک تب اضافه («همه») که به‌جای باز کردن یک منوی کشویی، صفحه‌ی
                    // گرید بنتوی «همه‌ی بخش‌ها» رو باز می‌کنه.
                    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                                .background(Color(0xE60E1018))
                                .border(androidx.compose.foundation.BorderStroke(1.dp, GlassBorder), RoundedCornerShape(28.dp))
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            bottomTabs.forEachIndexed { index, tab ->
                                val count = badgeCounts[tab.id] ?: 0
                                val selected = tab.id == active.id && !showAllSections
                                PillNavItem(
                                    icon = iconFor(tab.icon), label = tab.title, selected = selected, badgeCount = count,
                                    onClick = { showAllSections = false; selectedTabId = tab.id },
                                )
                            }
                            PillNavItem(
                                icon = Icons.Filled.GridView, label = "همه", selected = showAllSections,
                                onClick = { showAllSections = true },
                            )
                        }
                    }
                },
            ) { padding ->
                CyberBackground(Modifier.padding(padding)) {
                    if (showAllSections) {
                        AllSectionsScreen(config!!.server_name, config!!.tenant, tabs, badgeCounts) {
                            selectedTabId = it; showAllSections = false
                        }
                    } else {
                        RenderScreen(active, app.api, app.session, app.cache, onLoggedOut)
                    }
                }
            }
        }
    }
}

@Composable
private fun PillNavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, badgeCount: Int = 0, onClick: () -> Unit) {
    val bg = if (selected) BrandPrimary.copy(.18f) else Color.Transparent
    val fg = if (selected) BrandPrimary else TextMuted
    Column(
        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(bg)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BadgedBox(badge = { if (badgeCount > 0) Badge { Text(if (badgeCount > 9) "9+" else badgeCount.toString()) } }) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = fg, maxLines = 1)
    }
}
