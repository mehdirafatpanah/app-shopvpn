package com.shopvpn.admin.push

import android.os.Build
import com.google.firebase.messaging.FirebaseMessaging
import com.shopvpn.admin.BuildConfig
import com.shopvpn.admin.ShopVpnAdminApp
import kotlinx.coroutines.tasks.await

/** بعد از هر لاگین موفق یک‌بار صدا زده می‌شود تا توکن FCM فعلی دستگاه، صرف‌نظر
 * از اینکه onNewToken() چه زمانی فراخوانی شده، حتماً روی سرور ثبت باشد. */
suspend fun registerCurrentFcmToken(app: ShopVpnAdminApp) {
    if (!BuildConfig.HAS_FIREBASE) return
    try {
        val token = FirebaseMessaging.getInstance().token.await()
        app.api.post(
            "/api/app/fcm-token",
            """{"fcm_token":"$token","device_label":"${Build.MODEL}"}""",
        )
    } catch (_: Exception) {
        // بدون پوش هم بقیه‌ی اپ کار می‌کند؛ دفعه‌ی بعد دوباره تلاش می‌شود
    }
}
