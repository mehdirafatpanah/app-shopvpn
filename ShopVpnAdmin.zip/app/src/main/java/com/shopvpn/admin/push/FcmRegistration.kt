package com.shopvpn.admin.push

import android.os.Build
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.shopvpn.admin.ShopVpnAdminApp
import com.shopvpn.admin.data.model.AppConfigResponse
import kotlinx.coroutines.tasks.await

private const val TAG = "FcmRegistration"

/**
 * برخلاف روش معمول فایربیس (که پروژه از یک google-services.json ثابت در زمان
 * build خوانده می‌شود)، اینجا چون هر خودمیزبان (self-hoster) سرور و پروژه‌ی
 * فایربیس جدای خودش را دارد، پروژه در زمان اجرا -- از همان پاسخ /api/app/config
 * که این کاربر بعد از لاگین می‌گیرد -- ساخته می‌شود. یعنی همین یک APK رسمی
 * (بدون هیچ بیلد دستی) برای همه‌ی نصب‌ها کار می‌کند؛ هرکس فقط باید در پنل وب
 * خودش (تنظیمات > اپ موبایل) ۴ مقدار عمومی پروژه‌ی فایربیسش را وارد کند.
 *
 * اگر سرور هنوز این مقادیر را تنظیم نکرده باشد (خالی)، پوش فقط برای همین سرور
 * غیرفعال می‌ماند و بقیه‌ی اپ عادی کار می‌کند.
 */
private fun ensureFirebaseInitialized(app: ShopVpnAdminApp, config: AppConfigResponse): Boolean {
    val apiKey = config.firebase_api_key?.trim().orEmpty()
    val appId = config.firebase_app_id?.trim().orEmpty()
    val projectId = config.firebase_project_id?.trim().orEmpty()
    val senderId = config.firebase_sender_id?.trim().orEmpty()
    if (apiKey.isEmpty() || appId.isEmpty() || projectId.isEmpty() || senderId.isEmpty()) {
        return false
    }
    // FirebaseApp اجازه‌ی initializeApp دوباره روی همان نام (DEFAULT) را نمی‌دهد؛
    // اگر همین اجرا از قبل مقداردهی شده باشد (مثلاً رفرش دوباره‌ی کانفیگ)، همان
    // را نگه می‌داریم. تغییر واقعی پروژه‌ی فایربیس یک سرور فقط بعد از بستن کامل
    // و باز کردن دوباره‌ی اپ اثر می‌کند.
    if (FirebaseApp.getApps(app).isNotEmpty()) return true
    return try {
        val options = FirebaseOptions.Builder()
            .setApiKey(apiKey)
            .setApplicationId(appId)
            .setProjectId(projectId)
            .setGcmSenderId(senderId)
            .build()
        FirebaseApp.initializeApp(app, options)
        true
    } catch (e: Exception) {
        Log.w(TAG, "مقداردهی فایربیس با تنظیمات این سرور ناموفق بود", e)
        false
    }
}

/** بعد از هر لاگین موفق (و هر بار که /api/app/config با موفقیت گرفته شود) صدا
 * زده می‌شود تا هم فایربیس با پروژه‌ی همین سرور مقداردهی شود و هم توکن FCM
 * فعلی دستگاه، صرف‌نظر از اینکه onNewToken() چه زمانی فراخوانی شده، حتماً روی
 * سرور ثبت باشد. */
suspend fun registerCurrentFcmToken(app: ShopVpnAdminApp, config: AppConfigResponse) {
    if (!ensureFirebaseInitialized(app, config)) return
    try {
        val token = FirebaseMessaging.getInstance().token.await()
        app.api.post(
            "/api/app/fcm-token",
            """{"fcm_token":"$token","device_label":"${Build.MODEL}"}""",
        )
    } catch (_: Exception) {
        // بدون پوش هم بقیه‌ی اپ کار می‌کند؛ دفعه‌ی بعد دوباره تلاش می‌شود
    }
}
