package com.shopvpn.admin.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.ui.theme.*

private data class StatusStyle(val fg: Color, val bg: Color, val label: String)

private fun styleFor(raw: String): StatusStyle = when (raw.trim().lowercase()) {
    "approved", "active", "success", "paid", "online", "unlocked", "closed_ok", "true", "1" ->
        StatusStyle(StatusSuccess, StatusSuccessBg, when (raw.lowercase()) {
            "approved" -> "تایید شده"; "active", "true", "1" -> "فعال"; "online" -> "آنلاین"; else -> raw
        })
    "pending", "processing", "answered", "in_progress" ->
        StatusStyle(StatusWarning, StatusWarningBg, when (raw.lowercase()) {
            "pending" -> "در انتظار"; "answered" -> "پاسخ داده‌شده"; else -> raw
        })
    "rejected", "blocked", "failed", "danger", "offline", "false", "0", "expired" ->
        StatusStyle(StatusDanger, StatusDangerBg, when (raw.lowercase()) {
            "rejected" -> "رد شده"; "blocked" -> "مسدود"; "offline" -> "آفلاین"; "false", "0" -> "غیرفعال"; "expired" -> "منقضی"; else -> raw
        })
    "open" -> StatusStyle(StatusInfo, StatusInfoBg, "باز")
    "closed" -> StatusStyle(StatusNeutral, StatusNeutralBg, "بسته")
    else -> StatusStyle(StatusNeutral, StatusNeutralBg, raw.ifBlank { "—" })
}

@Composable
fun StatusChip(value: String, modifier: Modifier = Modifier) {
    val s = styleFor(value)
    Box(modifier.clip(RoundedCornerShape(50)).background(s.bg).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(s.label, style = MaterialTheme.typography.labelMedium, color = s.fg)
    }
}

@Composable
fun InitialsBadge(text: String, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val letter = text.trim().firstOrNull()?.toString() ?: "?"
    Box(modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(BrandStart, BrandEnd))), contentAlignment = Alignment.Center) {
        Text(letter, color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun BrandGradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(BrandStart, Color(0xFF4C3FD1), BrandEnd)))) {
        Box(Modifier.matchParentSize().background(Brush.radialGradient(listOf(Color.White.copy(.12f), Color.Transparent), radius = 600f)))
        Column(Modifier.padding(20.dp), content = content)
    }
}

@Composable
fun CyberBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBase, Color(0xFF070B17), BgBase))), content = content)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(horizontal = 4.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium, color = TextMuted)
}

@Composable
fun EmptyState(title: String, subtitle: String? = null, icon: ImageVector = Icons.Filled.Inbox, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Box(Modifier.size(68.dp).clip(CircleShape).background(BrandPrimary.copy(.12f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = BrandPrimary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center)
            subtitle?.let { Spacer(Modifier.height(5.dp)); Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted, textAlign = TextAlign.Center) }
        }
    }
}

@Composable
fun ElevatedAppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BgElevated1),
        elevation = CardDefaults.cardElevation(0.dp),
        border = BorderStroke(1.dp, StrokeSubtle),
        content = content,
    )
}

@Composable
fun NeonIconTile(icon: ImageVector, tint: Color = BrandPrimary, modifier: Modifier = Modifier) {
    Box(modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(21.dp))
    }
}
