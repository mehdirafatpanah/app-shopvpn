package com.shopvpn.admin.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.ui.theme.*

private data class StatusStyle(val fg: Color, val bg: Color, val label: String)

private fun styleFor(raw: String): StatusStyle = when (raw.trim().lowercase()) {
    "approved", "active", "success", "paid", "online", "unlocked", "closed_ok", "true", "1" ->
        StatusStyle(StatusSuccess, StatusSuccessBg, when (raw.lowercase()) {
            "approved" -> "تایید شده"; "active", "true", "1" -> "فعال"; "online" -> "آنلاین"; else -> raw
        })
    "pending", "processing", "answered", "in_progress" ->
        StatusStyle(StatusWarning, StatusWarningBg, when (raw.lowercase()) {
            "pending" -> "در انتظار"; "answered" -> "پاسخ داده‌شده"; else -> raw
        })
    "rejected", "blocked", "failed", "danger", "offline", "false", "0", "expired" ->
        StatusStyle(StatusDanger, StatusDangerBg, when (raw.lowercase()) {
            "rejected" -> "رد شده"; "blocked" -> "مسدود"; "offline" -> "آفلاین"; "false", "0" -> "غیرفعال"; "expired" -> "منقضی"; else -> raw
        })
    "open" -> StatusStyle(StatusInfo, StatusInfoBg, "باز")
    "closed" -> StatusStyle(StatusNeutral, StatusNeutralBg, "بسته")
    else -> StatusStyle(StatusNeutral, StatusNeutralBg, raw.ifBlank { "—" })
}

@Composable
fun StatusChip(value: String, modifier: Modifier = Modifier) {
    val s = styleFor(value)
    Box(modifier.clip(RoundedCornerShape(50)).background(s.bg).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(s.label, style = MaterialTheme.typography.labelMedium, color = s.fg)
    }
}

@Composable
fun InitialsBadge(text: String, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val letter = text.trim().firstOrNull()?.toString() ?: "?"
    Box(modifier.size(size).clip(RoundedCornerShape(size / 3)).background(Brush.linearGradient(listOf(BrandStart, BrandEnd))), contentAlignment = Alignment.Center) {
        Text(letter, color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

/**
 * کارت هیرو با گرادیانت برند (سرمه‌ای → فیروزه‌ای) — برای بخش‌های شاخص مثل
 * کارت درآمد یا کارت خوشامد؛ معادل کارتِ حساب/موجودی در اپ‌های بانکی.
 */
@Composable
fun BrandGradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(BrandStart, BrandEnd)))) {
        Box(Modifier.matchParentSize().background(Brush.radialGradient(listOf(Color.White.copy(.10f), Color.Transparent), radius = 620f)))
        Column(Modifier.padding(20.dp), content = content)
    }
}

/**
 * پس‌زمینه‌ی پایه‌ی اپ: یک رنگ صاف (روشن یا تیره، بسته به تم) به‌جای بلاب‌های
 * رنگی قبلی — زبان بصری اپ‌های بانکی معمولاً آرام و کم‌ازدحام است، نه پرانرژی.
 */
@Composable
fun CyberBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize().background(BgBase)) { content() }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(horizontal = 4.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium, color = TextMuted)
}

@Composable
fun EmptyState(title: String, subtitle: String? = null, icon: ImageVector = Icons.Filled.Inbox, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)).background(BrandPrimary.copy(.10f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = BrandPrimary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center)
            subtitle?.let { Spacer(Modifier.height(5.dp)); Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted, textAlign = TextAlign.Center) }
        }
    }
}

/**
 * کارت پایه‌ی سراسر اپ: سطح صاف (نه شیشه‌ای) با حاشیه‌ی ظریف و سایه‌ی خیلی
 * ملایم — الگوی رایج کارت در اپ‌های بانکی به‌جای افکت شیشه/گلو نسخه‌ی قبلی.
 * پارامتر tint اختیاریه و فقط برای شست‌شوی رنگی ملایم کارت‌های آماری استفاده می‌شه.
 */
@Composable
fun ElevatedAppCard(modifier: Modifier = Modifier, tint: Color = Color.Transparent, shape: Shape = RoundedCornerShape(16.dp), content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier
            .shadow(elevation = 1.dp, shape = shape, ambientColor = Color.Black.copy(.06f), spotColor = Color.Black.copy(.06f))
            .clip(shape)
            .background(BgElevated1)
            .background(tint)
            .border(BorderStroke(1.dp, StrokeSubtle), shape),
    ) {
        Column(content = content)
    }
}

@Composable
fun NeonIconTile(icon: ImageVector, tint: Color = BrandPrimary, modifier: Modifier = Modifier, size: Dp = 42.dp) {
    Box(modifier.size(size).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size / 2))
    }
}
