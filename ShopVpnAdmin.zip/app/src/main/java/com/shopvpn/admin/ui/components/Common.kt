package com.shopvpn.admin.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.ui.theme.*

private data class StatusStyle(val fg: Color, val bg: Color, val label: String)

private fun styleFor(raw: String): StatusStyle = when (raw.trim().lowercase()) {
    "approved", "active", "success", "paid", "online", "unlocked", "closed_ok", "true", "1" ->
        StatusStyle(StatusSuccess, StatusSuccessBg, when (raw.lowercase()) {
            "approved" -> "تایید شده"; "active", "true", "1" -> "فعال"; "online" -> "آنلاین"; else -> raw
        })
    "pending", "processing", "answered", "in_progress" ->
        StatusStyle(StatusWarning, StatusWarningBg, when (raw.lowercase()) {
            "pending" -> "در انتظار"; "answered" -> "پاسخ داده‌شده"; else -> raw
        })
    "rejected", "blocked", "failed", "danger", "offline", "false", "0", "expired" ->
        StatusStyle(StatusDanger, StatusDangerBg, when (raw.lowercase()) {
            "rejected" -> "رد شده"; "blocked" -> "مسدود"; "offline" -> "آفلاین"; "false", "0" -> "غیرفعال"; "expired" -> "منقضی"; else -> raw
        })
    "open" -> StatusStyle(StatusInfo, StatusInfoBg, "باز")
    "closed" -> StatusStyle(StatusNeutral, StatusNeutralBg, "بسته")
    else -> StatusStyle(StatusNeutral, StatusNeutralBg, raw.ifBlank { "—" })
}

@Composable
fun StatusChip(value: String, modifier: Modifier = Modifier) {
    val s = styleFor(value)
    Row(
        modifier.clip(RoundedCornerShape(50)).background(s.bg).padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(5.dp).clip(RoundedCornerShape(50)).background(s.fg))
        Spacer(Modifier.width(6.dp))
        Text(s.label, style = MaterialTheme.typography.labelMedium, color = s.fg)
    }
}

@Composable
fun InitialsBadge(text: String, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val letter = text.trim().firstOrNull()?.toString() ?: "?"
    Box(
        modifier.size(size).clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(BrandStart, BrandEnd))),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun BrandGradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier.clip(shape).background(
            Brush.linearGradient(
                colors = listOf(BrandStart, Color(0xFF4C50D9), BrandEnd)
            )
        ).border(BorderStroke(1.dp, Color.White.copy(.12f)), shape)
    ) {
        Box(
            Modifier.matchParentSize().background(
                Brush.radialGradient(
                    listOf(Color.White.copy(.11f), Color.Transparent),
                    radius = 520f
                )
            )
        )
        Column(Modifier.padding(20.dp), content = content)
    }
}

@Composable
fun CyberBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(BrandPrimary.copy(.075f), BgBase, BgBase),
                radius = 820f
            )
        )
    ) {
        // Subtle horizon glow — intentionally restrained so content stays primary.
        Box(
            Modifier.fillMaxWidth().height(220.dp).align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(AccentCyan.copy(.025f), Color.Transparent)))
        )
        content()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(horizontal = 4.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 3.dp, height = 15.dp).clip(RoundedCornerShape(4.dp)).background(BrandPrimary))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
    }
}

@Composable
fun EmptyState(
    title: String,
    subtitle: String? = null,
    icon: ImageVector = Icons.Filled.Inbox,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Box(
                Modifier.size(76.dp).clip(RoundedCornerShape(22.dp))
                    .background(BrandPrimary.copy(.09f))
                    .border(1.dp, BrandPrimary.copy(.14f), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = BrandPrimary, modifier = Modifier.size(31.dp))
            }
            Spacer(Modifier.height(15.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            subtitle?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun ElevatedAppCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.Transparent,
    shape: Shape = RoundedCornerShape(17.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier.shadow(
            elevation = 2.dp,
            shape = shape,
            ambientColor = Color.Black.copy(.12f),
            spotColor = Color.Black.copy(.18f)
        ).clip(shape)
            .background(BgElevated1)
            .background(tint)
            .border(BorderStroke(1.dp, StrokeSubtle), shape)
    ) {
        Column(content = content)
    }
}

@Composable
fun NeonIconTile(
    icon: ImageVector,
    tint: Color = BrandPrimary,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp
) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(13.dp))
            .background(tint.copy(alpha = .13f))
            .border(1.dp, tint.copy(.12f), RoundedCornerShape(13.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size / 2))
    }
}
