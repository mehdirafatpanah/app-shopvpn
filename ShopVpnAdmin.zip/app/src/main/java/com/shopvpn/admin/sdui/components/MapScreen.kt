package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.components.StatusChip
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch
import kotlin.math.min

// همان پروجکشن equirectangular ساده‌ای که world_map.py و app.js استفاده
// می‌کنند (viewBox فرضی ۱۰۰۰×۵۰۰) — تا پین‌ها دقیقاً روی خط ساحلی بیفتند.
private const val MAP_W = 1000f
private const val MAP_H = 500f

private fun project(lat: Double, lon: Double): Offset {
    val x = ((lon + 180.0) / 360.0 * MAP_W).toFloat()
    val y = ((90.0 - lat) / 180.0 * MAP_H).toFloat()
    return Offset(x, y)
}

/** پارسر ساده‌ی مسیر SVG که سرور می‌فرستد: فقط M/L/Z مطلق با اعشار، بدون
 * کمان یا curve — همان چیزی که world_map.py با ".1f" تولید می‌کند. */
private fun parseLandPath(d: String): Path {
    val path = Path()
    val regex = Regex("([ML])(-?[0-9]+\\.?[0-9]*),(-?[0-9]+\\.?[0-9]*)|(Z)")
    for (m in regex.findAll(d)) {
        val cmd = m.groupValues[1].ifEmpty { m.groupValues[4] }
        when (cmd) {
            "M" -> path.moveTo(m.groupValues[2].toFloat(), m.groupValues[3].toFloat())
            "L" -> path.lineTo(m.groupValues[2].toFloat(), m.groupValues[3].toFloat())
            "Z" -> path.close()
        }
    }
    return path
}

private data class MapServer(
    val country: String,
    val countryCode: String,
    val city: String,
    val lat: Double,
    val lon: Double,
    val status: String,
    val ip: String,
    val remark: String,
    val configsCount: Int,
)

private fun parseServers(arr: JsonArray): List<MapServer> = arr.mapNotNull { el ->
    if (!el.isJsonObject) return@mapNotNull null
    val o = el.asJsonObject
    fun str(k: String) = o[k]?.takeIf { !it.isJsonNull }?.asString ?: ""
    val lat = o["lat"]?.takeIf { !it.isJsonNull }?.asDouble
    val lon = o["lon"]?.takeIf { !it.isJsonNull }?.asDouble
    if (lat == null || lon == null) return@mapNotNull null
    MapServer(
        country = str("country"), countryCode = str("country_code"), city = str("city"),
        lat = lat, lon = lon, status = str("status").ifBlank { "unknown" },
        ip = str("ip"), remark = str("remark"),
        configsCount = o["configs_count"]?.takeIf { !it.isJsonNull }?.asInt ?: 1,
    )
}

private fun statusColor(status: String): Color = when (status) {
    "online" -> StatusSuccess
    "offline" -> StatusDanger
    else -> TextMuted
}

private fun statusLabel(status: String): String = when (status) {
    "online" -> "آنلاین"; "offline" -> "آفلاین"; else -> "نامشخص"
}

/**
 * تب «نقشه سرورها»: به‌جای بازکردن داشبورد پنل وب داخل وب‌ویو، مسیر SVG خط
 * ساحلی را از همان اندپوینتی که پنل وب استفاده می‌کند می‌گیرد (سرور خودش آن
 * را از world-atlas ساخته) و با Canvas بومی رسم می‌کند؛ پین هر سرور هم با
 * همان فرمول پروجکشن ساده‌ی lat/lon جای‌گذاری می‌شود.
 */
@Composable
fun MapScreen(tab: TabConfig, api: ApiClient) {
    var landPath by remember(tab.id) { mutableStateOf<Path?>(null) }
    var servers by remember(tab.id) { mutableStateOf<List<MapServer>>(emptyList()) }
    var totalServers by remember(tab.id) { mutableStateOf(0) }
    var totalCountries by remember(tab.id) { mutableStateOf(0) }
    var loading by remember(tab.id) { mutableStateOf(true) }
    var error by remember(tab.id) { mutableStateOf<String?>(null) }
    var selected by remember(tab.id) { mutableStateOf<MapServer?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load(refresh: Boolean = false) {
        loading = true
        error = null
        try {
            if (landPath == null || refresh) {
                val mapRes = api.get(tab.map_source ?: "/api/dashboard/world-map")
                if (mapRes.isJsonObject) {
                    val o = mapRes.asJsonObject
                    val ok = o["ok"]?.takeIf { !it.isJsonNull }?.asBoolean ?: false
                    if (ok) landPath = parseLandPath(o["land_path"]?.asString ?: "")
                }
            }
            val source = tab.source
            if (source == null) {
                error = "این تب پیکربندی نامعتبری دارد."
                return
            }
            val res = api.get(if (refresh) "$source?refresh=1" else source)
            if (res.isJsonObject) {
                val o = res.asJsonObject
                val ok = o["ok"]?.takeIf { !it.isJsonNull }?.asBoolean ?: false
                if (!ok) {
                    val errKey = o["error"]?.takeIf { !it.isJsonNull }?.asString
                    error = if (errKey == "no_link")
                        "لینک ساب اصلی هنوز در تنظیمات ثبت نشده؛ اول آن را تنظیم کن تا نقشه ساخته شود."
                    else errKey ?: "خطا در دریافت نقشه‌ی سرورها"
                    servers = emptyList()
                } else {
                    servers = parseServers(o["servers"]?.takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray())
                    totalServers = o["total_servers"]?.takeIf { !it.isJsonNull }?.asInt ?: 0
                    totalCountries = o["total_countries"]?.takeIf { !it.isJsonNull }?.asInt ?: 0
                }
            }
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری نقشه"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    Box(Modifier.fillMaxSize()) {
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                    Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
            }
            servers.isEmpty() -> EmptyState(title = "سروری برای نمایش پیدا نشد")
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "$totalServers پین در $totalCountries کشور",
                            style = MaterialTheme.typography.titleSmall,
                        )
                        TextButton(onClick = { scope.launch { load(refresh = true) } }) { Text("تازه‌سازی") }
                    }
                }
                item {
                    val path = landPath
                    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(2f)
                                .pointerInput(servers) {
                                    detectTapGestures { tapOffset ->
                                        val scale = min(size.width / MAP_W, size.height / MAP_H)
                                        val offX = (size.width - MAP_W * scale) / 2f
                                        val offY = (size.height - MAP_H * scale) / 2f
                                        var closest: MapServer? = null
                                        var bestDist = Float.MAX_VALUE
                                        servers.forEach { s ->
                                            val p = project(s.lat, s.lon)
                                            val sx = p.x * scale + offX
                                            val sy = p.y * scale + offY
                                            val dx = sx - tapOffset.x
                                            val dy = sy - tapOffset.y
                                            val dist = dx * dx + dy * dy
                                            if (dist < bestDist) { bestDist = dist; closest = s }
                                        }
                                        if (bestDist < 900f) selected = closest
                                    }
                                },
                        ) {
                            Canvas(Modifier.fillMaxSize()) {
                                val scale = min(size.width / MAP_W, size.height / MAP_H)
                                val offX = (size.width - MAP_W * scale) / 2f
                                val offY = (size.height - MAP_H * scale) / 2f
                                drawRect(color = Color(0xFF0E1A2B))
                                if (path != null) {
                                    withTransform({
                                        translate(offX, offY)
                                        scale(scale, scale, pivot = Offset.Zero)
                                    }) {
                                        drawPath(path, color = Color(0xFF23405C))
                                        drawPath(path, color = Color(0xFF3A5A7A), style = Stroke(width = 0.6f))
                                    }
                                }
                                servers.forEach { s ->
                                    val p = project(s.lat, s.lon)
                                    val cx = p.x * scale + offX
                                    val cy = p.y * scale + offY
                                    drawCircle(color = statusColor(s.status), radius = 5f, center = Offset(cx, cy))
                                }
                            }
                        }
                    }
                }
                items(servers) { s ->
                    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    listOfNotNull(s.country.ifBlank { null }, s.city.ifBlank { null }).joinToString(" · ").ifBlank { "نامشخص" },
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                if (s.remark.isNotBlank()) {
                                    Text(s.remark, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1)
                                }
                            }
                            StatusChip(s.status)
                        }
                    }
                }
            }
        }
    }

    selected?.let { s ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(listOfNotNull(s.country.ifBlank { null }, s.city.ifBlank { null }).joinToString(" · ").ifBlank { "سرور" }) },
            text = {
                Column {
                    Text("وضعیت: ${statusLabel(s.status)}")
                    if (s.ip.isNotBlank()) Text("IP: ${s.ip}")
                    if (s.remark.isNotBlank()) Text("نام کانفیگ: ${s.remark}")
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("باشه") } },
        )
    }
}
