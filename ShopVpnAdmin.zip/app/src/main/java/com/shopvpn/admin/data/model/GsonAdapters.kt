package com.shopvpn.admin.data.model

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.lang.reflect.Type

/**
 * چرا این فایل لازم است:
 * Gson با data class‌های Kotlin مقدار پیش‌فرض پارامترهای سازنده (مثل
 * `val filters: List<FilterConfig> = emptyList()`) را رعایت نمی‌کند؛ چون
 * Gson آبجکت را با ری‌فلکشن می‌سازد نه با صدا زدن سازنده‌ی Kotlin. پس اگر
 * سرور کلید "filters"/"fields"/"actions"/"options"/"tabs" را در JSON نفرستد
 * (یا مقدارش null باشد)، Gson آن فیلد را به‌جای لیست خالی، null می‌گذارد —
 * حتی وقتی نوع فیلد در Kotlin غیر-nullable تعریف شده. نتیجه‌اش کرش‌هایی مثل
 * NullPointerException روی `tab.filters.isNotEmpty()` است.
 *
 * این دیسیریالایزرهای سفارشی، هر کلید لیستیِ غایب/null را با لیست خالی
 * جایگزین می‌کنند تا این کلاس‌ها همیشه با تضمین Kotlin (`non-null`) واقعاً
 * non-null باشند.
 */

private fun JsonElement?.stringOrNull(): String? =
    if (this == null || isJsonNull) null else asString

private fun <T> JsonElement?.listOrEmpty(context: JsonDeserializationContext, elementType: Class<T>): List<T> {
    if (this == null || isJsonNull || !isJsonArray) return emptyList()
    return asJsonArray.map { context.deserialize<T>(it, elementType) }
}

private class FilterConfigDeserializer : JsonDeserializer<FilterConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): FilterConfig {
        val obj = json.asJsonObject
        return FilterConfig(
            key = obj.get("key").stringOrNull() ?: "",
            label = obj.get("label").stringOrNull() ?: "",
            options = obj.get("options").listOrEmpty(context, String::class.java),
        )
    }
}

private class TabConfigDeserializer : JsonDeserializer<TabConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): TabConfig {
        val obj = json.asJsonObject
        return TabConfig(
            id = obj.get("id").stringOrNull() ?: "",
            title = obj.get("title").stringOrNull() ?: "",
            icon = obj.get("icon").stringOrNull() ?: "circle",
            screen = obj.get("screen").stringOrNull() ?: "list",
            source = obj.get("source").stringOrNull(),
            url = obj.get("url").stringOrNull(),
            item_id_field = obj.get("item_id_field").stringOrNull() ?: "id",
            search = obj.get("search")?.takeIf { !it.isJsonNull }?.asBoolean ?: false,
            filters = obj.get("filters").listOrEmpty(context, FilterConfig::class.java),
            fields = obj.get("fields").listOrEmpty(context, FieldConfig::class.java),
            actions = obj.get("actions").listOrEmpty(context, ActionConfig::class.java),
            detail_source = obj.get("detail_source").stringOrNull(),
            section = obj.get("section").stringOrNull(),
        )
    }
}

private class AppConfigResponseDeserializer : JsonDeserializer<AppConfigResponse> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): AppConfigResponse {
        val obj = json.asJsonObject
        return AppConfigResponse(
            server_name = obj.get("server_name").stringOrNull() ?: "ShopVPN Admin",
            tenant = obj.get("tenant").stringOrNull() ?: "main",
            tabs = obj.get("tabs").listOrEmpty(context, TabConfig::class.java),
        )
    }
}

/**
 * تنها Gson ای که باید برای پارس کردن پاسخ /api/app/config استفاده شود.
 * از `Gson()` خام یا `GsonBuilder()` بدون این آداپترها برای این مدل‌ها
 * استفاده نکنید — همان باگ null دوباره برمی‌گردد.
 */
fun appConfigGson(): Gson = GsonBuilder()
    .registerTypeAdapter(AppConfigResponse::class.java, AppConfigResponseDeserializer())
    .registerTypeAdapter(TabConfig::class.java, TabConfigDeserializer())
    .registerTypeAdapter(FilterConfig::class.java, FilterConfigDeserializer())
    .create()
