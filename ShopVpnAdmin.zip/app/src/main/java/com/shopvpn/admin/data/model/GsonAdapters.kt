package com.shopvpn.admin.data.model

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.lang.reflect.Type

/**
 * چرا این فایل لازم است:
 * Gson با data class‌های Kotlin مقدار پیش‌فرض پارامترهای سازنده (مثل
 * `val filters: List<FilterConfig> = emptyList()`) را رعایت نمی‌کند؛ چون
 * Gson آبجکت را با ری‌فلکشن می‌سازد نه با صدا زدن سازنده‌ی Kotlin. پس اگر
 * سرور کلید "filters"/"fields"/"actions"/"options"/"tabs" را در JSON نفرستد
 * (یا مقدارش null باشد)، Gson آن فیلد را به‌جای لیست خالی، null می‌گذارد —
 * حتی وقتی نوع فیلد در Kotlin غیر-nullable تعریف شده. نتیجه‌اش کرش‌هایی مثل
 * NullPointerException روی `tab.filters.isNotEmpty()` است.
 *
 * این دیسیریالایزرهای سفارشی، هر کلید لیستیِ غایب/null را با لیست خالی
 * جایگزین می‌کنند تا این کلاس‌ها همیشه با تضمین Kotlin (`non-null`) واقعاً
 * non-null باشند.
 */

private fun JsonElement?.stringOrNull(): String? =
    if (this == null || isJsonNull) null else asString

private fun <T> JsonElement?.listOrEmpty(context: JsonDeserializationContext, elementType: Class<T>): List<T> {
    if (this == null || isJsonNull || !isJsonArray) return emptyList()
    return asJsonArray.map { context.deserialize<T>(it, elementType) }
}

private class FilterConfigDeserializer : JsonDeserializer<FilterConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): FilterConfig {
        val obj = json.asJsonObject
        return FilterConfig(
            key = obj.get("key").stringOrNull() ?: "",
            label = obj.get("label").stringOrNull() ?: "",
            options = obj.get("options").listOrEmpty(context, String::class.java),
        )
    }
}

private class FormFieldConfigDeserializer : JsonDeserializer<FormFieldConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): FormFieldConfig {
        val obj = json.asJsonObject
        val optionsEl = obj.get("options")
        val options = if (optionsEl != null && !optionsEl.isJsonNull && optionsEl.isJsonArray) {
            optionsEl.asJsonArray.mapNotNull { pair ->
                if (pair.isJsonArray) pair.asJsonArray.map { it.stringOrNull() ?: "" } else null
            }
        } else emptyList()
        return FormFieldConfig(
            key = obj.get("key").stringOrNull() ?: "",
            label = obj.get("label").stringOrNull() ?: "",
            type = obj.get("type").stringOrNull() ?: "text",
            options = options,
            options_source = obj.get("options_source").stringOrNull(),
            option_value_key = obj.get("option_value_key").stringOrNull() ?: "id",
            option_label_key = obj.get("option_label_key").stringOrNull() ?: "name",
            nullable = obj.get("nullable")?.takeIf { !it.isJsonNull }?.asBoolean ?: false,
            depends_on = obj.get("depends_on").stringOrNull(),
        )
    }
}

private class CreateEditFormConfigDeserializer : JsonDeserializer<CreateEditFormConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): CreateEditFormConfig {
        val obj = json.asJsonObject
        return CreateEditFormConfig(
            title = obj.get("title").stringOrNull() ?: "",
            submit_url = obj.get("submit_url").stringOrNull() ?: "",
            method = obj.get("method").stringOrNull() ?: "POST",
            fields = obj.get("fields").listOrEmpty(context, FormFieldConfig::class.java),
        )
    }
}

private class FormGroupConfigDeserializer : JsonDeserializer<FormGroupConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): FormGroupConfig {
        val obj = json.asJsonObject
        return FormGroupConfig(
            title = obj.get("title").stringOrNull() ?: "",
            fields = obj.get("fields").listOrEmpty(context, FormFieldConfig::class.java),
        )
    }
}

private class FormSectionConfigDeserializer : JsonDeserializer<FormSectionConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): FormSectionConfig {
        val obj = json.asJsonObject
        return FormSectionConfig(
            title = obj.get("title").stringOrNull() ?: "",
            groups = obj.get("groups").listOrEmpty(context, FormGroupConfig::class.java),
        )
    }
}

private class DangerActionConfigDeserializer : JsonDeserializer<DangerActionConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): DangerActionConfig {
        val obj = json.asJsonObject
        return DangerActionConfig(
            label = obj.get("label").stringOrNull() ?: "",
            endpoint = obj.get("endpoint").stringOrNull() ?: "",
            method = obj.get("method").stringOrNull() ?: "POST",
            confirm_text = obj.get("confirm_text").stringOrNull() ?: "مطمئنی؟",
        )
    }
}

private class SettingsCardConfigDeserializer : JsonDeserializer<SettingsCardConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): SettingsCardConfig {
        val obj = json.asJsonObject
        val dangerEl = obj.get("danger_action")
        // نکته: قبلاً اینجا نتیجه‌ی context.deserialize(...) مستقیم داخل یک
        // عبارت if/else به فیلد nullable «danger_action» انتساب داده می‌شد.
        // این الگو دقیقاً با یک باگ شناخته‌شده در type inference کاتلین
        // (KT-41176 / KT-42438) برخورد می‌کند: چون نوع T تابع جنریک
        // context.deserialize<T> از خودِ عبارت if/else استنتاج می‌شود نه از
        // آرگومان Class<T>، کامپایلر گاهی بایت‌کدی تولید می‌کند که یک
        // checkcast اشتباه به java.lang.Void دارد و در ران‌تایم با
        // «DangerActionConfig cannot be cast to java.lang.Void» کرش می‌کند.
        // راه‌حل: نتیجه را اول در یک val جدا با تایپ صریح می‌ریزیم تا
        // استنتاج نوع دیگر مبهم نباشد.
        val danger: DangerActionConfig? = if (dangerEl != null && !dangerEl.isJsonNull) {
            context.deserialize<DangerActionConfig>(dangerEl, DangerActionConfig::class.java)
        } else {
            null
        }
        return SettingsCardConfig(
            title = obj.get("title").stringOrNull() ?: "",
            load_url = obj.get("load_url").stringOrNull() ?: "",
            submit_url = obj.get("submit_url").stringOrNull() ?: "",
            fields = obj.get("fields").listOrEmpty(context, FormFieldConfig::class.java),
            danger_action = danger,
        )
    }
}

private class TabConfigDeserializer : JsonDeserializer<TabConfig> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): TabConfig {
        val obj = json.asJsonObject
        // همان الگوی احتیاطی danger_action (پایین‌تر): مقدار nullable حاصل از
        // context.deserialize را اول در یک val با تایپ صریح می‌ریزیم تا با
        // باگ استنتاج نوع KT-41176/KT-42438 برخورد نکنیم.
        val createFormEl = obj.get("create_form")
        val createForm: CreateEditFormConfig? = if (createFormEl != null && !createFormEl.isJsonNull) {
            context.deserialize<CreateEditFormConfig>(createFormEl, CreateEditFormConfig::class.java)
        } else null
        val editFormEl = obj.get("edit_form")
        val editForm: CreateEditFormConfig? = if (editFormEl != null && !editFormEl.isJsonNull) {
            context.deserialize<CreateEditFormConfig>(editFormEl, CreateEditFormConfig::class.java)
        } else null
        return TabConfig(
            id = obj.get("id").stringOrNull() ?: "",
            title = obj.get("title").stringOrNull() ?: "",
            icon = obj.get("icon").stringOrNull() ?: "circle",
            screen = obj.get("screen").stringOrNull() ?: "list",
            source = obj.get("source").stringOrNull(),
            url = obj.get("url").stringOrNull(),
            item_id_field = obj.get("item_id_field").stringOrNull() ?: "id",
            search = obj.get("search")?.takeIf { !it.isJsonNull }?.asBoolean ?: false,
            filters = obj.get("filters").listOrEmpty(context, FilterConfig::class.java),
            fields = obj.get("fields").listOrEmpty(context, FieldConfig::class.java),
            actions = obj.get("actions").listOrEmpty(context, ActionConfig::class.java),
            detail_source = obj.get("detail_source").stringOrNull(),
            section = obj.get("section").stringOrNull(),
            load_url = obj.get("load_url").stringOrNull(),
            submit_url = obj.get("submit_url").stringOrNull(),
            form_sections = obj.get("form_sections").listOrEmpty(context, FormSectionConfig::class.java),
            cards = obj.get("cards").listOrEmpty(context, SettingsCardConfig::class.java),
            map_source = obj.get("map_source").stringOrNull(),
            jobs_source = obj.get("jobs_source").stringOrNull(),
            backup_status_source = obj.get("backup_status_source").stringOrNull(),
            backup_create_endpoint = obj.get("backup_create_endpoint").stringOrNull(),
            backup_restore_endpoint = obj.get("backup_restore_endpoint").stringOrNull(),
            factory_reset_endpoint = obj.get("factory_reset_endpoint").stringOrNull(),
            create_form = createForm,
            edit_form = editForm,
            receipt_source = obj.get("receipt_source").stringOrNull(),
            detail_type = obj.get("detail_type").stringOrNull(),
            services_source = obj.get("services_source").stringOrNull(),
            wallet_endpoint = obj.get("wallet_endpoint").stringOrNull(),
            message_endpoint = obj.get("message_endpoint").stringOrNull(),
            config_bank_source = obj.get("config_bank_source").stringOrNull(),
            bank_configs_source = obj.get("bank_configs_source").stringOrNull(),
        )
    }
}

private class AppConfigResponseDeserializer : JsonDeserializer<AppConfigResponse> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): AppConfigResponse {
        val obj = json.asJsonObject
        return AppConfigResponse(
            server_name = obj.get("server_name").stringOrNull() ?: "ShopVPN Admin",
            tenant = obj.get("tenant").stringOrNull() ?: "main",
            tabs = obj.get("tabs").listOrEmpty(context, TabConfig::class.java),
            firebase_api_key = obj.get("firebase_api_key").stringOrNull(),
            firebase_app_id = obj.get("firebase_app_id").stringOrNull(),
            firebase_project_id = obj.get("firebase_project_id").stringOrNull(),
            firebase_sender_id = obj.get("firebase_sender_id").stringOrNull(),
        )
    }
}

/**
 * تنها Gson ای که باید برای پارس کردن پاسخ /api/app/config استفاده شود.
 * از `Gson()` خام یا `GsonBuilder()` بدون این آداپترها برای این مدل‌ها
 * استفاده نکنید — همان باگ null دوباره برمی‌گردد.
 */
fun appConfigGson(): Gson = GsonBuilder()
    .registerTypeAdapter(AppConfigResponse::class.java, AppConfigResponseDeserializer())
    .registerTypeAdapter(TabConfig::class.java, TabConfigDeserializer())
    .registerTypeAdapter(FilterConfig::class.java, FilterConfigDeserializer())
    .registerTypeAdapter(FormSectionConfig::class.java, FormSectionConfigDeserializer())
    .registerTypeAdapter(FormGroupConfig::class.java, FormGroupConfigDeserializer())
    .registerTypeAdapter(FormFieldConfig::class.java, FormFieldConfigDeserializer())
    .registerTypeAdapter(CreateEditFormConfig::class.java, CreateEditFormConfigDeserializer())
    .registerTypeAdapter(SettingsCardConfig::class.java, SettingsCardConfigDeserializer())
    .registerTypeAdapter(DangerActionConfig::class.java, DangerActionConfigDeserializer())
    .create()
