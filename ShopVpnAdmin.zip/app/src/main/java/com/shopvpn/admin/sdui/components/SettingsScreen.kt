package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.shopvpn.admin.BuildConfig
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.SectionLabel
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(session: SessionManager, api: ApiClient, onLoggedOut: () -> Unit) {
    var tokens by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var newTokenName by remember { mutableStateOf("گوشی من") }
    var justCreatedToken by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var biometricEnabled by remember { mutableStateOf(session.biometricLockEnabled) }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    suspend fun loadTokens() {
        loading = true
        try {
            val res = api.get("/api/app/tokens")
            tokens = if (res.isJsonArray) (res as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null } else emptyList()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { loadTokens() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionLabel("امنیت")
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column {
                        Text("قفل بیومتریک هنگام باز کردن اپ", style = MaterialTheme.typography.titleSmall)
                        Text(if (biometricEnabled) "فعال" else "غیرفعال", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = biometricEnabled,
                        onCheckedChange = {
                            biometricEnabled = it
                            session.biometricLockEnabled = it
                        },
                    )
                }
            }
        }

        item {
            SectionLabel("نوتیفیکیشن پوش")
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (BuildConfig.HAS_FIREBASE) "پوش لحظه‌ای (Firebase) فعال است."
                    else "این نسخه بدون Firebase بیلد شده؛ فقط هنگام باز بودن اپ به‌روزرسانی می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(14.dp),
                )
            }
        }

        item { SectionLabel("توکن‌های دسترسی اپ موبایل") }

        item {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newTokenName,
                    onValueChange = { newTokenName = it },
                    label = { Text("نام دستگاه") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    shape = MaterialTheme.shapes.small,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                    onClick = {
                        scope.launch {
                            try {
                                val res = api.post("/api/app/tokens", """{"name":"${newTokenName.replace("\"", "")}"}""")
                                justCreatedToken = res.asJsonObject.get("token").asString
                                loadTokens()
                            } catch (e: Exception) {
                                error = e.message
                            }
                        }
                    },
                ) { Text("ساخت توکن") }
            }
        }

        justCreatedToken?.let { token ->
            item {
                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("این توکن فقط همین یک‌بار نمایش داده می‌شود — جایی کپی‌اش کن:",
                            style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(token, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { clipboard.setText(AnnotatedString(token)) }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "کپی")
                            }
                        }
                    }
                }
            }
        }

        if (loading) {
            item { CircularProgressIndicator() }
        }

        items(tokens) { t ->
            val revoked = !t["revoked_at"].isJsonNull
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column {
                        Text(t["name"].asString, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            t["token_prefix"].asString + if (revoked) " (باطل‌شده)" else "",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (!revoked) {
                        IconButton(onClick = {
                            scope.launch {
                                try {
                                    api.delete("/api/app/tokens/${t["id"].asLong}")
                                    loadTokens()
                                } catch (e: Exception) {
                                    error = e.message
                                }
                            }
                        }) { Icon(Icons.Filled.Delete, contentDescription = "باطل کردن") }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { session.clear(); onLoggedOut() },
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
            ) { Text("قطع اتصال از این دستگاه") }
        }

        error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
    }
}
