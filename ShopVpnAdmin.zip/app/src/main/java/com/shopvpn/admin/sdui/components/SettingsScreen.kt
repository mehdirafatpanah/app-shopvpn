package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import com.google.firebase.FirebaseApp
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.NeonIconTile
import com.shopvpn.admin.ui.components.SectionLabel
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.TextMuted
import com.shopvpn.admin.ui.theme.ThemeController
import kotlinx.coroutines.launch

// شناسه‌ی دسته‌هایی که سرور واقعاً برایشون Push می‌فرسته (نگاه کن به
// _notify_admins/_notifier_loop در admin_panel/server.py: فقط سفارش، شارژ
// کیف‌پول، تیکت، چت زنده و قطعی/بازیابی پنل پوش دارن). قبلاً همه‌ی ۲۷ تبِ
// پنل (داشبورد، کاربران، تنظیمات و ...) این‌جا سوییچ داشتن، در حالی که
// هیچ‌وقت پوشی براشون فرستاده نمی‌شه - یعنی اکثر سوییچ‌ها ظاهراً کار می‌کردن
// ولی هیچ اعلانی برای خاموش/روشن‌کردن وجود نداشت. حالا فقط همون دسته‌هایی که
// واقعاً پوش دارن نشون داده می‌شن.
private val NOTIFIABLE_CATEGORY_IDS = setOf("orders", "topups", "tickets", "support", "panels")

@Composable
fun SettingsScreen(
    session: SessionManager,
    api: ApiClient,
    onLoggedOut: () -> Unit,
    allTabs: List<TabConfig> = emptyList(),
) {
    val notifiableTabs = remember(allTabs) { allTabs.filter { it.id in NOTIFIABLE_CATEGORY_IDS } }
    var tokens by remember { mutableStateOf<List<JsonObject>>(emptyList()) }
    var newTokenName by remember { mutableStateOf("گوشی من") }
    var justCreatedToken by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var biometricEnabled by remember { mutableStateOf(session.biometricLockEnabled) }
    var darkModeEnabled by remember { mutableStateOf(session.darkModeEnabled) }
    // نوتیف هر بخش رو جدا نگه می‌داریم؛ خالی‌بودنش توی SessionManager یعنی فعاله،
    // پس این مپ رو یک‌بار از روی تب‌های واقعی اپ می‌سازیم تا سوییچ‌ها درست باشن.
    var notifPrefs by remember(notifiableTabs) {
        mutableStateOf(notifiableTabs.associate { it.id to session.isNotificationCategoryEnabled(it.id) })
    }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    // فایربیس در زمان اجرا، بعد از لاگین، با تنظیمات همین سرور مقداردهی می‌شود
    // (نگاه کن به push/FcmRegistration.kt) — پس نبودِ آن یعنی این سرور هنوز
    // مقادیر پروژه‌ی فایربیسش را در تنظیمات > اپ موبایل وارد نکرده.
    val pushActive = remember { FirebaseApp.getApps(context).isNotEmpty() }
    var showPushGuide by remember { mutableStateOf(false) }
    var showNotificationSettings by remember { mutableStateOf(false) }

    if (showNotificationSettings) {
        NotificationSettingsScreen(
            allTabs = notifiableTabs,
            notifPrefs = notifPrefs,
            onBack = { showNotificationSettings = false },
            onToggle = { id, enabled ->
                session.setNotificationCategoryEnabled(id, enabled)
                notifPrefs = notifPrefs + (id to enabled)
            },
            onToggleAll = { enabled ->
                notifiableTabs.forEach { tab -> session.setNotificationCategoryEnabled(tab.id, enabled) }
                notifPrefs = notifiableTabs.associate { it.id to enabled }
            }
        )
        return
    }

    suspend fun loadTokens() {
        loading = true
        try {
            val res = api.get("/api/app/tokens")
            tokens = if (res.isJsonArray) (res as JsonArray).mapNotNull { if (it.isJsonObject) it.asJsonObject else null } else emptyList()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { loadTokens() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionLabel("امنیت")
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column {
                        Text("قفل بیومتریک هنگام باز کردن اپ", style = MaterialTheme.typography.titleSmall)
                        Text(if (biometricEnabled) "فعال" else "غیرفعال", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = biometricEnabled,
                        onCheckedChange = {
                            biometricEnabled = it
                            session.biometricLockEnabled = it
                        },
                    )
                }
            }
        }

        item {
            SectionLabel("ظاهر")
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column {
                        Text("تم تیره", style = MaterialTheme.typography.titleSmall)
                        Text(if (darkModeEnabled) "فعال" else "غیرفعال (روشن)", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = darkModeEnabled,
                        onCheckedChange = {
                            darkModeEnabled = it
                            session.darkModeEnabled = it
                            ThemeController.isDark = it
                        },
                    )
                }
            }
        }

        if (notifiableTabs.isNotEmpty()) {
            item {
                SectionLabel("اعلان‌ها")
                ElevatedAppCard(
                    modifier = Modifier.fillMaxWidth().clickable { showNotificationSettings = true },
                    shape = RoundedCornerShape(20.dp)
                ) {
                    val enabledCount = notifPrefs.values.count { it }
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        NeonIconTile(Icons.Filled.Notifications, BrandPrimary, size = 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("تنظیمات اعلان‌ها", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "$enabledCount از ${notifiableTabs.size} اعلان فعال",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }
                        Icon(Icons.Filled.ChevronLeft, contentDescription = null, tint = TextMuted)
                    }
                }
            }
        }

        item {
            SectionLabel("نوتیفیکیشن پوش")
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        if (pushActive) "پوش لحظه‌ای (Firebase) برای این سرور فعال است."
                        else "این سرور هنوز پروژه‌ی فایربیسش را تنظیم نکرده؛ تا آن زمان فقط هنگام باز بودن اپ به‌روزرسانی می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (!pushActive) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = { showPushGuide = true }) {
                            Text("راهنمای فعال‌سازی پوش")
                        }
                    }
                }
            }
        }

        item { SectionLabel("توکن‌های دسترسی اپ موبایل") }

        item {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newTokenName,
                    onValueChange = { newTokenName = it },
                    label = { Text("نام دستگاه") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    shape = MaterialTheme.shapes.small,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                    onClick = {
                        scope.launch {
                            try {
                                val res = api.post("/api/app/tokens", """{"name":"${newTokenName.replace("\"", "")}"}""")
                                justCreatedToken = res.asJsonObject.get("token").asString
                                loadTokens()
                            } catch (e: Exception) {
                                error = e.message
                            }
                        }
                    },
                ) { Text("ساخت توکن") }
            }
        }

        justCreatedToken?.let { token ->
            item {
                ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("این توکن فقط همین یک‌بار نمایش داده می‌شود — جایی کپی‌اش کن:",
                            style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(token, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { clipboard.setText(AnnotatedString(token)) }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "کپی")
                            }
                        }
                    }
                }
            }
        }

        if (loading) {
            item { CircularProgressIndicator() }
        }

        items(tokens) { t ->
            val revoked = !t["revoked_at"].isJsonNull
            ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column {
                        Text(t["name"].asString, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            t["token_prefix"].asString + if (revoked) " (باطل‌شده)" else "",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (!revoked) {
                        IconButton(onClick = {
                            scope.launch {
                                try {
                                    api.delete("/api/app/tokens/${t["id"].asLong}")
                                    loadTokens()
                                } catch (e: Exception) {
                                    error = e.message
                                }
                            }
                        }) { Icon(Icons.Filled.Delete, contentDescription = "باطل کردن") }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { session.clear(); onLoggedOut() },
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
            ) { Text("قطع اتصال از این دستگاه") }
        }

        error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
    }

    if (showPushGuide) {
        PushSetupGuideDialog(onDismiss = { showPushGuide = false })
    }
}

/**
 * راهنمای کامل داخل خودِ اپ برای فعال‌سازی پوش نوتیف این سرور — چون هر
 * خودمیزبان پروژه‌ی فایربیس جدای خودش را می‌سازد (نگاه کن به
 * push/FcmRegistration.kt)، این مراحل باید یک‌بار توسط ادمین هر نصب انجام شود.
 */
@Composable
private fun PushSetupGuideDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فعال‌سازی پوش نوتیف") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                GuideStep(1, "ساخت پروژه‌ی فایربیس") {
                    Text(
                        "به console.firebase.google.com برو و با اکانت گوگل خودت " +
                            "یک پروژه‌ی جدید بساز (رایگان، بدون کارت بانکی).",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    TextButton(
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://console.firebase.google.com"))
                                )
                            } catch (_: Exception) { }
                        },
                        contentPadding = PaddingValues(0.dp),
                    ) { Text("باز کردن Firebase Console") }
                }
                GuideStep(2, "افزودن اپ اندروید به پروژه") {
                    Text(
                        "داخل پروژه، روی «Add app» بزن، اندروید را انتخاب کن و در " +
                            "قسمت Package name دقیقاً همین را وارد کن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    SelectableCodeLine("com.shopvpn.admin")
                }
                GuideStep(3, "دانلود google-services.json") {
                    Text(
                        "فایربیس یک فایل google-services.json برایت می‌سازد. آن را با " +
                            "یک ویرایشگر متن (یا حتی داخل مرورگر) باز کن؛ این ۴ مقدار را " +
                            "از داخلش پیدا کن:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    SelectableCodeLine("\"api_key\" → \"current_key\"")
                    SelectableCodeLine("\"mobilesdk_app_id\"")
                    SelectableCodeLine("\"project_id\"")
                    SelectableCodeLine("\"project_number\" (این می‌شود Sender ID)")
                }
                GuideStep(4, "وارد کردن مقادیر در پنل وب") {
                    Text(
                        "در مرورگر، وارد پنل وب همین سرور شو و برو به: تنظیمات ← اپ " +
                            "موبایل ← بخش «پوش نوتیف اندروید (Firebase)». هر ۴ مقدار را " +
                            "آنجا وارد کن و «ذخیره تغییرات» را بزن.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                GuideStep(5, "بستن و باز کردن دوباره‌ی اپ") {
                    Text(
                        "همین اپ را کامل ببند (نه فقط حداقل کردن) و دوباره باز کن و " +
                            "وارد شو. از همین لحظه پوش نوتیف برای این سرور فعال است.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("متوجه شدم") }
        },
    )
}

@Composable
private fun GuideStep(number: Int, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(bottom = 14.dp)) {
        Text("$number) $title", style = MaterialTheme.typography.titleSmall, color = BrandPrimary)
        Spacer(Modifier.height(4.dp))
        content()
    }
}

@Composable
private fun SelectableCodeLine(text: String) {
    val clipboard = LocalClipboardManager.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f),
        )
        IconButton(onClick = { clipboard.setText(AnnotatedString(text)) }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.ContentCopy, contentDescription = "کپی", modifier = Modifier.size(16.dp))
        }
    }
}


@Composable
private fun NotificationSettingsScreen(
    allTabs: List<TabConfig>,
    notifPrefs: Map<String, Boolean>,
    onBack: () -> Unit,
    onToggle: (String, Boolean) -> Unit,
    onToggleAll: (Boolean) -> Unit,
) {
    val allEnabled = allTabs.isNotEmpty() && allTabs.all { notifPrefs[it.id] ?: true }
    val enabledCount = allTabs.count { notifPrefs[it.id] ?: true }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت")
            }
            Column(Modifier.weight(1f)) {
                Text("اعلان‌ها", style = MaterialTheme.typography.titleLarge)
                Text("$enabledCount از ${allTabs.size} فعال", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                ElevatedAppCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        NeonIconTile(Icons.Filled.Notifications, BrandPrimary, size = 42.dp)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("همه اعلان‌ها", style = MaterialTheme.typography.titleSmall)
                            Text("فعال یا غیرفعال کردن یک‌جا", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                        Switch(checked = allEnabled, onCheckedChange = onToggleAll)
                    }
                }
            }

            item { SectionLabel("اعلان‌های بخش‌ها") }

            items(allTabs) { tab ->
                val enabled = notifPrefs[tab.id] ?: true
                ElevatedAppCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        NeonIconTile(iconFor(tab.icon), BrandPrimary, size = 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(tab.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = enabled,
                            onCheckedChange = { onToggle(tab.id, it) },
                            modifier = Modifier.scale(0.88f)
                        )
                    }
                }
            }
        }
    }
}
