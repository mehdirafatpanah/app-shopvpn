package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.FormFieldConfig
import com.shopvpn.admin.data.model.SettingsCardConfig
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.EmptyState
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.TextMuted
import kotlinx.coroutines.launch

/** تبدیل مقدار JSON اولیه به نمایش رشته‌ای مناسب هر نوع فیلد، برای نگه‌داشتن
 * در state محلی فرم (خودِ Compose فقط با رشته/بولین راحت کار می‌کند). */
private fun displayValue(el: JsonElement?, type: String): String {
    if (el == null || el.isJsonNull) return ""
    return when (type) {
        "bool" -> when {
            el.isJsonPrimitive && el.asJsonPrimitive.isBoolean -> if (el.asBoolean) "1" else "0"
            el.isJsonPrimitive -> el.asString
            else -> "0"
        }
        "number_list" -> if (el.isJsonArray) el.asJsonArray.joinToString(", ") { it.asString } else ""
        "select_int_nullable" -> if (el.isJsonPrimitive) el.asString else ""
        else -> if (el.isJsonPrimitive) el.asString else el.toString()
    }
}

/** برعکسِ displayValue: از رشته‌ی نمایش‌داده‌شده، مقدار تایپ‌شده‌ی درست برای
 * بدنه‌ی JSON درخواست POST می‌سازد؛ چون سرور برای این تب (بر خلاف تب برندینگ)
 * انتظار انواع واقعی (بولین/عدد/آرایه) دارد، نه فقط رشته. */
private fun putTyped(body: JsonObject, field: FormFieldConfig, raw: String) {
    when (field.type) {
        "bool" -> body.addProperty(field.key, raw == "1" || raw == "true")
        "number" -> {
            val d = raw.toDoubleOrNull() ?: 0.0
            if (d == d.toLong().toDouble()) body.addProperty(field.key, d.toLong()) else body.addProperty(field.key, d)
        }
        "number_list" -> {
            val arr = JsonArray()
            raw.split(",").mapNotNull { it.trim().toDoubleOrNull() }.forEach { n ->
                if (n == n.toLong().toDouble()) arr.add(n.toLong()) else arr.add(n)
            }
            body.add(field.key, arr)
        }
        "select_int_nullable" -> {
            val n = raw.toIntOrNull()
            if (n == null) body.add(field.key, JsonNull.INSTANCE) else body.addProperty(field.key, n)
        }
        "info" -> { /* فقط نمایشی؛ در بدنه‌ی ذخیره شرکت نمی‌کند */ }
        else -> body.addProperty(field.key, raw)
    }
}

/**
 * تب «تنظیمات فروش»: چند کارت مستقل که هرکدام به یک اندپوینت REST جدا وصل
 * است (رفرال/گردونه/یادآوری تمدید/یادآوری حجمی/کانفیگ تست/عضویت اجباری/
 * هشدار موجودی). هر کارت دکمه‌ی ذخیره‌ی خودش را دارد چون هرکدام به یک
 * endpoint متفاوت پست می‌شود.
 */
@Composable
fun SettingsGroupScreen(tab: TabConfig, api: ApiClient) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (tab.cards.isEmpty()) {
                EmptyState(title = "کارتی برای نمایش تعریف نشده")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(tab.cards) { card ->
                        SettingsCardBlock(card, api, snackbarHostState, scope)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCardBlock(
    card: SettingsCardConfig,
    api: ApiClient,
    snackbarHostState: SnackbarHostState,
    scope: kotlinx.coroutines.CoroutineScope,
) {
    var values by remember(card.load_url) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember(card.load_url) { mutableStateOf(true) }
    var error by remember(card.load_url) { mutableStateOf<String?>(null) }
    var saving by remember(card.load_url) { mutableStateOf(false) }
    var confirmDanger by remember(card.load_url) { mutableStateOf(false) }

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(card.load_url)
            if (res.isJsonObject) {
                val obj = res.asJsonObject
                values = card.fields.associate { it.key to displayValue(obj[it.key], it.type) }
            }
        } catch (e: Exception) {
            error = e.message ?: "خطا در بارگذاری"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(card.load_url) { load() }

    suspend fun save() {
        saving = true
        try {
            val body = JsonObject()
            card.fields.forEach { f -> putTyped(body, f, values[f.key] ?: "") }
            api.post(card.submit_url, body.toString())
            snackbarHostState.showSnackbar("«${card.title}» ذخیره شد")
        } catch (e: Exception) {
            snackbarHostState.showSnackbar(e.message ?: "خطا در ذخیره")
        } finally {
            saving = false
        }
    }

    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(card.title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))
            when {
                loading -> Box(Modifier.fillMaxWidth().padding(20.dp), Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                }
                error != null -> Column {
                    Text(error!!, textAlign = TextAlign.Center, color = StatusDanger, modifier = Modifier.padding(vertical = 8.dp))
                    TextButton(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
                }
                else -> {
                    card.fields.forEachIndexed { index, field ->
                        if (field.type == "info") {
                            Text(
                                "${field.label}: ${values[field.key].orEmpty()}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                            )
                        } else {
                            FormFieldInput(field, values[field.key] ?: "") { new ->
                                values = values + (field.key to new)
                            }
                        }
                        if (index != card.fields.lastIndex) Spacer(Modifier.height(12.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { scope.launch { save() } }, enabled = !saving) {
                            if (saving) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            else Text("ذخیره")
                        }
                        card.danger_action?.let { danger ->
                            OutlinedButton(
                                onClick = { confirmDanger = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                            ) { Text(danger.label) }
                        }
                    }
                }
            }
        }
    }

    if (confirmDanger && card.danger_action != null) {
        val danger = card.danger_action
        AlertDialog(
            onDismissRequest = { confirmDanger = false },
            title = { Text("مطمئنی؟") },
            text = { Text(danger.confirm_text) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDanger = false
                    scope.launch {
                        try {
                            api.post(danger.endpoint)
                            snackbarHostState.showSnackbar("انجام شد")
                        } catch (e: Exception) {
                            snackbarHostState.showSnackbar(e.message ?: "خطا")
                        }
                    }
                }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { confirmDanger = false }) { Text("انصراف") } },
        )
    }
}
