package com.shopvpn.admin.sdui.components

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.shopvpn.admin.data.SessionManager

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(path: String, session: SessionManager) {
    val base = session.baseUrl?.trimEnd('/') ?: return
    val token = session.token.orEmpty()
    val url = base + (if (path.startsWith("/")) path else "/$path")

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: android.webkit.WebResourceRequest,
                    ) = null // اجازه‌ی همه‌ی درخواست‌ها؛ احراز هویت از طریق کوکی سشن مرورگر داخلی انجام می‌شود
                }
                // چون این صفحه (نقشه) از همان لاگین کوکی‌محور پنل وب استفاده می‌کند نه PAT،
                // اگر قبلاً در این WebView لاگین نشده، به صفحه‌ی لاگین وب هدایت می‌شود.
                CookieManager.getInstance().setAcceptCookie(true)
                loadUrl(url)
            }
        },
        update = { it.loadUrl(url) },
    )
}
