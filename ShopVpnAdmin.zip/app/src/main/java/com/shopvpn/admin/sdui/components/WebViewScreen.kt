package com.shopvpn.admin.sdui.components

import android.annotation.SuppressLint
import android.graphics.Color
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.viewinterop.AndroidView
import com.shopvpn.admin.data.SessionManager

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(path: String, session: SessionManager) {
    val base = session.baseUrl?.trimEnd('/') ?: run {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val token = session.token.orEmpty()
    val target = if (path.startsWith("http", ignoreCase = true)) path else base + (if (path.startsWith("/")) path else "/$path")
    val bridge = if (path.startsWith("http", ignoreCase = true)) target
                 else base + "/app/webview-bridge?token=${android.net.Uri.encode(token)}&next=${android.net.Uri.encode(path)}"

    fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    fun errorHtml(message: String) = """
        <html><head><meta name='viewport' content='width=device-width,initial-scale=1'/></head>
        <body style='background:#111318;color:#f2f2f5;font-family:sans-serif;padding:28px;text-align:center'>
        <h3>بارگذاری این بخش ناموفق بود</h3><p>${escape(message)}</p>
        <p style='opacity:.6;font-size:12px'>${escape(target)}</p>
        </body></html>
    """.trimIndent()

    // بدون این، وقتی کاربر داخل چت زنده (وب‌ویو) روی یه گفتگو باز شده و دکمه‌ی
    // بک سیستمی رو می‌زنه، به‌جای برگشت به لیست گفتگوها (تاریخچه‌ی داخلی
    // وب‌ویو)، مستقیم از کل اپ خارج می‌شد. اول تاریخچه‌ی خودِ وب‌ویو رو خالی
    // می‌کنیم؛ فقط وقتی چیزی برای برگشتن داخل وب‌ویو نمونده، اجازه می‌دیم بک
    // به بالا (ناوبری اصلی اپ) برسه.
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    BackHandler(enabled = canGoBack) { webViewRef?.goBack() }

    key(target) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webViewRef = this
                    setBackgroundColor(Color.WHITE)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    settings.loadsImagesAutomatically = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            CookieManager.getInstance().flush()
                            view.setBackgroundColor(Color.WHITE)
                            canGoBack = view.canGoBack()
                        }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            if (request.isForMainFrame) view.loadDataWithBaseURL(base, errorHtml("خطای شبکه: ${error.description}"), "text/html", "UTF-8", null)
                        }
                        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                            if (request.isForMainFrame && response.statusCode >= 400) {
                                view.loadDataWithBaseURL(base, errorHtml("خطای HTTP ${response.statusCode}"), "text/html", "UTF-8", null)
                            }
                        }
                    }
                    loadUrl(bridge)
                }
            },
        )
    }
}
