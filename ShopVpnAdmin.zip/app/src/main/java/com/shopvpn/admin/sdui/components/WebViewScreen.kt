package com.shopvpn.admin.sdui.components

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.shopvpn.admin.data.SessionManager

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(path: String, session: SessionManager) {
    val base = session.baseUrl?.trimEnd('/') ?: return
    val url = base + (if (path.startsWith("/")) path else "/$path")

    // نکته‌ی مهم: در Jetpack Compose، بلافاصله بعد از اجرای factory، خودِ Compose
    // یک‌بار update را هم صدا می‌زند (حتی در همون اولین ترکیب/composition). قبلاً
    // چون هم factory و هم update به‌طور مستقل loadUrl(url) را صدا می‌زدند، همون
    // لحظه‌ی اول این متد دوبار پشت‌سرهم اجرا می‌شد و درخواست اول (که شامل
    // ریدایرکت بریج احراز هویت + ست‌شدن کوکی سشن است) وسط راه لغو می‌شد؛
    // نتیجه‌اش صفحه‌ی خالی/سفید بود چون کوکی سشن هیچ‌وقت کامل ست نمی‌شد.
    // اینجا با نگه‌داشتن آخرین url لود‌شده، فقط وقتی url واقعاً عوض شده
    // (اولین بار، یا سوییچ به یک تب webview دیگر) دوباره لود می‌کنیم.
    var loadedUrl by remember { mutableStateOf<String?>(null) }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: android.webkit.WebResourceRequest,
                    ) = null // اجازه‌ی همه‌ی درخواست‌ها؛ احراز هویت از طریق کوکی سشن مرورگر داخلی انجام می‌شود
                }
                // چون این صفحات از همان لاگین کوکی‌محور پنل وب استفاده می‌کنند نه PAT،
                // اگر قبلاً در این WebView لاگین نشده، به صفحه‌ی لاگین وب هدایت می‌شود.
                CookieManager.getInstance().setAcceptCookie(true)
                // عمداً اینجا loadUrl صدا زده نمی‌شود؛ update (که بلافاصله بعد از
                // factory هم اجرا می‌شود) تنها مسئول لود کردن است تا لود تکراری
                // پیش نیاید.
            }
        },
        update = { webView ->
            if (loadedUrl != url) {
                loadedUrl = url
                webView.loadUrl(url)
            }
        },
    )
}
