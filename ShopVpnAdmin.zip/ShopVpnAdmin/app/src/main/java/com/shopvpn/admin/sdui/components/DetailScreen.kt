package com.shopvpn.admin.sdui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.shopvpn.admin.data.model.ActionConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import kotlinx.coroutines.launch

// فیلدهای فنی/داخلی که هیچ‌وقت نباید توی صفحه‌ی جزئیات نشون داده بشن (شناسه‌های
// خام، فیلدهای کمکی که فقط برای منطق داخلی اپ استفاده می‌شن، و غیره) — قبلاً همه‌ی
// این‌ها هم مثل بقیه‌ی فیلدها ردیف می‌شدن و ظاهر صفحه رو شلوغ می‌کردن.
private val HIDDEN_DETAIL_KEYS = setOf(
    "id", "receipt_file_id", "has_receipt", "raw", "ip", "ip_address",
    "user_agent", "token", "hash", "internal_note",
)
private val ID_LIKE_SUFFIXES = listOf("_id")
// برچسب فارسی برای پرکاربردترین کلیدها؛ هر کلید ناشناخته هم به‌جای snake_case
// خام، با فاصله و حرف اول بزرگ نشون داده می‌شه.
private val DETAIL_LABELS = mapOf(
    "status" to "وضعیت", "amount" to "مبلغ", "created_at" to "تاریخ ثبت",
    "updated_at" to "آخرین به‌روزرسانی", "method" to "روش پرداخت", "note" to "توضیحات",
    "description" to "توضیحات", "type" to "نوع", "product" to "محصول",
    "product_name" to "محصول", "username" to "نام کاربری", "title" to "عنوان",
    "reason" to "دلیل", "card_number" to "شماره کارت",
    "quantity" to "تعداد", "full_name" to "نام و نام خانوادگی",
)
private val PRIORITY_ORDER = listOf(
    "status", "product", "product_name", "quantity", "amount", "method",
    "username", "full_name", "created_at",
)

private fun prettyLabel(key: String): String =
    DETAIL_LABELS[key] ?: key.replace('_', ' ').replaceFirstChar { it.uppercase() }

private fun isNoisyKey(key: String): Boolean =
    key in HIDDEN_DETAIL_KEYS || (ID_LIKE_SUFFIXES.any { key.endsWith(it) } && key !in DETAIL_LABELS)

/**
 * صفحه‌ی جزئیات عمومی: هر چه از detail_source برگردد را نشان می‌دهد، اما پیش از
 * نمایش، فیلدهای فنی/شناسه‌ای را کنار می‌گذارد، بقیه را با برچسب خوانا (نه
 * snake_case خام) نشان می‌دهد و فیلدهای مهم‌تر (وضعیت، مبلغ، ...) را بالاتر
 * می‌آورد. اکشن‌های همان تب (مثل مسدود/رفع‌مسدودی) اینجا هم قابل اجرا هستند.
 */
@Composable
fun DetailScreen(
    title: String,
    detailSourceTemplate: String,
    idValue: String,
    actions: List<ActionConfig>,
    api: ApiClient,
    onClose: () -> Unit,
    receiptSourceTemplate: String? = null,
) {
    var data by remember { mutableStateOf<JsonObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var receiptBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var receiptLoading by remember { mutableStateOf(false) }
    var receiptError by remember { mutableStateOf<String?>(null) }
    var showReceipt by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    suspend fun loadReceipt() {
        if (receiptSourceTemplate == null) return
        receiptLoading = true
        receiptError = null
        try {
            val res = api.get(receiptSourceTemplate.replace("{id}", idValue).replace("{tg_id}", idValue))
            val obj = res.asJsonObject
            val b64 = obj["data_base64"].asString
            val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
            receiptBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            showReceipt = true
        } catch (e: Exception) {
            receiptError = e.message ?: "دریافت رسید ناموفق بود"
        } finally {
            receiptLoading = false
        }
    }

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(detailSourceTemplate.replace("{id}", idValue).replace("{tg_id}", idValue))
            data = if (res.isJsonObject) res.asJsonObject else null
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(idValue) { load() }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title) },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت")
                }
            },
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(error ?: "خطا") }
            data == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("چیزی پیدا نشد") }
            else -> {
                val rows = data!!.entrySet()
                    .filter { (it.value.isJsonPrimitive || it.value.isJsonNull) && !isNoisyKey(it.key) }
                    .map { it.key to (if (it.value.isJsonNull) "-" else (it.value as JsonPrimitive).asString) }
                    .sortedBy { (key, _) -> PRIORITY_ORDER.indexOf(key).let { if (it == -1) PRIORITY_ORDER.size else it } }
                    .map { (key, value) -> prettyLabel(key) to value }
                val hasReceipt = data!!["has_receipt"]?.let { it.isJsonPrimitive && it.asBoolean } ?: false

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(rows) { (key, value) ->
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(key, style = MaterialTheme.typography.bodySmall)
                                Text(value, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (receiptSourceTemplate != null && hasReceipt) {
                        item {
                            if (receiptError != null) {
                                Text(receiptError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            Button(
                                onClick = { scope.launch { loadReceipt() } },
                                enabled = !receiptLoading,
                                shape = MaterialTheme.shapes.small,
                            ) {
                                if (receiptLoading) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                else Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("نمایش رسید پرداخت")
                                }
                            }
                        }
                    }

                    if (actions.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                actions.forEach { action ->
                                    val isBusy = busyAction == action.id
                                    val color = when (action.style) {
                                        "success" -> StatusSuccess
                                        "danger" -> StatusDanger
                                        else -> BrandPrimary
                                    }
                                    Button(
                                        shape = MaterialTheme.shapes.small,
                                        onClick = {
                                            scope.launch {
                                                busyAction = action.id
                                                try {
                                                    val endpoint = action.endpoint
                                                        .replace("{id}", idValue).replace("{tg_id}", idValue)
                                                    if (action.method.equals("DELETE", true)) api.delete(endpoint)
                                                    else api.post(endpoint)
                                                    load()
                                                } catch (e: Exception) {
                                                    error = e.message
                                                } finally {
                                                    busyAction = null
                                                }
                                            }
                                        },
                                        enabled = !isBusy,
                                        colors = ButtonDefaults.buttonColors(containerColor = color),
                                    ) {
                                        if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                        else Text(action.label)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showReceipt && receiptBitmap != null) {
        Dialog(
            onDismissRequest = { showReceipt = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        bitmap = receiptBitmap!!.asImageBitmap(),
                        contentDescription = "رسید پرداخت",
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                    )
                    IconButton(
                        onClick = { showReceipt = false },
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    ) {
                        Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بستن")
                    }
                }
            }
        }
    }
}
