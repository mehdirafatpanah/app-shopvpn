package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.shopvpn.admin.data.model.ActionConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.StatusDanger
import com.shopvpn.admin.ui.theme.StatusSuccess
import kotlinx.coroutines.launch

/**
 * صفحه‌ی جزئیات عمومی: هیچ فیلدی از قبل نمی‌شناسد، فقط هر چه از detail_source
 * برگردد را به‌صورت ردیف‌های کلید/مقدار نشان می‌دهد. اکشن‌های همان تب (مثل
 * مسدود/رفع‌مسدودی) اینجا هم قابل اجرا هستند.
 */
@Composable
fun DetailScreen(
    title: String,
    detailSourceTemplate: String,
    idValue: String,
    actions: List<ActionConfig>,
    api: ApiClient,
    onClose: () -> Unit,
) {
    var data by remember { mutableStateOf<JsonObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busyAction by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(detailSourceTemplate.replace("{id}", idValue).replace("{tg_id}", idValue))
            data = if (res.isJsonObject) res.asJsonObject else null
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(idValue) { load() }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title) },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "بازگشت")
                }
            },
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(error ?: "خطا") }
            data == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("چیزی پیدا نشد") }
            else -> {
                val rows = data!!.entrySet()
                    .filter { it.value.isJsonPrimitive || it.value.isJsonNull }
                    .map { it.key to (if (it.value.isJsonNull) "-" else (it.value as JsonPrimitive).asString) }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(rows) { (key, value) ->
                        ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(key, style = MaterialTheme.typography.bodySmall)
                                Text(value, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (actions.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                actions.forEach { action ->
                                    val isBusy = busyAction == action.id
                                    val color = when (action.style) {
                                        "success" -> StatusSuccess
                                        "danger" -> StatusDanger
                                        else -> BrandPrimary
                                    }
                                    Button(
                                        shape = MaterialTheme.shapes.small,
                                        onClick = {
                                            scope.launch {
                                                busyAction = action.id
                                                try {
                                                    val endpoint = action.endpoint
                                                        .replace("{id}", idValue).replace("{tg_id}", idValue)
                                                    if (action.method.equals("DELETE", true)) api.delete(endpoint)
                                                    else api.post(endpoint)
                                                    load()
                                                } catch (e: Exception) {
                                                    error = e.message
                                                } finally {
                                                    busyAction = null
                                                }
                                            }
                                        },
                                        enabled = !isBusy,
                                        colors = ButtonDefaults.buttonColors(containerColor = color),
                                    ) {
                                        if (isBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                        else Text(action.label)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
