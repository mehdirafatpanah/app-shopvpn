package com.shopvpn.admin.ui.theme

import androidx.compose.ui.graphics.Color

// ShopVPN Admin — Bento Glass palette
val BgBase = Color(0xFF08090F)
val BgElevated1 = Color(0xFF0E1018)
val BgElevated2 = Color(0xFF141726)
val BgElevated3 = Color(0xFF1B1F33)
val StrokeSubtle = Color(0xFF232842)
val StrokeStrong = Color(0xFF39406B)

// Glass surface tokens — translucent white washes layered on top of ambient color
// blobs to fake a frosted-glass look without relying on real-time backdrop blur
// (minSdk 26 can't guarantee RenderEffect/Modifier.blur support on-device).
val GlassFill = Color(0x14FFFFFF)
val GlassFillStrong = Color(0x22FFFFFF)
val GlassBorder = Color(0x26FFFFFF)
val GlassSheen = Color(0x40FFFFFF)

val BrandStart = Color(0xFF7C67FF)
val BrandEnd = Color(0xFF22D3EE)
val BrandPrimary = Color(0xFF8B7CFF)
val BrandPrimaryOn = Color.White

val AccentViolet = Color(0xFF8B7CFF)
val AccentCyan = Color(0xFF22D3EE)
val AccentPink = Color(0xFFFF5FA8)
val AccentAmber = Color(0xFFFFC259)
val AccentGreen = Color(0xFF34E5A8)
val AccentBlue = Color(0xFF5B9DFF)

// Per-tile ambient washes for the bento grid — each metric/section gets its own
// tinted glass instead of one repeated card color.
val TileVioletBg = Color(0x298B7CFF)
val TileCyanBg = Color(0x2922D3EE)
val TilePinkBg = Color(0x29FF5FA8)
val TileAmberBg = Color(0x29FFC259)
val TileGreenBg = Color(0x2934E5A8)
val TileBlueBg = Color(0x295B9DFF)

val StatusSuccess = Color(0xFF34E5A8)
val StatusSuccessBg = Color(0xFF0E2B22)
val StatusWarning = Color(0xFFFFC259)
val StatusWarningBg = Color(0xFF302408)
val StatusDanger = Color(0xFFFF5C7A)
val StatusDangerBg = Color(0xFF351019)
val StatusInfo = Color(0xFF5B9DFF)
val StatusInfoBg = Color(0xFF0D2038)
val StatusNeutral = Color(0xFF8E96B8)
val StatusNeutralBg = Color(0xFF171A2A)

val TextPrimary = Color(0xFFF6F7FC)
val TextSecondary = Color(0xFFAAB0CC)
val TextMuted = Color(0xFF676E90)
