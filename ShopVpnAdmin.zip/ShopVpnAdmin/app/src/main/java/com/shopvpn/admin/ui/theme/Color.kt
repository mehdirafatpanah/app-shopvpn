package com.shopvpn.admin.ui.theme

import androidx.compose.ui.graphics.Color

// --- پس‌زمینه و سطوح (Dark، لایه‌بندی‌شده به‌جای یک رنگ تخت) ---
val BgBase = Color(0xFF0A0C14)
val BgElevated1 = Color(0xFF12151F)
val BgElevated2 = Color(0xFF1A1E2C)
val BgElevated3 = Color(0xFF232839)
val StrokeSubtle = Color(0xFF2A3042)

// --- برند: بنفش-آبی مدرن + گرادیان انرژی‌بخش برای CTA و هدر داشبورد ---
val BrandStart = Color(0xFF6A5CFF)
val BrandEnd = Color(0xFF00C2FF)
val BrandPrimary = Color(0xFF7B6BFF)
val BrandPrimaryOn = Color(0xFFFFFFFF)

// --- ثانویه / لهجه ---
val AccentCyan = Color(0xFF22D3EE)
val AccentAmber = Color(0xFFFFB020)
val AccentPink = Color(0xFFFF4FA0)

// --- سمانتیک (وضعیت‌ها: سفارش، تیکت، سرور و ...) ---
val StatusSuccess = Color(0xFF2ED47A)
val StatusSuccessBg = Color(0xFF15301F)
val StatusWarning = Color(0xFFFFB020)
val StatusWarningBg = Color(0xFF332507)
val StatusDanger = Color(0xFFFF5C7C)
val StatusDangerBg = Color(0xFF351019)
val StatusInfo = Color(0xFF4EA1FF)
val StatusInfoBg = Color(0xFF0F2440)
val StatusNeutral = Color(0xFF8A93A8)
val StatusNeutralBg = Color(0xFF1E2230)

// --- متن ---
val TextPrimary = Color(0xFFF3F5FA)
val TextSecondary = Color(0xFFA0A8C0)
val TextMuted = Color(0xFF6B7288)
