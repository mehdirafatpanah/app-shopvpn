package com.shopvpn.admin.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.ui.theme.*

/** رنگ‌بندی معنایی وضعیت‌ها (سفارش/تیکت/کاربر/سرور و ...) — یک نگاشت واحد
 * برای همه‌ی صفحات تا هر «pending» یا «approved» در کل اپ یک شکل باشد. */
private data class StatusStyle(val fg: Color, val bg: Color, val label: String)

private fun styleFor(raw: String): StatusStyle = when (raw.trim().lowercase()) {
    "approved", "active", "success", "paid", "online", "unlocked", "closed_ok", "true", "1" ->
        StatusStyle(StatusSuccess, StatusSuccessBg, when (raw.lowercase()) {
            "approved" -> "تایید شده"; "active", "true", "1" -> "فعال"; "online" -> "آنلاین"
            else -> raw
        })
    "pending", "processing", "answered", "in_progress" ->
        StatusStyle(StatusWarning, StatusWarningBg, when (raw.lowercase()) {
            "pending" -> "در انتظار"; "answered" -> "پاسخ داده‌شده"; else -> raw
        })
    "rejected", "blocked", "failed", "danger", "offline", "false", "0", "expired" ->
        StatusStyle(StatusDanger, StatusDangerBg, when (raw.lowercase()) {
            "rejected" -> "رد شده"; "blocked" -> "مسدود"; "offline" -> "آفلاین"
            "false", "0" -> "غیرفعال"; "expired" -> "منقضی"; else -> raw
        })
    "open" -> StatusStyle(StatusInfo, StatusInfoBg, "باز")
    "closed" -> StatusStyle(StatusNeutral, StatusNeutralBg, "بسته")
    else -> StatusStyle(StatusNeutral, StatusNeutralBg, raw.ifBlank { "—" })
}

@Composable
fun StatusChip(value: String, modifier: Modifier = Modifier) {
    val s = styleFor(value)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(s.bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(s.label, style = MaterialTheme.typography.labelMedium, color = s.fg)
    }
}

/** دایره‌ی حرف اول برای آواتار کاربران/سفارش‌ها وقتی عکسی در کار نیست. */
@Composable
fun InitialsBadge(text: String, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 40.dp) {
    val letter = text.trim().firstOrNull()?.toString() ?: "?"
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(BrandStart, BrandEnd))),
        contentAlignment = Alignment.Center,
    ) {
        Text(letter, color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

/** کارت گرادیانی برند — برای هدر داشبورد و بنرهای شاخص. */
@Composable
fun BrandGradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(BrandStart, BrandEnd)))
            .padding(20.dp),
        content = content,
    )
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        style = MaterialTheme.typography.labelMedium,
        color = TextMuted,
    )
}

@Composable
fun EmptyState(
    title: String,
    subtitle: String? = null,
    icon: ImageVector = Icons.Filled.Inbox,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(BgElevated2),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, contentDescription = null, tint = TextMuted) }
            Spacer(Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, color = TextSecondary, textAlign = TextAlign.Center)
            if (subtitle != null) {
                Spacer(Modifier.height(4.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
            }
        }
    }
}

/** کارت پایه‌ی سطح‌بندی‌شده‌ی همه‌ی صفحات — به‌جای Card پیش‌فرض متریال که تخت است. */
@Composable
fun ElevatedAppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BgElevated1),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StrokeSubtle),
    ) { Column(content = content) }
}
