package com.shopvpn.admin.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BentoScheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2A2260),
    onPrimaryContainer = TextPrimary,
    secondary = AccentCyan,
    onSecondary = Color(0xFF00232B),
    secondaryContainer = Color(0xFF0C3742),
    onSecondaryContainer = TextPrimary,
    tertiary = AccentPink,
    background = BgBase,
    onBackground = TextPrimary,
    surface = BgElevated1,
    onSurface = TextPrimary,
    surfaceVariant = BgElevated2,
    onSurfaceVariant = TextSecondary,
    outline = StrokeSubtle,
    outlineVariant = StrokeSubtle,
    error = StatusDanger,
    onError = Color.White,
    errorContainer = StatusDangerBg,
    onErrorContainer = TextPrimary,
)

private val AppTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 38.sp, color = TextPrimary, letterSpacing = (-0.8).sp),
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, color = TextPrimary, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 19.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextPrimary, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextPrimary, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, color = TextSecondary, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, color = TextMuted),
)

// Jumbo stat number style for large bento tiles — not part of the M3 type scale,
// exposed separately so dashboard/hero tiles can opt into it.
val BentoJumboNumber = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 34.sp, color = TextPrimary, letterSpacing = (-0.6).sp)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

@Composable
fun ShopVpnAdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BentoScheme, typography = AppTypography, shapes = AppShapes, content = content)
}
