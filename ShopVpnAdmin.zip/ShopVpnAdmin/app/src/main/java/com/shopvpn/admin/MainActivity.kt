package com.shopvpn.admin

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.shopvpn.admin.data.model.AppConfigResponse
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.data.model.appConfigGson
import com.shopvpn.admin.push.registerCurrentFcmToken
import com.shopvpn.admin.sdui.RenderScreen
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.screens.OnboardingScreen
import com.shopvpn.admin.ui.theme.BrandEnd
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.BrandStart
import com.shopvpn.admin.ui.theme.ShopVpnAdminTheme
import com.shopvpn.admin.ui.theme.StatusDanger
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShopVpnAdminApp

        setContent {
            ShopVpnAdminTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RootNavigator(app)
                }
            }
        }
    }
}

@Composable
private fun RootNavigator(app: ShopVpnAdminApp) {
    var connected by remember { mutableStateOf(app.session.isConnected) }
    var unlocked by remember { mutableStateOf(!app.session.biometricLockEnabled) }
    val context = LocalContext.current

    if (!connected) {
        OnboardingScreen(app.session, app.api, onConnected = { connected = true })
        return
    }

    if (!unlocked) {
        BiometricGate(onUnlocked = { unlocked = true }, onFallback = { unlocked = true })
        return
    }

    AppShell(app, onLoggedOut = { connected = false; unlocked = !app.session.biometricLockEnabled })
}

@Composable
private fun BiometricGate(onUnlocked: () -> Unit, onFallback: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    LaunchedEffect(Unit) {
        try {
            val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
            val prompt = androidx.biometric.BiometricPrompt(
                activity, executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                        onUnlocked()
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        onFallback() // دستگاه بیومتریک ندارد یا کاربر لغو کرد -> عبور بدون قفل اضافه
                    }
                },
            )
            val info = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به ShopVPN Admin")
                .setSubtitle("برای ادامه هویتت را تایید کن")
                .setNegativeButtonText("انصراف")
                .build()
            prompt.authenticate(info)
        } catch (e: Exception) {
            onFallback()
        }
    }
    Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun AppShell(app: ShopVpnAdminApp, onLoggedOut: () -> Unit) {
    var config by remember { mutableStateOf<AppConfigResponse?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var offline by remember { mutableStateOf(false) }
    var selectedTabId by remember { mutableStateOf<String?>(null) }
    var badgeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    suspend fun loadBadges() {
        try {
            val res = app.api.get("/api/notifications/summary")
            if (res.isJsonObject) {
                badgeCounts = res.asJsonObject.entrySet()
                    .filter { it.value.isJsonPrimitive && it.value.asJsonPrimitive.isNumber }
                    .associate { it.key to it.value.asInt }
            }
        } catch (_: Exception) { /* بج‌ها تزئینی‌اند؛ خطا نباید کل صفحه را خراب کند */ }
    }

    // آفلاین-اول: اول هر چیزی که از دفعه‌ی قبل کش شده را فوری نشان بده تا اپ
    // بدون معطلی باز شود، بعد از سرور تازه بگیر و کش را به‌روزرسانی کن. اگر
    // سرور در دسترس نبود (قطعی شبکه لحظه‌ای)، به‌جای صفحه‌ی خطا، همان کش را
    // نگه دار — این دقیقاً همان چیزی است که قبلاً باعث می‌شد بعضی وقت‌ها کل اپ
    // (نه فقط یک تب) با «خطا در دریافت پیکربندی» باز نشود.
    LaunchedEffect(Unit) {
        val cached = try {
            app.cache.load(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG)
        } catch (_: Exception) { null }
        if (cached != null) {
            try {
                config = appConfigGson().fromJson(cached, AppConfigResponse::class.java)
                selectedTabId = config?.tabs?.firstOrNull()?.id
                offline = true
            } catch (_: Exception) { /* کش خراب بود، نادیده بگیر و منتظر شبکه بمان */ }
        }
        try {
            val res = app.api.get("/api/app/config")
            val parsed = appConfigGson().fromJson(res, AppConfigResponse::class.java)
            config = parsed
            offline = false
            selectedTabId = selectedTabId?.takeIf { id -> parsed.tabs.any { it.id == id } }
                ?: parsed.tabs.firstOrNull()?.id
            app.cache.save(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG, res)
            registerCurrentFcmToken(app)
            loadBadges()
        } catch (e: Exception) {
            if (config == null) {
                error = e.message ?: "خطا در دریافت پیکربندی از سرور"
            } else {
                offline = true // کانفیگ کش‌شده را نگه دار، فقط نشان بده که آفلاینیم
            }
        }
    }

    when {
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onLoggedOut) { Text("قطع اتصال و اتصال دوباره") }
            }
        }
        config == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        else -> {
            val tabs = config!!.tabs
            val active = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    AppDrawer(
                        serverName = config!!.server_name,
                        tenant = config!!.tenant,
                        tabs = tabs,
                        activeId = active.id,
                        badgeCounts = badgeCounts,
                        onSelect = {
                            selectedTabId = it
                            scope.launch { drawerState.close() }
                        },
                    )
                },
            ) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(active.title)
                                    if (offline) {
                                        Text(
                                            "آفلاین — نمایش آخرین نسخه‌ی ذخیره‌شده",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusDanger,
                                        )
                                    }
                                }
                            },
                            navigationIcon = {
                                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                    Icon(Icons.Filled.Menu, contentDescription = "منو")
                                }
                            },
                        )
                    },
                ) { padding ->
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        RenderScreen(active, app.api, app.session, app.cache, onLoggedOut)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppDrawer(
    serverName: String,
    tenant: String,
    tabs: List<TabConfig>,
    activeId: String,
    badgeCounts: Map<String, Int>,
    onSelect: (String) -> Unit,
) {
    ModalDrawerSheet {
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(BrandStart, BrandEnd))).padding(20.dp)) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center,
            ) { Text(serverName.firstOrNull()?.toString() ?: "S", color = Color.White, style = MaterialTheme.typography.titleLarge) }
            Spacer(Modifier.height(10.dp))
            Text(serverName, color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text("پنل: $tenant", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
        }

        LazyColumn(Modifier.weight(1f, fill = false)) {
            var lastSection: String? = null
            tabs.forEach { tab ->
                if (tab.section != lastSection) {
                    lastSection = tab.section
                    if (tab.section != null) {
                        item {
                            Text(
                                tab.section,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 4.dp),
                            )
                        }
                    }
                }
                item {
                    val count = badgeCounts[tab.id] ?: 0
                    NavigationDrawerItem(
                        icon = { Icon(iconFor(tab.icon), contentDescription = null) },
                        label = { Text(tab.title) },
                        badge = { if (count > 0) Badge(containerColor = StatusDanger) { Text(if (count > 99) "99+" else count.toString()) } },
                        selected = tab.id == activeId,
                        onClick = { onSelect(tab.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = BrandPrimary.copy(alpha = 0.18f)),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                    )
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
