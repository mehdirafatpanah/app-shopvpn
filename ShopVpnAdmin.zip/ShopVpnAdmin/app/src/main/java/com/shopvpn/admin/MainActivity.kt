package com.shopvpn.admin

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.fragment.app.FragmentActivity
import com.shopvpn.admin.data.model.AppConfigResponse
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.data.model.appConfigGson
import com.shopvpn.admin.push.registerCurrentFcmToken
import com.shopvpn.admin.sdui.RenderScreen
import com.shopvpn.admin.sdui.iconFor
import com.shopvpn.admin.ui.components.CyberBackground
import com.shopvpn.admin.ui.components.NeonIconTile
import com.shopvpn.admin.ui.screens.OnboardingScreen
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShopVpnAdminApp
        setContent {
            ShopVpnAdminTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = BgBase) { RootNavigator(app) }
                }
            }
        }
    }
}

@Composable
private fun RootNavigator(app: ShopVpnAdminApp) {
    var connected by remember { mutableStateOf(app.session.isConnected) }
    var unlocked by remember { mutableStateOf(!app.session.biometricLockEnabled) }
    if (!connected) {
        OnboardingScreen(app.session, app.api, onConnected = { connected = true })
        return
    }
    if (!unlocked) {
        BiometricGate(onUnlocked = { unlocked = true }, onFallback = { unlocked = true })
        return
    }
    AppShell(app) { connected = false; unlocked = !app.session.biometricLockEnabled }
}

@Composable
private fun BiometricGate(onUnlocked: () -> Unit, onFallback: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    LaunchedEffect(Unit) {
        try {
            val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
            val prompt = androidx.biometric.BiometricPrompt(activity, executor,
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) = onUnlocked()
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onFallback()
                })
            val info = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به ShopVPN Admin").setSubtitle("برای ادامه هویتت را تایید کن")
                .setNegativeButtonText("انصراف").build()
            prompt.authenticate(info)
        } catch (_: Exception) { onFallback() }
    }
    CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
}

@Composable
private fun AppShell(app: ShopVpnAdminApp, onLoggedOut: () -> Unit) {
    var config by remember { mutableStateOf<AppConfigResponse?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var offline by remember { mutableStateOf(false) }
    var selectedTabId by remember { mutableStateOf<String?>(null) }
    var badgeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    suspend fun loadBadges() {
        try {
            val res = app.api.get("/api/notifications/summary")
            if (res.isJsonObject) badgeCounts = res.asJsonObject.entrySet()
                .filter { it.value.isJsonPrimitive && it.value.asJsonPrimitive.isNumber }
                .associate { it.key to it.value.asInt }
        } catch (_: Exception) { }
    }

    LaunchedEffect(Unit) {
        val cached = try { app.cache.load(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG) } catch (_: Exception) { null }
        if (cached != null) try {
            config = appConfigGson().fromJson(cached, AppConfigResponse::class.java)
            selectedTabId = config?.tabs?.firstOrNull()?.id
            offline = true
        } catch (_: Exception) { }
        try {
            val res = app.api.get("/api/app/config")
            val parsed = appConfigGson().fromJson(res, AppConfigResponse::class.java)
            config = parsed; offline = false
            selectedTabId = selectedTabId?.takeIf { id -> parsed.tabs.any { it.id == id } } ?: parsed.tabs.firstOrNull()?.id
            app.cache.save(com.shopvpn.admin.data.local.LocalCacheRepository.KEY_APP_CONFIG, res)
            registerCurrentFcmToken(app); loadBadges()
        } catch (e: Exception) {
            if (config == null) error = e.message ?: "خطا در دریافت پیکربندی از سرور" else offline = true
        }
    }

    when {
        error != null -> CyberBackground {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                ElevatedAppCard(Modifier.fillMaxWidth(.86f)) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        NeonIconTile(Icons.Filled.CloudOff, StatusDanger)
                        Spacer(Modifier.height(14.dp)); Text("اتصال برقرار نشد", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp)); Text(error!!, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Spacer(Modifier.height(16.dp)); Button(onClick = onLoggedOut) { Text("اتصال دوباره") }
                    }
                }
            }
        }
        config == null -> CyberBackground { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) } }
        else -> {
            val tabs = config!!.tabs
            if (tabs.isEmpty()) return
            val active = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()
            val bottomTabs = tabs.take(4)
            val activeBottomIndex = bottomTabs.indexOfFirst { it.id == active.id }

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    AppDrawer(config!!.server_name, config!!.tenant, tabs, active.id, badgeCounts) {
                        selectedTabId = it; scope.launch { drawerState.close() }
                    }
                },
            ) {
                Scaffold(
                    containerColor = Color.Transparent,
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(active.title, style = MaterialTheme.typography.titleLarge)
                                    if (offline) Text("آفلاین • آخرین داده ذخیره‌شده", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                                }
                            },
                            navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Filled.Menu, "منو") } },
                            actions = {
                                if (!offline) IconButton(onClick = { scope.launch { loadBadges() } }) { Icon(Icons.Filled.NotificationsNone, "اعلان‌ها") }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xE80A0F1D), tonalElevation = 0.dp) {
                            bottomTabs.forEachIndexed { index, tab ->
                                val count = badgeCounts[tab.id] ?: 0
                                NavigationBarItem(
                                    selected = tab.id == active.id,
                                    onClick = { selectedTabId = tab.id },
                                    icon = { BadgedBox(badge = { if (count > 0) Badge { Text(if (count > 9) "9+" else count.toString()) } }) { Icon(iconFor(tab.icon), null) } },
                                    label = { Text(tab.title, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(selectedIconColor = BrandPrimary, selectedTextColor = BrandPrimary, indicatorColor = BrandPrimary.copy(.12f), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted),
                                )
                            }
                            NavigationBarItem(
                                selected = activeBottomIndex < 0,
                                onClick = { scope.launch { drawerState.open() } },
                                icon = { Icon(Icons.Filled.GridView, null) }, label = { Text("بیشتر") },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = BrandPrimary, selectedTextColor = BrandPrimary, indicatorColor = BrandPrimary.copy(.12f), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted),
                            )
                        }
                    },
                ) { padding ->
                    CyberBackground(Modifier.padding(padding)) {
                        Box(Modifier.fillMaxSize()) {
                            // Subtle neon ambience behind all screens.
                            Box(Modifier.align(Alignment.TopEnd).size(180.dp).clip(CircleShape).background(Brush.radialGradient(listOf(BrandPrimary.copy(.10f), Color.Transparent))))
                            RenderScreen(active, app.api, app.session, app.cache, onLoggedOut)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppDrawer(serverName: String, tenant: String, tabs: List<TabConfig>, activeId: String, badgeCounts: Map<String, Int>, onSelect: (String) -> Unit) {
    ModalDrawerSheet(drawerContainerColor = Color(0xFF090D19), drawerShape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp)) {
        Column(Modifier.fillMaxHeight()) {
            Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(Color(0xFF17134A), Color(0xFF073B54), Color(0xFF08101E)))).padding(22.dp)) {
                Column(verticalArrangement = Arrangement.Bottom, modifier = Modifier.fillMaxSize()) {
                    Box(Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(BrandStart, BrandEnd))), Alignment.Center) { Text(serverName.firstOrNull()?.uppercase() ?: "S", color = Color.White, style = MaterialTheme.typography.titleLarge) }
                    Spacer(Modifier.height(12.dp)); Text("ShopVPN Admin", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text("$serverName  •  پنل $tenant", color = Color.White.copy(.65f), style = MaterialTheme.typography.bodySmall)
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                var lastSection: String? = null
                tabs.forEach { tab ->
                    if (tab.section != null && tab.section != lastSection) {
                        lastSection = tab.section
                        item { Text(tab.section!!, style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) }
                    }
                    item {
                        val count = badgeCounts[tab.id] ?: 0
                        NavigationDrawerItem(
                            icon = { Icon(iconFor(tab.icon), null) }, label = { Text(tab.title) },
                            badge = { if (count > 0) Badge { Text(if (count > 99) "99+" else count.toString()) } },
                            selected = tab.id == activeId, onClick = { onSelect(tab.id) },
                            shape = RoundedCornerShape(14.dp),
                            colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = BrandPrimary.copy(.14f), selectedIconColor = BrandPrimary, selectedTextColor = TextPrimary, unselectedIconColor = TextSecondary, unselectedTextColor = TextSecondary),
                        )
                    }
                }
            }
            HorizontalDivider(color = StrokeSubtle)
            Text("مدیریت • نسخه 1.0.0", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(18.dp))
        }
    }
}
