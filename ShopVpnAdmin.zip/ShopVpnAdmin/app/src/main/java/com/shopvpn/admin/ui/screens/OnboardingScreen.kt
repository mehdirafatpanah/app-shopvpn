package com.shopvpn.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.shopvpn.admin.data.SessionManager
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.theme.BrandEnd
import com.shopvpn.admin.ui.theme.BrandPrimary
import com.shopvpn.admin.ui.theme.BrandStart
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(session: SessionManager, api: ApiClient, onConnected: () -> Unit) {
    var serverUrl by remember { mutableStateOf("https://") }
    var token by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(Brush.linearGradient(listOf(BrandStart, BrandEnd))),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp)) }
            Spacer(Modifier.height(16.dp))
            Text("اتصال به پنل ShopVPN", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(4.dp))
            Text(
                "از تنظیمات پنل وب → «دسترسی اپ موبایل» یک توکن بساز و اینجا وارد کن.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = serverUrl,
                onValueChange = { serverUrl = it; error = null },
                label = { Text("آدرس سرور") },
                placeholder = { Text("https://panel.example.com") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = token,
                onValueChange = { token = it; error = null },
                label = { Text("توکن دسترسی (PAT)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )

            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                onClick = {
                    error = null
                    if (serverUrl.isBlank() || token.isBlank()) {
                        error = "آدرس سرور و توکن را کامل وارد کن."
                        return@Button
                    }
                    loading = true
                    session.baseUrl = serverUrl.trim()
                    session.token = token.trim()
                    scope.launch {
                        val ok = api.testConnection()
                        loading = false
                        if (ok) {
                            onConnected()
                        } else {
                            session.clear()
                            error = "اتصال ناموفق بود. آدرس یا توکن را بررسی کن."
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
                if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("اتصال")
            }
        }
    }
}
