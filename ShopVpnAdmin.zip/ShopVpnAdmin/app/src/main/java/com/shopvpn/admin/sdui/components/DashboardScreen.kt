package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.*
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

private data class Metric(val key: String, val label: String, val icon: ImageVector, val accent: Color, val tileBg: Color, val format: (Double) -> String = { it.toLong().toString() })

// هر متریک رنگ شیشه‌ای خودش رو داره — گرید بنتو باید رنگی و قابل تشخیص باشه،
// نه یک ستون کارت هم‌شکل با فقط آیکون فرق‌کننده.
private val METRICS = listOf(
    Metric("total_users", "کاربران کل", Icons.Filled.People, AccentCyan, TileCyanBg),
    Metric("new_users", "کاربران جدید", Icons.Filled.PersonAdd, AccentGreen, TileGreenBg),
    Metric("active_configs", "کانفیگ فعال", Icons.Filled.Shield, AccentViolet, TileVioletBg),
    Metric("open_tickets", "تیکت باز", Icons.Filled.SupportAgent, AccentAmber, TileAmberBg),
    Metric("conversion_rate", "نرخ تبدیل", Icons.Filled.TrendingUp, AccentBlue, TileBlueBg) { "${it.toInt()}٪" },
    Metric("repeat_customer_rate", "مشتری تکراری", Icons.Filled.Repeat, AccentPink, TilePinkBg) { "${it.toInt()}٪" },
)
private fun JsonObject.num(key: String): Double? = get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
private fun fmtToman(v: Double) = String.format("%,d", v.toLong()).replace(",", "٬") + " تومان"

@Composable
fun DashboardScreen(tab: TabConfig, api: ApiClient) {
    var stats by remember { mutableStateOf<JsonObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    suspend fun load() {
        loading = true; error = null
        try { val res = api.get(tab.source ?: "/api/dashboard"); stats = res.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject() }
        catch (e: Exception) { error = e.message ?: "خطا در دریافت آمار" }
        finally { loading = false }
    }
    LaunchedEffect(tab.id) { load() }
    when {
        loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = BrandPrimary) }
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("داشبورد در دسترس نیست"); Spacer(Modifier.height(10.dp)); Button({ scope.launch { load() } }) { Text("تلاش دوباره") } } }
        else -> {
            val s = stats ?: JsonObject(); val revenue = s.num("revenue") ?: 0.0; val change = s.num("revenue_change_pct")
            val wallet = s.num("wallet_total"); val aov = s.num("aov")
            val metricsWithValues = METRICS.map { it to s.num(it.key) }

            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // ردیف بنتو ۱: کارت درآمد بزرگ (۲/۳ عرض) + یک متریک برجسته کنارش (۱/۳ عرض)
                Row(Modifier.fillMaxWidth().height(168.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BrandGradientCard(Modifier.weight(2f).fillMaxHeight()) {
                        Column(Modifier.fillMaxSize()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("مرکز کنترل", color = Color.White.copy(.75f), style = MaterialTheme.typography.labelMedium)
                                Box(Modifier.size(34.dp).background(Color.White.copy(.14f), RoundedCornerShape(11.dp)), Alignment.Center) { Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                            }
                            Spacer(Modifier.weight(1f))
                            Text("درآمد این بازه", color = Color.White.copy(.75f), style = MaterialTheme.typography.bodySmall)
                            Text(fmtToman(revenue), color = Color.White, style = BentoJumboNumber)
                            Spacer(Modifier.height(6.dp))
                            if (change != null) Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (change >= 0) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("${"%.1f".format(kotlin.math.abs(change))}٪ نسبت به بازه قبل", color = Color.White.copy(.85f), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    metricsWithValues.getOrNull(0)?.let { (m, v) -> BentoTile(m, v, Modifier.weight(1f).fillMaxHeight()) }
                }

                SectionLabel("نمای کلی")
                // ردیف بنتو ۲: سه کارت مربعی کوچک
                Row(Modifier.fillMaxWidth().height(112.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    metricsWithValues.drop(1).take(3).forEach { (m, v) -> BentoTile(m, v, Modifier.weight(1f).fillMaxHeight(), compact = true) }
                }
                // ردیف بنتو ۳: یک کارت پهن + یک کارت باریک
                Row(Modifier.fillMaxWidth().height(112.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    metricsWithValues.getOrNull(4)?.let { (m, v) -> BentoTile(m, v, Modifier.weight(2f).fillMaxHeight(), compact = true) }
                    metricsWithValues.getOrNull(5)?.let { (m, v) -> BentoTile(m, v, Modifier.weight(1f).fillMaxHeight(), compact = true) }
                }

                if (wallet != null || aov != null) {
                    SectionLabel("مالی")
                    Row(Modifier.fillMaxWidth().height(88.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        wallet?.let { QuickValueCard("مجموع کیف‌پول", fmtToman(it), Icons.Filled.AccountBalanceWallet, AccentCyan, TileCyanBg, Modifier.weight(1f).fillMaxHeight()) }
                        aov?.let { QuickValueCard("میانگین سفارش", fmtToman(it), Icons.Filled.ReceiptLong, AccentPink, TilePinkBg, Modifier.weight(1f).fillMaxHeight()) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun BentoTile(m: Metric, value: Double?, modifier: Modifier, compact: Boolean = false) {
    ElevatedAppCard(modifier, tint = m.tileBg) {
        Column(Modifier.fillMaxSize().padding(if (compact) 12.dp else 14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            NeonIconTile(m.icon, m.accent, size = if (compact) 34.dp else 38.dp)
            Column {
                Text(value?.let(m.format) ?: "—", style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall)
                Text(m.label, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1)
            }
        }
    }
}

@Composable private fun QuickValueCard(label: String, value: String, icon: ImageVector, color: Color, tileBg: Color, modifier: Modifier) {
    ElevatedAppCard(modifier, tint = tileBg) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            NeonIconTile(icon, color, size = 38.dp); Spacer(Modifier.width(10.dp))
            Column { Text(value, style = MaterialTheme.typography.titleSmall); Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted) }
        }
    }
}
