package com.shopvpn.admin.sdui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.shopvpn.admin.data.model.TabConfig
import com.shopvpn.admin.network.ApiClient
import com.shopvpn.admin.ui.components.BrandGradientCard
import com.shopvpn.admin.ui.components.ElevatedAppCard
import com.shopvpn.admin.ui.components.SectionLabel
import com.shopvpn.admin.ui.theme.*
import kotlinx.coroutines.launch

private data class Metric(
    val key: String,
    val label: String,
    val icon: ImageVector,
    val color: Color,
    val format: (Double) -> String = { it.toLong().toString() },
    val changeKey: String? = null,
)

private val METRICS = listOf(
    Metric("total_users", "کاربران", Icons.Filled.People, AccentCyan),
    Metric("new_users", "کاربر جدید (بازه)", Icons.Filled.PersonAdd, StatusSuccess),
    Metric("active_configs", "کانفیگ فعال", Icons.Filled.Inventory2, BrandPrimary),
    Metric("open_tickets", "تیکت باز", Icons.Filled.SupportAgent, StatusWarning),
    Metric("conversion_rate", "نرخ تبدیل", Icons.Filled.TrendingUp, StatusInfo, { "${it.toInt()}٪" }),
    Metric("repeat_customer_rate", "مشتری تکراری", Icons.Filled.Repeat, AccentPink, { "${it.toInt()}٪" }),
)

private fun JsonObject.num(key: String): Double? =
    if (has(key) && this[key].isJsonPrimitive && this[key].asJsonPrimitive.isNumber) this[key].asDouble else null

private fun fmtToman(v: Double): String {
    val n = v.toLong()
    return "%,d".format(n).replace(",", "٬") + " ت"
}

@Composable
fun DashboardScreen(tab: TabConfig, api: ApiClient) {
    var stats by remember { mutableStateOf<JsonObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        loading = true
        error = null
        try {
            val res = api.get(tab.source ?: "/api/dashboard")
            stats = if (res.isJsonObject) res.asJsonObject else JsonObject()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    LaunchedEffect(tab.id) { load() }

    when {
        loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error ?: "خطا")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { scope.launch { load() } }) { Text("تلاش دوباره") }
            }
        }
        else -> {
            val s = stats ?: JsonObject()
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                val revenue = s.num("revenue") ?: 0.0
                val revenueChange = s.num("revenue_change_pct")
                val approved = s.num("approved") ?: 0.0
                val pending = s.num("pending") ?: 0.0

                BrandGradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("درآمد این بازه", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(fmtToman(revenue), color = Color.White, style = MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (revenueChange != null) {
                            val up = revenueChange >= 0
                            Icon(
                                if (up) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                                contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp),
                            )
                            Text(
                                " ${"%.1f".format(kotlin.math.abs(revenueChange))}٪ نسبت به بازه‌ی قبل",
                                color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.labelMedium,
                            )
                            Spacer(Modifier.width(10.dp))
                        }
                        Text(
                            "${approved.toInt()} تایید‌شده · ${pending.toInt()} در انتظار",
                            color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }

                SectionLabel("نگاه کلی")
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(((METRICS.size / 2 + METRICS.size % 2) * 100).dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(METRICS) { m ->
                        val raw = s.num(m.key)
                        StatCard(m, raw)
                    }
                }

                val walletTotal = s.num("wallet_total")
                val aov = s.num("aov")
                if (walletTotal != null || aov != null) {
                    SectionLabel("مالی تکمیلی")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        if (walletTotal != null) MiniStat("مجموع کیف‌پول کاربران", fmtToman(walletTotal), Modifier.weight(1f))
                        if (aov != null) MiniStat("میانگین ارزش سفارش", fmtToman(aov), Modifier.weight(1f))
                    }
                }

                val ticketsOpen = s.num("tickets_open")
                val avgResponse = s.num("avg_ticket_response_minutes")
                if (ticketsOpen != null || avgResponse != null) {
                    SectionLabel("پشتیبانی")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        if (ticketsOpen != null) MiniStat("تیکت باز", ticketsOpen.toInt().toString(), Modifier.weight(1f))
                        if (avgResponse != null) MiniStat("میانگین پاسخ (دقیقه)", avgResponse.toInt().toString(), Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun StatCard(m: Metric, raw: Double?) {
    ElevatedAppCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(m.color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) { Icon(m.icon, contentDescription = null, tint = m.color, modifier = Modifier.size(18.dp)) }
            Spacer(Modifier.height(10.dp))
            Text(if (raw != null) m.format(raw) else "—", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(2.dp))
            Text(m.label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedAppCard(modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(value, style = MaterialTheme.typography.titleMedium, color = BrandPrimary)
            Spacer(Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
